﻿using RestoranOtomasyon.Components;
using RestoranOtomasyon.Functions;
using RestoranOtomasyon.Objects;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace RestoranOtomasyon.Forms
{
    public partial class YonetimBayiAyarlari : Form
    {
        // GLOBAL VARIABLES


        // CONSTRUCTOR AND LOAD OBJECT
        public YonetimBayiAyarlari()
        {
            InitializeComponent();
        }
        private void YonetimBayiAyarlari_Load(object sender, EventArgs e)
        {
            loadBayiler();

        }

        // FUNCTIONS
        public void loadBayiler()
        {
            pnl_Bayiler.Controls.Clear();
            Database database = new Database();
            List<BayiObject> bayiler = database.listBayiler();
            foreach (var bayi in bayiler)
            {
                YonetimBayi yonetimBayi = new YonetimBayi(bayi.Id,bayi.BayiAdi,bayi.BayiAdresi,bayi.TelefonNo,bayi.YoneticiId,this)
                {
                    Dock = DockStyle.Top,
                    BorderStyle = BorderStyle.FixedSingle,
                };
                pnl_Bayiler.Controls.Add(yonetimBayi);
                Panel marginPanel = new Panel()
                {
                    Height = 5,
                    Dock = DockStyle.Top,
                    BackColor = Color.FromArgb(39, 39, 39),
                };
                pnl_Bayiler.Controls.Add(marginPanel);
            }
        }

        // EVENTS
        private void button2_Click(object sender2, EventArgs e)
        {
            YeniBayiEkleForm yeniBayiEkleForm = new YeniBayiEkleForm();
            yeniBayiEkleForm.FormClosing += (sender, args) =>
            {
                loadBayiler();
            };
            yeniBayiEkleForm.ShowDialog();
        }

        
    }
}
