﻿using Mail.Forms;
using RestoranOtomasyon.Functions;
using RestoranOtomasyon.Objects;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace RestoranOtomasyon.Forms
{
    public partial class YeniMasaKategorisiEkleForm : Form
    {
        YonetimRestoranAyarlari restoranAyarlari;
        GarsonEkrani garson;
        public YeniMasaKategorisiEkleForm(YonetimRestoranAyarlari yonetimRestoranAyarlari, GarsonEkrani garson)
        {
            InitializeComponent();
            this.restoranAyarlari = yonetimRestoranAyarlari;
            this.garson = garson;
        }
        public void Message(string message)
        {
            MyMessageBox messageBox = new MyMessageBox(message);
            messageBox.Show();
        }


        private void btn_Exit_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void btn_Sil_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void btn_Guncelle_Click(object sender, EventArgs e)
        {

            if (!(txb_KategoriAdi.Text.Length > 0))
            {
                Message("Lütfen kategori adı giriniz");
            }
            else if(!(txb_MasaSayisi.Text.Length > 0))
            {
                Message("Lütfen masa sayısı giriniz");
            }
            else
            {
                Database database = new Database();
                MasaKategoriObject masaKategoriObject = new MasaKategoriObject();
                masaKategoriObject.KategoriAdi = txb_KategoriAdi.Text;
                masaKategoriObject.Aktiflik = true;
                try
                {
                    masaKategoriObject.KategoriMasaSayisi = Convert.ToInt32(txb_MasaSayisi.Text);
                    string result = database.insertMasaKategori(masaKategoriObject);
                    Message(result);
                    restoranAyarlari.loadMasaKategorileri();
                    garson.listMasaKategori();
                    this.Close();
                }
                catch 
                {
                    Message("Kategori ekleme isteği gönderilirken bir hata meydana geldi");
                    return;
                }

            }
        }

        private void txb_MasaSayisi_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!char.IsControl(e.KeyChar) && !char.IsDigit(e.KeyChar))
            {
                e.Handled = true;
            }
        }
    }
}
