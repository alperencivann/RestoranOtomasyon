﻿using Mail.Forms;
using RestoranOtomasyon.Components;
using RestoranOtomasyon.Functions;
using RestoranOtomasyon.Objects;
using System;
using System.Collections.Generic;
using System.Data;
using System.Windows.Forms;

namespace RestoranOtomasyon.Forms
{
	public partial class YonetimUrunYonetimi : Form
    {
        // GLOBAL VARIABLES

        // CONSTRUCTOR AND LOAD EVENT
        public YonetimUrunYonetimi()
        {
            InitializeComponent();
        }
        private void YonetimUrunYonetimi_Load(object sender, EventArgs e)
        {
			loadUrunKategorileri();
			loadUrunler();
		}

		// FUNCTIONS
		public void loadUrunKategorileri()
		{
			pnl_UrunKategorileri.Controls.Clear();
			Database database = new Database();
			List<UrunKategoriObject> urunKategorileri = database.listUrunKategori();
			foreach (var urunKategorisi in urunKategorileri)
			{
				YonetimUrunKategorisiComp yonetimUrunKategorisi = new YonetimUrunKategorisiComp(urunKategorisi.Id, urunKategorisi.KategoriAdi, urunKategorisi.Aktiflik,this);
				yonetimUrunKategorisi.Dock = DockStyle.Top;
				pnl_UrunKategorileri.Controls.Add(yonetimUrunKategorisi);
				Panel pnlMargin = new Panel
				{
					Dock = DockStyle.Top,
					Height = 5,
				};
				pnl_UrunKategorileri.Controls.Add(pnlMargin);
			}
		}
		public void loadUrunler()
        {

            pnl_Urunler.Controls.Clear();
			Database database = new Database();
			List<UrunObject> urunler = database.listUrun();
			foreach (var urun in urunler)
			{
				YonetimUrunComp yonetimUrun = new YonetimUrunComp(urun.Id, urun.UrunAdi, this);
				yonetimUrun.Dock = DockStyle.Top;
				pnl_Urunler.Controls.Add(yonetimUrun);
				Panel pnlMargin = new Panel
				{
					Dock = DockStyle.Top,
					Height = 5,

				};
				pnl_Urunler.Controls.Add(pnlMargin);
			}
		}
		public void Message(string msg)
        {
            MyMessageBox myMessageBox = new MyMessageBox(msg);
            myMessageBox.ShowDialog();
        }
		public void locate()
		{
			int totalHeight = this.Height;
			pnl_UrunUst.Height = totalHeight / 2;
			pnl_UrunKategoriUst.Height = totalHeight / 2;
		}

		// EVENTS

		private void button1_Click(object sender2, EventArgs e)
		{
            YeniUrunEklemeDuzenlemeForm yeniUrunEklemeDuzenlemeForm = new YeniUrunEklemeDuzenlemeForm();
			yeniUrunEklemeDuzenlemeForm.FormClosing += (sender, args) =>
			{
				loadUrunler();
			};
			yeniUrunEklemeDuzenlemeForm.ShowDialog();
		}

		private void btn_YeniUrunKategorisiEkle_Click(object sender2, EventArgs e)
		{
			YeniUrunKategorisiEkleDuzenle yeniUrunKategorisiEkleDuzenle = new YeniUrunKategorisiEkleDuzenle(urunYonetimi:this);
			yeniUrunKategorisiEkleDuzenle.FormClosing += (sender, args) =>
			{
				loadUrunKategorileri();
			};
			yeniUrunKategorisiEkleDuzenle.ShowDialog();
		}

		private void YonetimUrunYonetimi_SizeChanged(object sender, EventArgs e)
		{
			locate();
		}
	}
}
