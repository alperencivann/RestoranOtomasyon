﻿using System;
using System.Text;
using System.Windows.Forms;

namespace Mail.Forms
{
    public partial class MyMessageBox : Form
    {
        public bool mouseDown;

        public string headerMessage = "";
        public string message = "";

        public int line = 40;
        public int lineHeight = 15;
        public int marginHeight = 12;
        public int headerAndButtonHeight = 33;

        int mouseX = 0;
        int mouseY = 0;

        public MyMessageBox(string message = "")
        {
            InitializeComponent();

            this.lbl_Header.Text = "Waldensoft | Restoran Otomasyon";
            this.lbl_Message.Text = message;
            this.message = message;

        }
        private void btn_Exit_Click(object sender, EventArgs e)
        {
            this.Close();

        }

        private void button1_Click(object sender, EventArgs e)
        {
            this.Close();
        }
        public void sizeAyarla()
        {
            if (message.Length < 100)
            {
                this.Width = 400;
                line = 40;
            }
            else if (message.Length < 200)
            {
                this.Width = 600;
                line = 60;
            }
            int nCount = howMuchRow(message);
            this.Height = ((this.message.Length / line) * lineHeight) + (marginHeight * 3) + (headerAndButtonHeight * 2) + (nCount * lineHeight);
            this.CenterToScreen();
        }
        private void MyMessageBox_Load(object sender, EventArgs e)
        {
            sizeAyarla();

        }

        public int howMuchRow(string text)
        {
            int nCounter = 0;
            int index = 0;
            while (index != -1)
            {
                index = text.IndexOf("\n");
                nCounter++;
                var aStringBuilder = new StringBuilder(text);
                if (index != -1)
                {
                    aStringBuilder.Remove(index, 1);
                    text = aStringBuilder.ToString();
                }
                else
                {
                    return nCounter;
                }
            }
            return nCounter;

        }

        private void pnl_Header_MouseDown(object sender, MouseEventArgs e)
        {
            mouseDown = true;
            mouseX = MousePosition.X - this.Left;
            mouseY = MousePosition.Y - this.Top;
        }

        private void pnl_Header_MouseMove(object sender, MouseEventArgs e)
        {
            if (mouseDown)
            {
                this.SetDesktopLocation((MousePosition.X - mouseX), (MousePosition.Y - mouseY));

            }
        }
        private void pnl_Header_MouseUp(object sender, MouseEventArgs e)
        {
            mouseDown = false;
        }

        private void lbl_Header_MouseDown(object sender, MouseEventArgs e)
        {
            mouseDown = true;
            mouseX = MousePosition.X - this.Left;
            mouseY = MousePosition.Y - this.Top;
        }

        private void lbl_Header_MouseMove(object sender, MouseEventArgs e)
        {
            if (mouseDown)
            {
                this.SetDesktopLocation((MousePosition.X - mouseX), (MousePosition.Y - mouseY));

            }
        }

        private void lbl_Header_MouseUp(object sender, MouseEventArgs e)
        {
            mouseDown = false;

        }
    }
}
