﻿using Mail.Forms;
using RestoranOtomasyon.Components;
using RestoranOtomasyon.Functions;
using RestoranOtomasyon.Objects;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace RestoranOtomasyon.Forms
{
	public partial class YeniUrunEklemeDuzenlemeForm : Form
	{
		// GLOBAL VARIABLES
		int urunId;
		YonetimUrunYonetimi yonetim;
		UrunObject urun = new UrunObject();

				
		// CONSTRUCTOR AND LOAD EVENT
		public YeniUrunEklemeDuzenlemeForm(int urunId = 0, YonetimUrunYonetimi yonetim = null)
		{
			InitializeComponent();
			this.urun.Id = urunId;
			this.yonetim = yonetim;
		}

		private void YeniUrunEklemeDuzenlemeForm_Load(object sender, EventArgs e)
		{
			loadUrunDetails();
		}
		// FUNCS
		public void Message(string message)
		{
			MyMessageBox myMessageBox = new MyMessageBox(message);
			myMessageBox.ShowDialog();
		}
		public void loadUrunDetails()
		{
			if (urun.Id != 0)
			{
				lbl_Header.Text = "Ürün Düzenleme Ekranı";
				Database database = new Database();
				urun = database.getUrun(urun.Id);
				txb_UrunAdi.Text = urun.UrunAdi;
				txb_SatisFiyati.Text = urun.SatisFiyati.ToString();
				try
				{
					
					pcb_Image.Image = Image.FromFile(urun.ImagePath);

				}
				catch 
				{

				}
				loadKategoriler(urun.KategoriId);
				
			}
			else
			{
				int width = (btn_Sil.Location.X + btn_Sil.Width) - btn_Guncelle.Location.X;
				btn_Guncelle.Width = width;
				btn_Sil.Visible = false;
				lbl_Header.Text = "Ürün Ekleme Ekranı";
				btn_Guncelle.Text = "Ürünü Kaydet";
				loadKategoriler(0);

			}
		}
		public void loadKategoriler(int seciliKategoriId)
		{
			Database databaseUrunKategorileri = new Database();
			List<UrunKategoriObject> kategories = databaseUrunKategorileri.listUrunKategori();
			foreach (var kategori in kategories)
			{
				cbx_Kategori.Items.Add(kategori.KategoriAdi);
				if (seciliKategoriId == kategori.Id && seciliKategoriId != 0)
				{
					cbx_Kategori.SelectedItem = kategori.KategoriAdi;
				}
			}
		}

		private void btn_Exit_Click(object sender, EventArgs e)
		{
			this.Close();
		}

		private void btn_UrunResmiSec_Click(object sender, EventArgs e)
		{
			OpenFileDialog of = new OpenFileDialog();
			//For any other formats
			of.Filter = "Image Files (*.bmp;*.jpg;*.jpeg,*.png)|*.BMP;*.JPG;*.JPEG;*.PNG";
			if (of.ShowDialog() == DialogResult.OK)
			{
				pcb_Image.ImageLocation = of.FileName;
				urun.ImagePath = of.FileName;
			}
		}

		private void btn_Guncelle_Click(object sender, EventArgs e)
		{
			if (urun.Id != 0)
			{
				string message = "";
				urun.UrunAdi = txb_UrunAdi.Text;
				if (urun.UrunAdi.Length < 1)
					message += "\nLütfen bir ürün adı girişi yapınız.";

				try
				{
					urun.SatisFiyati = (float)Convert.ToDouble(txb_SatisFiyati.Text);
				}
				catch
				{
					message += "\nLütfen ürüne bir satış fiyatı girişi yapınız.";
				}
				Database kategoriDatabase = new Database();
				string kategoriAdi = cbx_Kategori.Text;
				if (kategoriAdi.Length < 1)
				{
					message += "\nLütfen bir ürün kategorisi seçiniz.";
				}
				if (String.IsNullOrEmpty(urun.ImagePath))
				{
					urun.ImagePath = "";
				}
				urun.KategoriId = kategoriDatabase.getUrunKategoriFromName(kategoriAdi).Id;
				if (message.Length > 0)
				{
					Message(message);
				}
				else
				{
					Database database = new Database();
					string result = database.updateUrun(urun);
					Message(result);
					if (result.ToLower().Contains("başarılı"))
					{
						this.Close();
						yonetim.loadUrunler();
					}
				}
				
			}
			else
			{
				Database database = new Database();
				string message = "";
				urun.UrunAdi = txb_UrunAdi.Text;
				if (urun.UrunAdi.Length < 1)
					message += "\nLütfen bir ürün adı girişi yapınız.";

				try
				{
					urun.SatisFiyati = (float)Convert.ToDouble(txb_SatisFiyati.Text);
				}
				catch 
				{
					message += "\nLütfen ürüne bir satış fiyatı girişi yapınız.";
				}
				Database kategoriDatabase = new Database();
				string kategoriAdi = cbx_Kategori.Text;
				if (kategoriAdi.Length < 1)
				{
					message += "\nLütfen bir ürün kategorisi seçiniz.";
				}
				if (String.IsNullOrEmpty( urun.ImagePath))
				{
					urun.ImagePath = "";
				}
				urun.KategoriId = kategoriDatabase.getUrunKategoriFromName(kategoriAdi).Id;
				if (message.Length > 0)
				{
					Message(message);
				}
				else
				{
					string result = database.insertUrun(urun);
					Message(result);
					if (result.ToLower().Contains("başarılı"))
					{
						this.Close();
						yonetim.loadUrunler();
					}
				}
	
			}
		}

		private void txb_SatisFiyati_KeyPress(object sender, KeyPressEventArgs e)
		{
			if((!char.IsControl(e.KeyChar) && !char.IsDigit(e.KeyChar)) || e.KeyChar == '.')
			{
				e.Handled = true;
			}
		}

		private void btn_YeniKategoriEkle_Click(object sender2, EventArgs e)
		{
			YeniUrunKategorisiEkleDuzenle yeniUrunKategorisiEkleDuzenle = new YeniUrunKategorisiEkleDuzenle(urunYonetimi:yonetim);
			yeniUrunKategorisiEkleDuzenle.FormClosing += (sender, args) =>
			{
				loadKategoriler(urun.KategoriId);
			};
			yeniUrunKategorisiEkleDuzenle.ShowDialog();
		}

		private void btn_Sil_Click(object sender, EventArgs e)
		{
			Database db = new Database();
			string result = db.deleteUrun(urunId);
			Message(result);
			if (result.ToLower().Contains("başarılı"))
			{
				yonetim.loadUrunler();
				this.Close();
			}
		}
	}
}
