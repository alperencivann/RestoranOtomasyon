﻿using Mail.Forms;
using RestoranOtomasyon.Functions;
using RestoranOtomasyon.Objects;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Runtime.InteropServices;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace RestoranOtomasyon.Forms
{
    public partial class YeniTelegramBotuEkleForm : Form
    {
        // GLOBAL VARIABLES

        bool siparisBildirim = true;
        bool alinacaklarListesiBildirim = true;
        bool rezervasyonBildirim = true;
        bool gunlukRaporBildirim = true;
        bool yonetimAyariBildirim = true;
        bool calisanMaasBildirim = true;
        bool aktiflik = true;

        // CONSTRUCTOR AND LOAD EVENT
        public YeniTelegramBotuEkleForm()
        {
            InitializeComponent();
        }
        private void YeniTelegramBotuEkleForm_Load(object sender, EventArgs e)
        {
            Database dbKullanicilar = new Database();
            List<KullaniciObject> kullanicilar = dbKullanicilar.listKullanicilar();
            foreach (var kullanici in kullanicilar)
            {
                cbx_Kullanici.Items.Add(kullanici.KullaniciAdi);
            }
            cbx_Aktiflik.SelectedItem = "Aktif";
            setSiparisBildirimleri(siparisBildirim);
            setAlinacaklarBildirimleri(alinacaklarListesiBildirim);
            setRezervasyonBildirimleri(rezervasyonBildirim);
            setGunlukBildirimleri(gunlukRaporBildirim);
            setYonetimBildirimleri(yonetimAyariBildirim);
            setCalisanBildirimleri(calisanMaasBildirim);
        }
        // FUNCS
        public void Message(string message)
        {
            MyMessageBox myMessageBox = new MyMessageBox(message);
            myMessageBox.Show();
        }

        public void setSiparisBildirimleri(bool active)
        {
            if (active)
                pbx_Siparis.Image = imageList1.Images[0];
            else
                pbx_Siparis.Image = imageList1.Images[1];
        }
        public void setAlinacaklarBildirimleri(bool active)
        {
            if (active)
                pbx_Alinacaklar.Image = imageList1.Images[0];
            else
                pbx_Alinacaklar.Image = imageList1.Images[1];
        }
        public void setRezervasyonBildirimleri(bool active)
        {
            if (active)
                pbx_Rezervasyon.Image = imageList1.Images[0];
            else
                pbx_Rezervasyon.Image = imageList1.Images[1];
        }
        public void setGunlukBildirimleri(bool active)
        {
            if (active)
                pbx_GunlukRapor.Image = imageList1.Images[0];
            else
                pbx_GunlukRapor.Image = imageList1.Images[1];
        }
        public void setYonetimBildirimleri(bool active)
        {
            if (active)
                pbx_Yonetim.Image = imageList1.Images[0];
            else
                pbx_Yonetim.Image = imageList1.Images[1];
        }
        public void setCalisanBildirimleri(bool active)
        {
            if (active)
                pbx_Calisan.Image = imageList1.Images[0];
            else
                pbx_Calisan.Image = imageList1.Images[1];
        }

        // EVENTS
        private void pbx_Siparis_Click(object sender, EventArgs e)
        {
            siparisBildirim = !siparisBildirim;
            setSiparisBildirimleri(siparisBildirim);
        }

        private void pbx_Alinacaklar_Click(object sender, EventArgs e)
        {
            alinacaklarListesiBildirim = !alinacaklarListesiBildirim;
            setAlinacaklarBildirimleri(alinacaklarListesiBildirim);
        }

        private void pbx_GunlukRapor_Click(object sender, EventArgs e)
        {
            gunlukRaporBildirim = !gunlukRaporBildirim;
            setGunlukBildirimleri(gunlukRaporBildirim);
        }

        private void pbx_Yonetim_Click(object sender, EventArgs e)
        {
            yonetimAyariBildirim = !yonetimAyariBildirim;
            setYonetimBildirimleri(yonetimAyariBildirim);
        }

        private void pbx_Rezervasyon_Click(object sender, EventArgs e)
        {
            rezervasyonBildirim = !rezervasyonBildirim;
            setRezervasyonBildirimleri(rezervasyonBildirim);
        }

        private void pbx_Calisan_Click(object sender, EventArgs e)
        {
            calisanMaasBildirim = !calisanMaasBildirim;
            setCalisanBildirimleri(calisanMaasBildirim);
        }

        private void btn_Ekle_Click(object sender, EventArgs e)
        {
            string botAdi = txb_BotAdi.Text;
            string kullaniciName = cbx_Kullanici.Text;
            string botKey = txb_BotKey.Text;
            string chatId = txb_ChatId.Text;
            string message = "";
            bool flag = false;

            if (botAdi.Length <= 0)
            {
                message += "Lütfen bot adı bilgisi giriniz.\n";
                flag = true;
            }
            if (kullaniciName.Length <= 0)
            {
                message += "Lütfen kullanıcı seçiniz.\n";
                flag = true;
            }
            if (botKey.Length <= 0)
            {
                message += "Lütfen bot key bilgisi giriniz.\n";
                flag = true;
            }
            if (chatId.Length <= 0)
            {
                message += "Lütfen chat id bilgisi giriniz.\n";
                flag = true;
            }
            bool aktiflik = (cbx_Aktiflik.Text == "Aktif") ? true : false;

            if (flag)
            {
                Message(message);
            }
            else
            {
                Database dbKullanici = new Database();
                KullaniciObject kullanici = dbKullanici.getKullaniciFromName(cbx_Kullanici.Text);
                TelegramBotObject telegram = new TelegramBotObject();
                telegram.KullaniciId = kullanici.Id;
                telegram.BotKey = botKey;
                telegram.ChatId = chatId;
                telegram.SiparisBildirim = siparisBildirim;
                telegram.AlinacaklarListesiBildirim = alinacaklarListesiBildirim;
                telegram.RezervasyonBildirim = rezervasyonBildirim;
                telegram.GunlukRaporBildirim = gunlukRaporBildirim;
                telegram.YonetimAyariBildirim = yonetimAyariBildirim;
                telegram.CalisanMaasBildirim = calisanMaasBildirim;
                telegram.BotAdi = botAdi;
                telegram.Aktiflik = aktiflik;
                Database database = new Database();
                string result = database.insertTelegram(telegram);
                Message(result);
                this.Close();
            }

            

        }

        private void btn_Exit_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void btn_Iptal_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        
    }
}
