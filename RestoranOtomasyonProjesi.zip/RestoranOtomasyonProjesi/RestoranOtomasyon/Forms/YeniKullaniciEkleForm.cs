﻿using Mail.Forms;
using RestoranOtomasyon.Functions;
using RestoranOtomasyon.Objects;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Runtime.InteropServices;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace RestoranOtomasyon.Forms
{
    public partial class YeniKullaniciEkleForm : Form
    {
        public string kullaniciAdi;
        public string telefonNumarasi;
        public string adres;
        public string iban;
        public int maas;
        public int yetkiId;
        public YonetimKullaniciAyarlari yonetimKullanici;

        public YeniKullaniciEkleForm([Optional, DefaultValue(null)]YonetimKullaniciAyarlari yonetimKullanici)
        {
            InitializeComponent();
            this.yonetimKullanici = yonetimKullanici;
        }
        
        // FUNCS
        public void Message(string message)
        {
            MyMessageBox myMessageBox = new MyMessageBox(message);
            myMessageBox.Show();
        }

        public void loadYetkiler()
        {
            Database database = new Database();
            List<YetkiObject> yetkiler = database.listYetkiler();
            foreach (var yetki in yetkiler)
            {
                cbx_Yetkisi.Items.Add(yetki.YetkiAdi);
            }

        }
        private void YeniKullaniciEkleForm_Load(object sender, EventArgs e)
        {
            loadYetkiler();
        }

        private async void btn_Ekle_ClickAsync(object sender, EventArgs e)
        {
            Database yetkiDb = new Database();
            kullaniciAdi = txb_AdSoyad.Text;
            telefonNumarasi = txb_TelefonNumarası.Text.Replace("+","");
            adres = txb_KullaniciAdresi.Text;
            iban = txb_Iban.Text;
            try
            {
                maas = Convert.ToInt32(txb_Maas.Text);
            }
            catch
            {
                maas = 0;
            }
            YetkiObject yetkili = yetkiDb.getYetkiFromName(cbx_Yetkisi.Text);
            
            Funcs funcs = new Funcs();
            bool flag = false;
            string message = "";
            if (kullaniciAdi.Length < 1)
            {
                flag = true;
                message += "Lütfen isim soyisim bilgisi giriniz.\n";
            }
            if (!await funcs.isValidPhoneNumber(telefonNumarasi))
            {
                flag = true;
                message += "Lütfen geçerli bir telefon numarası giriniz.\n";
            }
            if (cbx_Yetkisi.Text.Length < 1 || !(yetkili.YetkiAdi.Length > 0))
            {
                flag = true;
                message += "Kullanıcının sahip olduğu bir yetki olmalıdır, lütfen yetki seçiniz.\n";
            }
            

            if (flag)
            {
                Message(message);
            }
            else
            {
                Database isTakedDb = new Database();
                KullaniciObject isTakedKullanici = isTakedDb.getKullaniciFromName(kullaniciAdi);
                bool isTaked = string.IsNullOrEmpty(isTakedKullanici.KullaniciAdi);
                if (!isTaked)
                {
                    Message("Bu isim soyisime sahip bir kullanıcı bulunmaktadır.\nLütfen başka isim soyisim giriniz.");
                }
                else
                {
                    Database database = new Database();
                    KullaniciObject kullanici = new KullaniciObject()
                    {
                        KullaniciAdi = kullaniciAdi,
                        KullaniciTelefonNumarasi = telefonNumarasi,
                        KullaniciAdresi = adres,
                        KullaniciIban = iban,
                        KullaniciMaasi = maas,
                        YetkiId = yetkili.Id
                    };
                    string result = database.insertKullanici(kullanici);
                    Message(result);
                    if (result.ToLower().Contains("başarılı") && yonetimKullanici != null)
                    {
                        yonetimKullanici.loadKullanicilar();
                    }
                    
                }
            }
        }

        private void btn_Iptal_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void btn_Exit_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void txb_Maas_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!char.IsControl(e.KeyChar) && !char.IsDigit(e.KeyChar))
            {
                e.Handled = true;
            }
        }

		private void txb_TelefonNumarası_KeyPress(object sender, KeyPressEventArgs e)
		{
			if (!char.IsControl(e.KeyChar) && !char.IsDigit(e.KeyChar) &&
		(e.KeyChar != '.'))
			{
				e.Handled = true;
			}
		}
	}
}
