﻿namespace RestoranOtomasyon.Forms
{
    partial class YonetimYetkileriDuzenlemeForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(YonetimYetkileriDuzenlemeForm));
            this.panel1 = new System.Windows.Forms.Panel();
            this.lbl_Header = new System.Windows.Forms.Label();
            this.panel2 = new System.Windows.Forms.Panel();
            this.panel10 = new System.Windows.Forms.Panel();
            this.btn_Exit = new System.Windows.Forms.Button();
            this.panel3 = new System.Windows.Forms.Panel();
            this.txb_RestoranAdi = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.panel4 = new System.Windows.Forms.Panel();
            this.btn_Guncelle = new System.Windows.Forms.Button();
            this.panel17 = new System.Windows.Forms.Panel();
            this.pcb_Urun = new System.Windows.Forms.PictureBox();
            this.label14 = new System.Windows.Forms.Label();
            this.panel12 = new System.Windows.Forms.Panel();
            this.pcb_Modul = new System.Windows.Forms.PictureBox();
            this.label9 = new System.Windows.Forms.Label();
            this.panel13 = new System.Windows.Forms.Panel();
            this.pcb_Telegram = new System.Windows.Forms.PictureBox();
            this.label10 = new System.Windows.Forms.Label();
            this.panel14 = new System.Windows.Forms.Panel();
            this.pcb_RaporGoruntuleme = new System.Windows.Forms.PictureBox();
            this.label11 = new System.Windows.Forms.Label();
            this.panel6 = new System.Windows.Forms.Panel();
            this.pcb_BayiGoruntuleme = new System.Windows.Forms.PictureBox();
            this.label6 = new System.Windows.Forms.Label();
            this.panel7 = new System.Windows.Forms.Panel();
            this.pcb_SiparisIptalEtme = new System.Windows.Forms.PictureBox();
            this.label7 = new System.Windows.Forms.Label();
            this.panel11 = new System.Windows.Forms.Panel();
            this.pcb_YapilacaklarListesindenSilme = new System.Windows.Forms.PictureBox();
            this.label8 = new System.Windows.Forms.Label();
            this.panel9 = new System.Windows.Forms.Panel();
            this.pcb_YapilacaklarListesineEkleme = new System.Windows.Forms.PictureBox();
            this.label5 = new System.Windows.Forms.Label();
            this.panel8 = new System.Windows.Forms.Panel();
            this.pcb_YonetimEklemeGuncelleme = new System.Windows.Forms.PictureBox();
            this.label4 = new System.Windows.Forms.Label();
            this.panel5 = new System.Windows.Forms.Panel();
            this.pcb_ayarlarEkrani = new System.Windows.Forms.PictureBox();
            this.label3 = new System.Windows.Forms.Label();
            this.imageList = new System.Windows.Forms.ImageList(this.components);
            this.panel1.SuspendLayout();
            this.panel10.SuspendLayout();
            this.panel3.SuspendLayout();
            this.panel4.SuspendLayout();
            this.panel17.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pcb_Urun)).BeginInit();
            this.panel12.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pcb_Modul)).BeginInit();
            this.panel13.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pcb_Telegram)).BeginInit();
            this.panel14.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pcb_RaporGoruntuleme)).BeginInit();
            this.panel6.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pcb_BayiGoruntuleme)).BeginInit();
            this.panel7.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pcb_SiparisIptalEtme)).BeginInit();
            this.panel11.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pcb_YapilacaklarListesindenSilme)).BeginInit();
            this.panel9.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pcb_YapilacaklarListesineEkleme)).BeginInit();
            this.panel8.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pcb_YonetimEklemeGuncelleme)).BeginInit();
            this.panel5.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pcb_ayarlarEkrani)).BeginInit();
            this.SuspendLayout();
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(24)))), ((int)(((byte)(24)))), ((int)(((byte)(24)))));
            this.panel1.Controls.Add(this.lbl_Header);
            this.panel1.Controls.Add(this.panel2);
            this.panel1.Controls.Add(this.panel10);
            this.panel1.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel1.Location = new System.Drawing.Point(0, 0);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(800, 50);
            this.panel1.TabIndex = 2;
            // 
            // lbl_Header
            // 
            this.lbl_Header.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(29)))), ((int)(((byte)(29)))), ((int)(((byte)(29)))));
            this.lbl_Header.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lbl_Header.Font = new System.Drawing.Font("Century Gothic", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.lbl_Header.ForeColor = System.Drawing.Color.White;
            this.lbl_Header.Location = new System.Drawing.Point(36, 0);
            this.lbl_Header.Name = "lbl_Header";
            this.lbl_Header.Size = new System.Drawing.Size(728, 50);
            this.lbl_Header.TabIndex = 5;
            this.lbl_Header.Text = "Yetkileri Düzenle";
            this.lbl_Header.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // panel2
            // 
            this.panel2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(29)))), ((int)(((byte)(29)))), ((int)(((byte)(29)))));
            this.panel2.Dock = System.Windows.Forms.DockStyle.Left;
            this.panel2.Location = new System.Drawing.Point(0, 0);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(36, 50);
            this.panel2.TabIndex = 4;
            // 
            // panel10
            // 
            this.panel10.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(29)))), ((int)(((byte)(29)))), ((int)(((byte)(29)))));
            this.panel10.Controls.Add(this.btn_Exit);
            this.panel10.Dock = System.Windows.Forms.DockStyle.Right;
            this.panel10.Location = new System.Drawing.Point(764, 0);
            this.panel10.Name = "panel10";
            this.panel10.Size = new System.Drawing.Size(36, 50);
            this.panel10.TabIndex = 3;
            // 
            // btn_Exit
            // 
            this.btn_Exit.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(24)))), ((int)(((byte)(24)))), ((int)(((byte)(24)))));
            this.btn_Exit.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_Exit.Font = new System.Drawing.Font("Century Gothic", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.btn_Exit.ForeColor = System.Drawing.Color.Red;
            this.btn_Exit.Location = new System.Drawing.Point(4, 9);
            this.btn_Exit.Name = "btn_Exit";
            this.btn_Exit.Size = new System.Drawing.Size(29, 31);
            this.btn_Exit.TabIndex = 1;
            this.btn_Exit.Text = "x";
            this.btn_Exit.UseVisualStyleBackColor = false;
            this.btn_Exit.Click += new System.EventHandler(this.btn_Exit_Click);
            // 
            // panel3
            // 
            this.panel3.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(29)))), ((int)(((byte)(29)))), ((int)(((byte)(29)))));
            this.panel3.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel3.Controls.Add(this.txb_RestoranAdi);
            this.panel3.Controls.Add(this.label1);
            this.panel3.Location = new System.Drawing.Point(12, 56);
            this.panel3.Name = "panel3";
            this.panel3.Size = new System.Drawing.Size(776, 46);
            this.panel3.TabIndex = 3;
            // 
            // txb_RestoranAdi
            // 
            this.txb_RestoranAdi.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.txb_RestoranAdi.Font = new System.Drawing.Font("Century Gothic", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.txb_RestoranAdi.Location = new System.Drawing.Point(179, 12);
            this.txb_RestoranAdi.Name = "txb_RestoranAdi";
            this.txb_RestoranAdi.Size = new System.Drawing.Size(575, 22);
            this.txb_RestoranAdi.TabIndex = 3;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Century Gothic", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label1.ForeColor = System.Drawing.Color.White;
            this.label1.Location = new System.Drawing.Point(12, 15);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(65, 16);
            this.label1.TabIndex = 1;
            this.label1.Text = "Yetki Adı";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Century Gothic", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label2.ForeColor = System.Drawing.Color.White;
            this.label2.Location = new System.Drawing.Point(24, 116);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(150, 16);
            this.label2.TabIndex = 4;
            this.label2.Text = "Sahip Olduğu Yetkiler";
            // 
            // panel4
            // 
            this.panel4.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(29)))), ((int)(((byte)(29)))), ((int)(((byte)(29)))));
            this.panel4.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel4.Controls.Add(this.btn_Guncelle);
            this.panel4.Controls.Add(this.panel17);
            this.panel4.Controls.Add(this.panel12);
            this.panel4.Controls.Add(this.panel13);
            this.panel4.Controls.Add(this.panel14);
            this.panel4.Controls.Add(this.panel6);
            this.panel4.Controls.Add(this.panel7);
            this.panel4.Controls.Add(this.panel11);
            this.panel4.Controls.Add(this.panel9);
            this.panel4.Controls.Add(this.panel8);
            this.panel4.Controls.Add(this.panel5);
            this.panel4.Location = new System.Drawing.Point(12, 146);
            this.panel4.Name = "panel4";
            this.panel4.Size = new System.Drawing.Size(776, 276);
            this.panel4.TabIndex = 4;
            // 
            // btn_Guncelle
            // 
            this.btn_Guncelle.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.btn_Guncelle.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(2)))), ((int)(((byte)(117)))), ((int)(((byte)(252)))));
            this.btn_Guncelle.FlatAppearance.BorderSize = 0;
            this.btn_Guncelle.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_Guncelle.Font = new System.Drawing.Font("Century Gothic", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.btn_Guncelle.ForeColor = System.Drawing.Color.White;
            this.btn_Guncelle.Location = new System.Drawing.Point(9, 229);
            this.btn_Guncelle.Name = "btn_Guncelle";
            this.btn_Guncelle.Size = new System.Drawing.Size(756, 33);
            this.btn_Guncelle.TabIndex = 15;
            this.btn_Guncelle.Text = "Kaydet";
            this.btn_Guncelle.UseVisualStyleBackColor = false;
            this.btn_Guncelle.Click += new System.EventHandler(this.btn_Guncelle_Click);
            // 
            // panel17
            // 
            this.panel17.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(49)))), ((int)(((byte)(49)))), ((int)(((byte)(49)))));
            this.panel17.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel17.Controls.Add(this.pcb_Urun);
            this.panel17.Controls.Add(this.label14);
            this.panel17.Location = new System.Drawing.Point(9, 172);
            this.panel17.Name = "panel17";
            this.panel17.Size = new System.Drawing.Size(242, 47);
            this.panel17.TabIndex = 14;
            // 
            // pcb_Urun
            // 
            this.pcb_Urun.Cursor = System.Windows.Forms.Cursors.Hand;
            this.pcb_Urun.Image = ((System.Drawing.Image)(resources.GetObject("pcb_Urun.Image")));
            this.pcb_Urun.Location = new System.Drawing.Point(155, -1);
            this.pcb_Urun.Name = "pcb_Urun";
            this.pcb_Urun.Size = new System.Drawing.Size(80, 47);
            this.pcb_Urun.SizeMode = System.Windows.Forms.PictureBoxSizeMode.CenterImage;
            this.pcb_Urun.TabIndex = 6;
            this.pcb_Urun.TabStop = false;
            this.pcb_Urun.Click += new System.EventHandler(this.pcb_Urun_Click);
            // 
            // label14
            // 
            this.label14.Font = new System.Drawing.Font("Century Gothic", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label14.ForeColor = System.Drawing.Color.White;
            this.label14.Location = new System.Drawing.Point(8, 0);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(141, 45);
            this.label14.TabIndex = 4;
            this.label14.Text = "Ürün yönetimi";
            this.label14.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // panel12
            // 
            this.panel12.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(49)))), ((int)(((byte)(49)))), ((int)(((byte)(49)))));
            this.panel12.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel12.Controls.Add(this.pcb_Modul);
            this.panel12.Controls.Add(this.label9);
            this.panel12.Location = new System.Drawing.Point(523, 118);
            this.panel12.Name = "panel12";
            this.panel12.Size = new System.Drawing.Size(242, 47);
            this.panel12.TabIndex = 13;
            // 
            // pcb_Modul
            // 
            this.pcb_Modul.Cursor = System.Windows.Forms.Cursors.Hand;
            this.pcb_Modul.Image = ((System.Drawing.Image)(resources.GetObject("pcb_Modul.Image")));
            this.pcb_Modul.Location = new System.Drawing.Point(155, -1);
            this.pcb_Modul.Name = "pcb_Modul";
            this.pcb_Modul.Size = new System.Drawing.Size(80, 47);
            this.pcb_Modul.SizeMode = System.Windows.Forms.PictureBoxSizeMode.CenterImage;
            this.pcb_Modul.TabIndex = 6;
            this.pcb_Modul.TabStop = false;
            this.pcb_Modul.Click += new System.EventHandler(this.pcb_Modul_Click);
            // 
            // label9
            // 
            this.label9.Font = new System.Drawing.Font("Century Gothic", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label9.ForeColor = System.Drawing.Color.White;
            this.label9.Location = new System.Drawing.Point(8, 0);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(141, 45);
            this.label9.TabIndex = 4;
            this.label9.Text = "Modül Düzenleme";
            this.label9.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // panel13
            // 
            this.panel13.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(49)))), ((int)(((byte)(49)))), ((int)(((byte)(49)))));
            this.panel13.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel13.Controls.Add(this.pcb_Telegram);
            this.panel13.Controls.Add(this.label10);
            this.panel13.Location = new System.Drawing.Point(266, 118);
            this.panel13.Name = "panel13";
            this.panel13.Size = new System.Drawing.Size(242, 47);
            this.panel13.TabIndex = 12;
            // 
            // pcb_Telegram
            // 
            this.pcb_Telegram.Cursor = System.Windows.Forms.Cursors.Hand;
            this.pcb_Telegram.Image = ((System.Drawing.Image)(resources.GetObject("pcb_Telegram.Image")));
            this.pcb_Telegram.Location = new System.Drawing.Point(155, -1);
            this.pcb_Telegram.Name = "pcb_Telegram";
            this.pcb_Telegram.Size = new System.Drawing.Size(80, 47);
            this.pcb_Telegram.SizeMode = System.Windows.Forms.PictureBoxSizeMode.CenterImage;
            this.pcb_Telegram.TabIndex = 5;
            this.pcb_Telegram.TabStop = false;
            this.pcb_Telegram.Click += new System.EventHandler(this.pcb_Telegram_Click);
            // 
            // label10
            // 
            this.label10.Font = new System.Drawing.Font("Century Gothic", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label10.ForeColor = System.Drawing.Color.White;
            this.label10.Location = new System.Drawing.Point(8, 0);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(141, 45);
            this.label10.TabIndex = 4;
            this.label10.Text = "Telegram bot ayarları";
            this.label10.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // panel14
            // 
            this.panel14.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(49)))), ((int)(((byte)(49)))), ((int)(((byte)(49)))));
            this.panel14.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel14.Controls.Add(this.pcb_RaporGoruntuleme);
            this.panel14.Controls.Add(this.label11);
            this.panel14.Location = new System.Drawing.Point(9, 118);
            this.panel14.Name = "panel14";
            this.panel14.Size = new System.Drawing.Size(242, 47);
            this.panel14.TabIndex = 11;
            // 
            // pcb_RaporGoruntuleme
            // 
            this.pcb_RaporGoruntuleme.Cursor = System.Windows.Forms.Cursors.Hand;
            this.pcb_RaporGoruntuleme.Image = ((System.Drawing.Image)(resources.GetObject("pcb_RaporGoruntuleme.Image")));
            this.pcb_RaporGoruntuleme.Location = new System.Drawing.Point(155, -1);
            this.pcb_RaporGoruntuleme.Name = "pcb_RaporGoruntuleme";
            this.pcb_RaporGoruntuleme.Size = new System.Drawing.Size(80, 47);
            this.pcb_RaporGoruntuleme.SizeMode = System.Windows.Forms.PictureBoxSizeMode.CenterImage;
            this.pcb_RaporGoruntuleme.TabIndex = 6;
            this.pcb_RaporGoruntuleme.TabStop = false;
            this.pcb_RaporGoruntuleme.Click += new System.EventHandler(this.pcb_RaporGoruntuleme_Click);
            // 
            // label11
            // 
            this.label11.Font = new System.Drawing.Font("Century Gothic", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label11.ForeColor = System.Drawing.Color.White;
            this.label11.Location = new System.Drawing.Point(8, 0);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(141, 45);
            this.label11.TabIndex = 4;
            this.label11.Text = "Rapor görüntüleme";
            this.label11.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // panel6
            // 
            this.panel6.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(49)))), ((int)(((byte)(49)))), ((int)(((byte)(49)))));
            this.panel6.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel6.Controls.Add(this.pcb_BayiGoruntuleme);
            this.panel6.Controls.Add(this.label6);
            this.panel6.Location = new System.Drawing.Point(523, 64);
            this.panel6.Name = "panel6";
            this.panel6.Size = new System.Drawing.Size(242, 47);
            this.panel6.TabIndex = 10;
            // 
            // pcb_BayiGoruntuleme
            // 
            this.pcb_BayiGoruntuleme.Cursor = System.Windows.Forms.Cursors.Hand;
            this.pcb_BayiGoruntuleme.Image = ((System.Drawing.Image)(resources.GetObject("pcb_BayiGoruntuleme.Image")));
            this.pcb_BayiGoruntuleme.Location = new System.Drawing.Point(155, -1);
            this.pcb_BayiGoruntuleme.Name = "pcb_BayiGoruntuleme";
            this.pcb_BayiGoruntuleme.Size = new System.Drawing.Size(80, 47);
            this.pcb_BayiGoruntuleme.SizeMode = System.Windows.Forms.PictureBoxSizeMode.CenterImage;
            this.pcb_BayiGoruntuleme.TabIndex = 6;
            this.pcb_BayiGoruntuleme.TabStop = false;
            this.pcb_BayiGoruntuleme.Click += new System.EventHandler(this.pcb_BayiGoruntuleme_Click);
            // 
            // label6
            // 
            this.label6.Font = new System.Drawing.Font("Century Gothic", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label6.ForeColor = System.Drawing.Color.White;
            this.label6.Location = new System.Drawing.Point(8, 0);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(141, 45);
            this.label6.TabIndex = 4;
            this.label6.Text = "Bayi görüntüleme";
            this.label6.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // panel7
            // 
            this.panel7.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(49)))), ((int)(((byte)(49)))), ((int)(((byte)(49)))));
            this.panel7.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel7.Controls.Add(this.pcb_SiparisIptalEtme);
            this.panel7.Controls.Add(this.label7);
            this.panel7.Location = new System.Drawing.Point(266, 64);
            this.panel7.Name = "panel7";
            this.panel7.Size = new System.Drawing.Size(242, 47);
            this.panel7.TabIndex = 9;
            // 
            // pcb_SiparisIptalEtme
            // 
            this.pcb_SiparisIptalEtme.Cursor = System.Windows.Forms.Cursors.Hand;
            this.pcb_SiparisIptalEtme.Image = ((System.Drawing.Image)(resources.GetObject("pcb_SiparisIptalEtme.Image")));
            this.pcb_SiparisIptalEtme.Location = new System.Drawing.Point(155, -1);
            this.pcb_SiparisIptalEtme.Name = "pcb_SiparisIptalEtme";
            this.pcb_SiparisIptalEtme.Size = new System.Drawing.Size(80, 47);
            this.pcb_SiparisIptalEtme.SizeMode = System.Windows.Forms.PictureBoxSizeMode.CenterImage;
            this.pcb_SiparisIptalEtme.TabIndex = 5;
            this.pcb_SiparisIptalEtme.TabStop = false;
            this.pcb_SiparisIptalEtme.Click += new System.EventHandler(this.pcb_SiparisIptalEtme_Click);
            // 
            // label7
            // 
            this.label7.Font = new System.Drawing.Font("Century Gothic", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label7.ForeColor = System.Drawing.Color.White;
            this.label7.Location = new System.Drawing.Point(8, 0);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(141, 45);
            this.label7.TabIndex = 4;
            this.label7.Text = "Sipariş iptal etme";
            this.label7.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // panel11
            // 
            this.panel11.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(49)))), ((int)(((byte)(49)))), ((int)(((byte)(49)))));
            this.panel11.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel11.Controls.Add(this.pcb_YapilacaklarListesindenSilme);
            this.panel11.Controls.Add(this.label8);
            this.panel11.Location = new System.Drawing.Point(9, 64);
            this.panel11.Name = "panel11";
            this.panel11.Size = new System.Drawing.Size(242, 47);
            this.panel11.TabIndex = 8;
            // 
            // pcb_YapilacaklarListesindenSilme
            // 
            this.pcb_YapilacaklarListesindenSilme.Cursor = System.Windows.Forms.Cursors.Hand;
            this.pcb_YapilacaklarListesindenSilme.Image = ((System.Drawing.Image)(resources.GetObject("pcb_YapilacaklarListesindenSilme.Image")));
            this.pcb_YapilacaklarListesindenSilme.Location = new System.Drawing.Point(155, -1);
            this.pcb_YapilacaklarListesindenSilme.Name = "pcb_YapilacaklarListesindenSilme";
            this.pcb_YapilacaklarListesindenSilme.Size = new System.Drawing.Size(80, 47);
            this.pcb_YapilacaklarListesindenSilme.SizeMode = System.Windows.Forms.PictureBoxSizeMode.CenterImage;
            this.pcb_YapilacaklarListesindenSilme.TabIndex = 6;
            this.pcb_YapilacaklarListesindenSilme.TabStop = false;
            this.pcb_YapilacaklarListesindenSilme.Click += new System.EventHandler(this.pcb_YapilacaklarListesindenSilme_Click);
            // 
            // label8
            // 
            this.label8.Font = new System.Drawing.Font("Century Gothic", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label8.ForeColor = System.Drawing.Color.White;
            this.label8.Location = new System.Drawing.Point(8, 0);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(141, 45);
            this.label8.TabIndex = 4;
            this.label8.Text = "Yapılacaklar listesinden silme";
            this.label8.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // panel9
            // 
            this.panel9.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(49)))), ((int)(((byte)(49)))), ((int)(((byte)(49)))));
            this.panel9.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel9.Controls.Add(this.pcb_YapilacaklarListesineEkleme);
            this.panel9.Controls.Add(this.label5);
            this.panel9.Location = new System.Drawing.Point(523, 9);
            this.panel9.Name = "panel9";
            this.panel9.Size = new System.Drawing.Size(242, 47);
            this.panel9.TabIndex = 7;
            // 
            // pcb_YapilacaklarListesineEkleme
            // 
            this.pcb_YapilacaklarListesineEkleme.Cursor = System.Windows.Forms.Cursors.Hand;
            this.pcb_YapilacaklarListesineEkleme.Image = ((System.Drawing.Image)(resources.GetObject("pcb_YapilacaklarListesineEkleme.Image")));
            this.pcb_YapilacaklarListesineEkleme.Location = new System.Drawing.Point(155, -1);
            this.pcb_YapilacaklarListesineEkleme.Name = "pcb_YapilacaklarListesineEkleme";
            this.pcb_YapilacaklarListesineEkleme.Size = new System.Drawing.Size(80, 47);
            this.pcb_YapilacaklarListesineEkleme.SizeMode = System.Windows.Forms.PictureBoxSizeMode.CenterImage;
            this.pcb_YapilacaklarListesineEkleme.TabIndex = 6;
            this.pcb_YapilacaklarListesineEkleme.TabStop = false;
            this.pcb_YapilacaklarListesineEkleme.Click += new System.EventHandler(this.pcb_YapilacaklarListesineEkleme_Click);
            // 
            // label5
            // 
            this.label5.Font = new System.Drawing.Font("Century Gothic", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label5.ForeColor = System.Drawing.Color.White;
            this.label5.Location = new System.Drawing.Point(8, 0);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(141, 45);
            this.label5.TabIndex = 4;
            this.label5.Text = "Yapılacaklar listesine ekleme";
            this.label5.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // panel8
            // 
            this.panel8.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(49)))), ((int)(((byte)(49)))), ((int)(((byte)(49)))));
            this.panel8.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel8.Controls.Add(this.pcb_YonetimEklemeGuncelleme);
            this.panel8.Controls.Add(this.label4);
            this.panel8.Location = new System.Drawing.Point(266, 9);
            this.panel8.Name = "panel8";
            this.panel8.Size = new System.Drawing.Size(242, 47);
            this.panel8.TabIndex = 6;
            // 
            // pcb_YonetimEklemeGuncelleme
            // 
            this.pcb_YonetimEklemeGuncelleme.Cursor = System.Windows.Forms.Cursors.Hand;
            this.pcb_YonetimEklemeGuncelleme.Image = ((System.Drawing.Image)(resources.GetObject("pcb_YonetimEklemeGuncelleme.Image")));
            this.pcb_YonetimEklemeGuncelleme.Location = new System.Drawing.Point(155, -1);
            this.pcb_YonetimEklemeGuncelleme.Name = "pcb_YonetimEklemeGuncelleme";
            this.pcb_YonetimEklemeGuncelleme.Size = new System.Drawing.Size(80, 47);
            this.pcb_YonetimEklemeGuncelleme.SizeMode = System.Windows.Forms.PictureBoxSizeMode.CenterImage;
            this.pcb_YonetimEklemeGuncelleme.TabIndex = 5;
            this.pcb_YonetimEklemeGuncelleme.TabStop = false;
            this.pcb_YonetimEklemeGuncelleme.Click += new System.EventHandler(this.pcb_YonetimEklemeGuncelleme_Click);
            // 
            // label4
            // 
            this.label4.Font = new System.Drawing.Font("Century Gothic", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label4.ForeColor = System.Drawing.Color.White;
            this.label4.Location = new System.Drawing.Point(8, 0);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(141, 45);
            this.label4.TabIndex = 4;
            this.label4.Text = "Yönetim Paneli Ekleme güncelleme yetkisi";
            this.label4.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // panel5
            // 
            this.panel5.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(49)))), ((int)(((byte)(49)))), ((int)(((byte)(49)))));
            this.panel5.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel5.Controls.Add(this.pcb_ayarlarEkrani);
            this.panel5.Controls.Add(this.label3);
            this.panel5.Location = new System.Drawing.Point(9, 9);
            this.panel5.Name = "panel5";
            this.panel5.Size = new System.Drawing.Size(242, 47);
            this.panel5.TabIndex = 0;
            // 
            // pcb_ayarlarEkrani
            // 
            this.pcb_ayarlarEkrani.Cursor = System.Windows.Forms.Cursors.Hand;
            this.pcb_ayarlarEkrani.Image = ((System.Drawing.Image)(resources.GetObject("pcb_ayarlarEkrani.Image")));
            this.pcb_ayarlarEkrani.Location = new System.Drawing.Point(155, -1);
            this.pcb_ayarlarEkrani.Name = "pcb_ayarlarEkrani";
            this.pcb_ayarlarEkrani.Size = new System.Drawing.Size(80, 47);
            this.pcb_ayarlarEkrani.SizeMode = System.Windows.Forms.PictureBoxSizeMode.CenterImage;
            this.pcb_ayarlarEkrani.TabIndex = 6;
            this.pcb_ayarlarEkrani.TabStop = false;
            this.pcb_ayarlarEkrani.Click += new System.EventHandler(this.pcb_ayarlarEkrani_Click);
            // 
            // label3
            // 
            this.label3.Font = new System.Drawing.Font("Century Gothic", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label3.ForeColor = System.Drawing.Color.White;
            this.label3.Location = new System.Drawing.Point(8, 0);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(141, 45);
            this.label3.TabIndex = 4;
            this.label3.Text = "Ayarlar ekranına erişim";
            this.label3.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // imageList
            // 
            this.imageList.ImageStream = ((System.Windows.Forms.ImageListStreamer)(resources.GetObject("imageList.ImageStream")));
            this.imageList.TransparentColor = System.Drawing.Color.Transparent;
            this.imageList.Images.SetKeyName(0, "off.png");
            this.imageList.Images.SetKeyName(1, "on.png");
            // 
            // YonetimYetkileriDuzenlemeForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(49)))), ((int)(((byte)(49)))), ((int)(((byte)(49)))));
            this.ClientSize = new System.Drawing.Size(800, 435);
            this.Controls.Add(this.panel4);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.panel3);
            this.Controls.Add(this.panel1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "YonetimYetkileriDuzenlemeForm";
            this.Text = "YonetimYetkileriDuzenlemeForm";
            this.Load += new System.EventHandler(this.YonetimYetkileriDuzenlemeForm_Load);
            this.panel1.ResumeLayout(false);
            this.panel10.ResumeLayout(false);
            this.panel3.ResumeLayout(false);
            this.panel3.PerformLayout();
            this.panel4.ResumeLayout(false);
            this.panel17.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.pcb_Urun)).EndInit();
            this.panel12.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.pcb_Modul)).EndInit();
            this.panel13.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.pcb_Telegram)).EndInit();
            this.panel14.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.pcb_RaporGoruntuleme)).EndInit();
            this.panel6.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.pcb_BayiGoruntuleme)).EndInit();
            this.panel7.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.pcb_SiparisIptalEtme)).EndInit();
            this.panel11.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.pcb_YapilacaklarListesindenSilme)).EndInit();
            this.panel9.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.pcb_YapilacaklarListesineEkleme)).EndInit();
            this.panel8.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.pcb_YonetimEklemeGuncelleme)).EndInit();
            this.panel5.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.pcb_ayarlarEkrani)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Label lbl_Header;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.Panel panel10;
        private System.Windows.Forms.Button btn_Exit;
        private System.Windows.Forms.Panel panel3;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox txb_RestoranAdi;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Panel panel4;
        private System.Windows.Forms.Panel panel5;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Panel panel17;
        private System.Windows.Forms.PictureBox pcb_Urun;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.Panel panel12;
        private System.Windows.Forms.PictureBox pcb_Modul;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Panel panel13;
        private System.Windows.Forms.PictureBox pcb_Telegram;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Panel panel14;
        private System.Windows.Forms.PictureBox pcb_RaporGoruntuleme;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Panel panel6;
        private System.Windows.Forms.PictureBox pcb_BayiGoruntuleme;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Panel panel7;
        private System.Windows.Forms.PictureBox pcb_SiparisIptalEtme;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Panel panel11;
        private System.Windows.Forms.PictureBox pcb_YapilacaklarListesindenSilme;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Panel panel9;
        private System.Windows.Forms.PictureBox pcb_YapilacaklarListesineEkleme;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Panel panel8;
        private System.Windows.Forms.PictureBox pcb_YonetimEklemeGuncelleme;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.PictureBox pcb_ayarlarEkrani;
        private System.Windows.Forms.Button btn_Guncelle;
        public System.Windows.Forms.ImageList imageList;
    }
}