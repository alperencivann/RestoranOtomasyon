﻿using Mail.Forms;
using RestoranOtomasyon.Functions;
using RestoranOtomasyon.Objects;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace RestoranOtomasyon.Forms
{
    public partial class ModulDuzenlemeEkrani : Form
    {

        // GLOBAL VARIABLES
        int id;
        string modulAdi;
        string modulKey;
        bool aktiflik;


        // CONSTRUCTOR AND LOAD EVENT
        public ModulDuzenlemeEkrani(string modulAdi)
        {
            InitializeComponent();
            this.modulAdi = modulAdi;
        }

        private void ModulDuzenlemeEkrani_Load(object sender, EventArgs e)
        {
            txb_ModulAdi.Text = modulAdi;
            Database database = new Database();
            ModulObject modul = database.getModulFromName(modulAdi);
            txb_ModulKey.Text = modul.ModulKey;
            if (modul.Aktiflik)
                cbx_Aktiflik.SelectedItem = "Aktif";
            else
                cbx_Aktiflik.SelectedItem = "Pasif";
        }

        // FUNCS 
        public void Message(string msg)
        {
            MyMessageBox messageBox = new MyMessageBox(msg);
            messageBox.ShowDialog();
        }


        // EVENTS
        private void btn_Guncelle_Click(object sender, EventArgs e)
        {
            ModulObject modul = new ModulObject();
            modul.ModulAdi = modulAdi;
            modul.Aktiflik = cbx_Aktiflik.Text == "Aktif" ? true : false;
            modul.ModulKey = txb_ModulKey.Text;
            if (modul.ModulKey.Length != 19)
            {
                Message("Lütfen geçerli bir modül key giriniz.");
            }
            else
            {
                Database database = new Database();
                string result = database.updateModul(modul);
                Message(result);
                this.Close();
            }

        }

        private void btn_Exit_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void btn_Iptal_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
