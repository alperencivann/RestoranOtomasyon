﻿using Mail.Forms;
using RestoranOtomasyon.Functions;
using RestoranOtomasyon.Objects;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations.Schema;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace RestoranOtomasyon.Forms
{
    public partial class RezerveEt : Form
    {
		// GLOBBAL VARIABLES
		List<MasaKategoriObject> kategoriler = new List<MasaKategoriObject>();
		List<MasaObject> masalar = new List<MasaObject>();
		public int secilenKategoriId = 0;
		public int secilenMasaId = 0;
		int rezervasyonId;
        // CONSTRUCTOR AND LOAD EVENT
        public RezerveEt(int id = 0)
        {
            InitializeComponent();
            this.rezervasyonId = id;
        }
        
        private void RezerveEt_Load(object sender, EventArgs e)
        {
			
			if (rezervasyonId == 0)
            {
                loadMasaKategorileri();
			}
            else
            {
                Database dbRez = new Database();
                RezervasyonObject rezervasyon = dbRez.getRezervasyon(rezervasyonId);
                loadGecmisRezervasyonlar(rezervasyon.IsimSoyisim, rezervasyon.RezervasyonTelefonNo);

				Database dbMasa = new Database();
                MasaObject masa = dbMasa.getMasa(rezervasyon.MasaId);
				cbx_MasaNumarasi.Text = masa.MasaNo;
                loadMasaKategorileri(masa.KategoriId,masa.Id);
                txb_IsimSoyisim.Text = rezervasyon.IsimSoyisim;
                txb_TelefonNumarasi.Text = rezervasyon.RezervasyonTelefonNo;
                dtp_RezervasyonSaati.Value = rezervasyon.RezervasyonOlusturmaTarihi;
                
			}
            
        }
        // FUNCTIONS
        public void Message(string message)
        {
            MyMessageBox myMessageBox= new MyMessageBox(message);
            myMessageBox.ShowDialog();
        }
        public void loadMasaKategorileri(int selectedCategoryId = 0, int selectedMasaId = 0)
        {
			Database database = new Database();
			var kategories = database.listMasaKategori();
			if (selectedCategoryId == 0)
            {	
                foreach (var category in kategories)
                {
                    cbx_kategori.Items.Add(category.KategoriAdi);
                }
			}
            else
            {
                string selectedKategori = "";
                foreach (var kategori in kategories)
                {
                    if (kategori.Id == selectedCategoryId)
                    {
                        selectedKategori = kategori.KategoriAdi;
                        loadMasalar(kategori.Id, selectedMasaId);
                    }
                    cbx_kategori.Items.Add(kategori.KategoriAdi);
                }
                cbx_kategori.SelectedItem = selectedKategori;

			}
			
		}
        public void loadMasalar(int kategoriId, int masaId = 0)
        {
            Database db = new Database();
            var masalar = db.listMasaWithCategory(kategoriId);
            string selectedMasaNo = "";
            foreach (var masa in masalar)
            {
				cbx_MasaNumarasi.Items.Add(masa.MasaNo);
				if (masaId != 0 && masa.Id == masaId)
                {
                    selectedMasaNo = masa.MasaNo;
                }
            }
            cbx_MasaNumarasi.SelectedItem = selectedMasaNo;
        }
        public void loadGecmisRezervasyonlar(string isimSoyisim, string telefonNumarasi)
        {
            var db = new Database();
            List<RezervasyonObject> gecmisRezervasyonlar = db.listGecmisRezervasyonlar(isimSoyisim, telefonNumarasi);
            foreach (var rez in gecmisRezervasyonlar)
            {
                string rezDate = (rez.RezervasyonOlusturmaTarihi.Day.ToString() + "." + rez.RezervasyonOlusturmaTarihi.Month.ToString() + "." + rez.RezervasyonOlusturmaTarihi.Year.ToString() + " " + rez.RezervasyonOlusturmaTarihi.Hour.ToString() + ":" + rez.RezervasyonOlusturmaTarihi.Minute.ToString() );
                if (rez.RezervasyonDurumu == 2)
                {
					rtb_GecmisRezervasyonlar.AppendText(rez.IsimSoyisim + " | " + rez.RezervasyonTelefonNo + " | " + rezDate + " | GELDİ");
				}
                else if(rez.RezervasyonDurumu == 3)
                {
					rtb_GecmisRezervasyonlar.AppendText(rez.IsimSoyisim + " | " + rez.RezervasyonTelefonNo + " | " + rezDate + " | GELMEDİ");
				}
			}

        }

        // EVENTS
        private void cbx_kategori_SelectedIndexChanged(object sender, EventArgs e)
        {
            cbx_MasaNumarasi.Items.Clear();
            cbx_MasaNumarasi.Text = "";
            Database database = new Database();
            cbx_MasaNumarasi.Items.Clear();
            foreach (var kategori in kategoriler)
            {
                if (kategori.KategoriAdi.Contains(cbx_kategori.Text))
                {
                    secilenKategoriId = kategori.Id;
                    List<MasaObject> masaList = database.listMasaWithCategory(kategori.Id);
                    foreach (var masa in masaList)
                    {
                        masalar.Add(masa);
                        cbx_MasaNumarasi.Items.Add(masa.MasaNo);
                    }
                    break;
                }
            }
        }
        private void cbx_MasaNumarasi_SelectedIndexChanged(object sender, EventArgs e)
        {
            foreach (var masa in masalar)
            {
                if (masa.MasaNo.ToString() == cbx_MasaNumarasi.Text)
                {
                    secilenMasaId = masa.Id;
                    break;
                }
            }
        }



        private void btn_Exit_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void btn_RezervasyonuKaydet_Click(object sender, EventArgs e)
        {
            Database database = new Database();
            RezervasyonObject rezervasyon = new RezervasyonObject();
            rezervasyon.IsimSoyisim = txb_IsimSoyisim.Text;
            rezervasyon.RezervasyonTelefonNo = txb_TelefonNumarasi.Text;
            rezervasyon.RezervasyonSaati = dtp_RezervasyonSaati.Value;
            rezervasyon.KullaniciId = 0;
            rezervasyon.RezervasyonOlusturmaTarihi = DateTime.Now;
            rezervasyon.RezervasyonDurumu = 1; // 1 işlemde - 2 geldi - 3 gelmedi
			rezervasyon.MasaId = secilenMasaId;
            string err = "";
            if (rezervasyon.IsimSoyisim.Length < 1)
                err += "Lütfen isim soyisim bilgisi giriniz.";
            if (rezervasyon.RezervasyonTelefonNo.Length < 1)
				err += "\nLütfen telefon numarası bilgisi giriniz.";
            if (rezervasyon.RezervasyonSaati == null)
                err += "\nLütfen rezervasyon tarihi seçiniz.";
            if (!(rezervasyon.MasaId > 0))
                err += "\nLütfen rezerve edilecek masayı seçiniz";


            if (string.IsNullOrEmpty(err))
            {
				string result = database.insertRezervasyon(rezervasyon);
				Message(result);
                if (result.ToLower().Contains("başarılı"))
                {
                    this.Close();
                }
			}
            else
            {
                Message(err);
            }

		}

        private void btn_RezervasyonuIptalEt_Click(object sender, EventArgs e)
        {
            if (rezervasyonId != 0)
            {
                Database deleteDb = new Database();
                string result = deleteDb.deleteRezervasyon(rezervasyonId);
                Message(result);
                if (result.ToLower().Contains("başarılı"))
                {
                    this.Close();
                }
            }
            else
            {
                Message("Böyle bir kayıtlı rezervasyon bulunmamaktadır.");
            }
        }

		private void button2_Click(object sender, EventArgs e)
		{
			// 1 işlemde - 2 geldi - 3 gelmedi
			Database database = new Database();
			RezervasyonObject rezervasyon = new RezervasyonObject();
			rezervasyon.IsimSoyisim = txb_IsimSoyisim.Text;
			rezervasyon.RezervasyonTelefonNo = txb_TelefonNumarasi.Text;
			rezervasyon.RezervasyonSaati = dtp_RezervasyonSaati.Value;
			rezervasyon.KullaniciId = 0;
			rezervasyon.RezervasyonOlusturmaTarihi = DateTime.Now;
			rezervasyon.RezervasyonDurumu = 2;
			rezervasyon.MasaId = secilenMasaId;
			string result = database.updateRezervasyon(rezervasyon);
			Message(result);
			if (result.ToLower().Contains("başarılı"))
			{
				this.Close();
			}
		}

		private void button1_Click(object sender, EventArgs e)
		{
            // 1 işlemde - 2 geldi - 3 gelmedi
			Database database = new Database();
			RezervasyonObject rezervasyon = new RezervasyonObject();
			rezervasyon.IsimSoyisim = txb_IsimSoyisim.Text;
			rezervasyon.RezervasyonTelefonNo = txb_TelefonNumarasi.Text;
			rezervasyon.RezervasyonSaati = dtp_RezervasyonSaati.Value;
			rezervasyon.KullaniciId = 0;
			rezervasyon.RezervasyonOlusturmaTarihi = DateTime.Now;
			rezervasyon.RezervasyonDurumu = 3;
			rezervasyon.MasaId = secilenMasaId;
			string result = database.updateRezervasyon(rezervasyon);
			Message(result);
			if (result.ToLower().Contains("başarılı"))
			{
				this.Close();
			}
		}

		private void txb_TelefonNumarasi_KeyPress(object sender, KeyPressEventArgs e)
		{
			if (!char.IsControl(e.KeyChar) && !char.IsDigit(e.KeyChar) && (e.KeyChar != '.'))
			{
				e.Handled = true;
			}
		}
	}
}
