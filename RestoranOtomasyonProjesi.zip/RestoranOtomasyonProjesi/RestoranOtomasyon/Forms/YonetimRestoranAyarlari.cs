﻿using Mail.Forms;
using RestoranOtomasyon.Components;
using RestoranOtomasyon.Functions;
using RestoranOtomasyon.Objects;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations.Schema;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace RestoranOtomasyon.Forms
{
    public partial class YonetimRestoranAyarlari : Form
    {
        // GLOBAL VARIABLES
        GarsonEkrani garsonEkrani;

        // CONSTRUCTOR AND LOAD EVENT
        public YonetimRestoranAyarlari(GarsonEkrani garson)
        {
            InitializeComponent();
            this.garsonEkrani = garson;
        }
        private void YonetimRestoranAyarlari_Load(object sender, EventArgs e)
        {
            loadMasaKategorileri();
            loadRestoranBilgileri();
        }

        // FUNCS
        public void Message(string message)
        {
            MyMessageBox messageBox = new MyMessageBox(message);
            messageBox.Show();
        }
        public void loadRestoranBilgileri()
        {
            Database database = new Database();
            RestoranObject restoran = database.getRestoranBilgileri();
            txb_RestoranAdi.Text = restoran.RestoranAdi;
            txb_TelefonNumarasi.Text = restoran.RestoranTelefonNumarasi;
            Database dbKullanici = new Database();
            KullaniciObject kullaniciBilgileri = dbKullanici.getKullanici(restoran.RestoranYoneticiId);
            Database dbKullanicilar = new Database();
            List<KullaniciObject> kullanicilar = dbKullanicilar.listKullanicilar();
            foreach (var kullanici in kullanicilar)
            {
                cbx_Yonetici.Items.Add(kullanici.KullaniciAdi);
            }
            cbx_Yonetici.SelectedItem = kullaniciBilgileri.KullaniciAdi;
        }
        public async Task updateRestoranBilgileriAsync()
        {
            Funcs funcs = new Funcs();
            bool isPhoneNumberValid = await funcs.isValidPhoneNumber(txb_TelefonNumarasi.Text.Replace("+", "").Replace(" ",""));
            string message = "";
            bool flag = false;
            if (!(txb_RestoranAdi.Text.Length > 0))
            {
                message += "Lütfen bir restoran adı giriniz.\n";
                flag = true;
            }
            if (!isPhoneNumberValid)
            {
                message += "Lütfen geçerli bir telefon numarası giriniz.";
                flag = true;
            }

            if(!flag)
            {
                Database database = new Database();
                RestoranObject restoran = new RestoranObject();
                restoran.RestoranAdi = txb_RestoranAdi.Text;
                restoran.RestoranTelefonNumarasi = txb_TelefonNumarasi.Text;
                Database dbKullanici = new Database();
                KullaniciObject yetkili;
                if (cbx_Yonetici.Text.Length > 0)
                {
                    yetkili = dbKullanici.getKullaniciFromName(cbx_Yonetici.Text);
                    restoran.RestoranYoneticiId = yetkili.Id;
                }
                string result = database.updateRestoran(restoran);
                Message(result);
                if (result.ToLower().Contains("başarılı"))
                {
                    garsonEkrani.loadRestoran();
                }
            }
            else
            {
                Message(message);
            }
            
        }
        public void loadMasaKategorileri()
        {

            pnl_Masalar.Controls.Clear();
            Database database = new Database();
            List<MasaKategoriObject> masaKategoriObjects = database.listMasaKategori();

            foreach (var masaKategori in masaKategoriObjects)
            {
                pnl_MasaBulunmamaktadir.Visible = false;
                YonetimMasaKategori yonetimMasaKategori = new YonetimMasaKategori(masaKategori.Id, masaKategori.KategoriAdi, masaKategori.KategoriMasaSayisi, garsonEkrani, this)
                {
                    Dock = DockStyle.Top,
                    BorderStyle = BorderStyle.FixedSingle
                };
                pnl_MasaDuzenleme.Height = pnl_Masalar.Height + yonetimMasaKategori.Height;
                pnl_Masalar.Controls.Add(yonetimMasaKategori);
                Panel marginPanel = new Panel()
                {
                    Height = 5,
                    Dock = DockStyle.Top,
                    BackColor = Color.FromArgb(39, 39, 39),
                };
                pnl_Masalar.Controls.Add(marginPanel);

            }
            if (masaKategoriObjects.Count > 0)
            {
                garsonEkrani.listMasaKategori();
            }
        }
        

        private void btn_YeniKategoriEkle_Click(object sender, EventArgs e)
        {
            YeniMasaKategorisiEkleForm yeniMasaKategorisiEkleForm = new YeniMasaKategorisiEkleForm(this,garsonEkrani);
            yeniMasaKategorisiEkleForm.ShowDialog();
        }

        private void btn_Guncelle_Click(object sender, EventArgs e)
        {
            updateRestoranBilgileriAsync();
        }

        private void panel3_Paint(object sender, PaintEventArgs e)
        {

        }


        // EVENTS
    }
}
