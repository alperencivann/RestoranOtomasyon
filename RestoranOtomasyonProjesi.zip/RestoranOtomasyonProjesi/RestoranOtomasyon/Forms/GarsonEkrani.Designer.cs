﻿namespace RestoranOtomasyon.Forms
{
    partial class GarsonEkrani
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
			System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(GarsonEkrani));
			this.panel1 = new System.Windows.Forms.Panel();
			this.pnl_Ayarlar = new System.Windows.Forms.Panel();
			this.pictureBox4 = new System.Windows.Forms.PictureBox();
			this.panel4 = new System.Windows.Forms.Panel();
			this.pictureBox3 = new System.Windows.Forms.PictureBox();
			this.panel3 = new System.Windows.Forms.Panel();
			this.pictureBox2 = new System.Windows.Forms.PictureBox();
			this.panel2 = new System.Windows.Forms.Panel();
			this.pictureBox1 = new System.Windows.Forms.PictureBox();
			this.panel6 = new System.Windows.Forms.Panel();
			this.panel8 = new System.Windows.Forms.Panel();
			this.lbl_RestoranAdi = new System.Windows.Forms.Label();
			this.label4 = new System.Windows.Forms.Label();
			this.panel10 = new System.Windows.Forms.Panel();
			this.btn_Exit = new System.Windows.Forms.Button();
			this.panel7 = new System.Windows.Forms.Panel();
			this.panel5 = new System.Windows.Forms.Panel();
			this.btn_YeniRezervasyonEkle = new System.Windows.Forms.Button();
			this.flp_Tamamlanmamis = new System.Windows.Forms.FlowLayoutPanel();
			this.panel12 = new System.Windows.Forms.Panel();
			this.pnl_Tamamlanmamis = new System.Windows.Forms.Panel();
			this.lbl_TamamlanmamisRezervasyonSayisi = new System.Windows.Forms.Label();
			this.label6 = new System.Windows.Forms.Label();
			this.flp_Tamamlanan = new System.Windows.Forms.FlowLayoutPanel();
			this.pnl_Tamamlanmis = new System.Windows.Forms.Panel();
			this.panel9 = new System.Windows.Forms.Panel();
			this.lbl_TamamlanmisRezervasyonSayisi = new System.Windows.Forms.Label();
			this.label3 = new System.Windows.Forms.Label();
			this.pnl_MasaKategorileri = new System.Windows.Forms.Panel();
			this.pnl_Masalar = new System.Windows.Forms.Panel();
			this.panel1.SuspendLayout();
			this.pnl_Ayarlar.SuspendLayout();
			((System.ComponentModel.ISupportInitialize)(this.pictureBox4)).BeginInit();
			this.panel4.SuspendLayout();
			((System.ComponentModel.ISupportInitialize)(this.pictureBox3)).BeginInit();
			this.panel3.SuspendLayout();
			((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).BeginInit();
			this.panel2.SuspendLayout();
			((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
			this.panel6.SuspendLayout();
			this.panel8.SuspendLayout();
			this.panel10.SuspendLayout();
			this.panel7.SuspendLayout();
			this.panel5.SuspendLayout();
			this.flp_Tamamlanmamis.SuspendLayout();
			this.panel12.SuspendLayout();
			this.pnl_Tamamlanmamis.SuspendLayout();
			this.flp_Tamamlanan.SuspendLayout();
			this.pnl_Tamamlanmis.SuspendLayout();
			this.panel9.SuspendLayout();
			this.SuspendLayout();
			// 
			// panel1
			// 
			this.panel1.Controls.Add(this.pnl_Ayarlar);
			this.panel1.Controls.Add(this.panel4);
			this.panel1.Controls.Add(this.panel3);
			this.panel1.Controls.Add(this.panel2);
			this.panel1.Dock = System.Windows.Forms.DockStyle.Left;
			this.panel1.Location = new System.Drawing.Point(0, 0);
			this.panel1.Name = "panel1";
			this.panel1.Size = new System.Drawing.Size(80, 510);
			this.panel1.TabIndex = 0;
			// 
			// pnl_Ayarlar
			// 
			this.pnl_Ayarlar.Controls.Add(this.pictureBox4);
			this.pnl_Ayarlar.Dock = System.Windows.Forms.DockStyle.Bottom;
			this.pnl_Ayarlar.Location = new System.Drawing.Point(0, 430);
			this.pnl_Ayarlar.Name = "pnl_Ayarlar";
			this.pnl_Ayarlar.Size = new System.Drawing.Size(80, 80);
			this.pnl_Ayarlar.TabIndex = 4;
			// 
			// pictureBox4
			// 
			this.pictureBox4.Cursor = System.Windows.Forms.Cursors.Hand;
			this.pictureBox4.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox4.Image")));
			this.pictureBox4.Location = new System.Drawing.Point(12, 21);
			this.pictureBox4.Name = "pictureBox4";
			this.pictureBox4.Size = new System.Drawing.Size(60, 39);
			this.pictureBox4.SizeMode = System.Windows.Forms.PictureBoxSizeMode.AutoSize;
			this.pictureBox4.TabIndex = 1;
			this.pictureBox4.TabStop = false;
			this.pictureBox4.Click += new System.EventHandler(this.pictureBox4_Click);
			// 
			// panel4
			// 
			this.panel4.Controls.Add(this.pictureBox3);
			this.panel4.Dock = System.Windows.Forms.DockStyle.Top;
			this.panel4.Location = new System.Drawing.Point(0, 160);
			this.panel4.Name = "panel4";
			this.panel4.Size = new System.Drawing.Size(80, 80);
			this.panel4.TabIndex = 3;
			// 
			// pictureBox3
			// 
			this.pictureBox3.Cursor = System.Windows.Forms.Cursors.Hand;
			this.pictureBox3.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox3.Image")));
			this.pictureBox3.Location = new System.Drawing.Point(12, 21);
			this.pictureBox3.Name = "pictureBox3";
			this.pictureBox3.Size = new System.Drawing.Size(60, 42);
			this.pictureBox3.SizeMode = System.Windows.Forms.PictureBoxSizeMode.AutoSize;
			this.pictureBox3.TabIndex = 1;
			this.pictureBox3.TabStop = false;
			// 
			// panel3
			// 
			this.panel3.Controls.Add(this.pictureBox2);
			this.panel3.Dock = System.Windows.Forms.DockStyle.Top;
			this.panel3.Location = new System.Drawing.Point(0, 80);
			this.panel3.Name = "panel3";
			this.panel3.Size = new System.Drawing.Size(80, 80);
			this.panel3.TabIndex = 2;
			// 
			// pictureBox2
			// 
			this.pictureBox2.Cursor = System.Windows.Forms.Cursors.Hand;
			this.pictureBox2.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox2.Image")));
			this.pictureBox2.Location = new System.Drawing.Point(12, 20);
			this.pictureBox2.Name = "pictureBox2";
			this.pictureBox2.Size = new System.Drawing.Size(60, 39);
			this.pictureBox2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.AutoSize;
			this.pictureBox2.TabIndex = 1;
			this.pictureBox2.TabStop = false;
			// 
			// panel2
			// 
			this.panel2.Controls.Add(this.pictureBox1);
			this.panel2.Dock = System.Windows.Forms.DockStyle.Top;
			this.panel2.Location = new System.Drawing.Point(0, 0);
			this.panel2.Name = "panel2";
			this.panel2.Size = new System.Drawing.Size(80, 80);
			this.panel2.TabIndex = 1;
			// 
			// pictureBox1
			// 
			this.pictureBox1.Cursor = System.Windows.Forms.Cursors.Hand;
			this.pictureBox1.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox1.Image")));
			this.pictureBox1.Location = new System.Drawing.Point(12, 21);
			this.pictureBox1.Name = "pictureBox1";
			this.pictureBox1.Size = new System.Drawing.Size(60, 41);
			this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.AutoSize;
			this.pictureBox1.TabIndex = 0;
			this.pictureBox1.TabStop = false;
			// 
			// panel6
			// 
			this.panel6.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(24)))), ((int)(((byte)(24)))), ((int)(((byte)(24)))));
			this.panel6.Controls.Add(this.panel8);
			this.panel6.Controls.Add(this.panel10);
			this.panel6.Dock = System.Windows.Forms.DockStyle.Top;
			this.panel6.Location = new System.Drawing.Point(80, 0);
			this.panel6.Name = "panel6";
			this.panel6.Size = new System.Drawing.Size(698, 80);
			this.panel6.TabIndex = 1;
			// 
			// panel8
			// 
			this.panel8.Controls.Add(this.lbl_RestoranAdi);
			this.panel8.Controls.Add(this.label4);
			this.panel8.Dock = System.Windows.Forms.DockStyle.Left;
			this.panel8.Location = new System.Drawing.Point(0, 0);
			this.panel8.Name = "panel8";
			this.panel8.Size = new System.Drawing.Size(300, 80);
			this.panel8.TabIndex = 3;
			// 
			// lbl_RestoranAdi
			// 
			this.lbl_RestoranAdi.Cursor = System.Windows.Forms.Cursors.Hand;
			this.lbl_RestoranAdi.Dock = System.Windows.Forms.DockStyle.Fill;
			this.lbl_RestoranAdi.Font = new System.Drawing.Font("Century Gothic", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
			this.lbl_RestoranAdi.ForeColor = System.Drawing.Color.White;
			this.lbl_RestoranAdi.Location = new System.Drawing.Point(0, 0);
			this.lbl_RestoranAdi.Name = "lbl_RestoranAdi";
			this.lbl_RestoranAdi.Size = new System.Drawing.Size(300, 58);
			this.lbl_RestoranAdi.TabIndex = 16;
			this.lbl_RestoranAdi.Text = " Restoran Otomasyon";
			this.lbl_RestoranAdi.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
			// 
			// label4
			// 
			this.label4.Cursor = System.Windows.Forms.Cursors.Hand;
			this.label4.Dock = System.Windows.Forms.DockStyle.Bottom;
			this.label4.Font = new System.Drawing.Font("Century Gothic", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
			this.label4.ForeColor = System.Drawing.Color.Red;
			this.label4.Location = new System.Drawing.Point(0, 58);
			this.label4.Name = "label4";
			this.label4.Size = new System.Drawing.Size(300, 22);
			this.label4.TabIndex = 15;
			this.label4.Text = " Çıkış Yap";
			this.label4.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
			this.label4.Click += new System.EventHandler(this.label4_Click);
			// 
			// panel10
			// 
			this.panel10.Controls.Add(this.btn_Exit);
			this.panel10.Dock = System.Windows.Forms.DockStyle.Right;
			this.panel10.Location = new System.Drawing.Point(662, 0);
			this.panel10.Name = "panel10";
			this.panel10.Size = new System.Drawing.Size(36, 80);
			this.panel10.TabIndex = 2;
			// 
			// btn_Exit
			// 
			this.btn_Exit.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(24)))), ((int)(((byte)(24)))), ((int)(((byte)(24)))));
			this.btn_Exit.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
			this.btn_Exit.Font = new System.Drawing.Font("Century Gothic", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
			this.btn_Exit.ForeColor = System.Drawing.Color.Red;
			this.btn_Exit.Location = new System.Drawing.Point(3, 3);
			this.btn_Exit.Name = "btn_Exit";
			this.btn_Exit.Size = new System.Drawing.Size(29, 31);
			this.btn_Exit.TabIndex = 1;
			this.btn_Exit.Text = "x";
			this.btn_Exit.UseVisualStyleBackColor = false;
			this.btn_Exit.Click += new System.EventHandler(this.btn_Exit_Click);
			// 
			// panel7
			// 
			this.panel7.AutoScroll = true;
			this.panel7.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(29)))), ((int)(((byte)(29)))), ((int)(((byte)(29)))));
			this.panel7.Controls.Add(this.panel5);
			this.panel7.Controls.Add(this.flp_Tamamlanmamis);
			this.panel7.Controls.Add(this.flp_Tamamlanan);
			this.panel7.Dock = System.Windows.Forms.DockStyle.Left;
			this.panel7.Location = new System.Drawing.Point(80, 80);
			this.panel7.Name = "panel7";
			this.panel7.Size = new System.Drawing.Size(300, 430);
			this.panel7.TabIndex = 2;
			// 
			// panel5
			// 
			this.panel5.Controls.Add(this.btn_YeniRezervasyonEkle);
			this.panel5.Dock = System.Windows.Forms.DockStyle.Top;
			this.panel5.Font = new System.Drawing.Font("Century Gothic", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
			this.panel5.Location = new System.Drawing.Point(0, 104);
			this.panel5.Name = "panel5";
			this.panel5.Size = new System.Drawing.Size(300, 29);
			this.panel5.TabIndex = 3;
			// 
			// btn_YeniRezervasyonEkle
			// 
			this.btn_YeniRezervasyonEkle.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(19)))), ((int)(((byte)(19)))), ((int)(((byte)(19)))));
			this.btn_YeniRezervasyonEkle.Dock = System.Windows.Forms.DockStyle.Fill;
			this.btn_YeniRezervasyonEkle.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
			this.btn_YeniRezervasyonEkle.ForeColor = System.Drawing.Color.White;
			this.btn_YeniRezervasyonEkle.Location = new System.Drawing.Point(0, 0);
			this.btn_YeniRezervasyonEkle.Name = "btn_YeniRezervasyonEkle";
			this.btn_YeniRezervasyonEkle.Size = new System.Drawing.Size(300, 29);
			this.btn_YeniRezervasyonEkle.TabIndex = 0;
			this.btn_YeniRezervasyonEkle.Text = "Yeni Rezervasyon Ekle";
			this.btn_YeniRezervasyonEkle.UseVisualStyleBackColor = false;
			this.btn_YeniRezervasyonEkle.Click += new System.EventHandler(this.btn_YeniRezervasyonEkle_Click);
			// 
			// flp_Tamamlanmamis
			// 
			this.flp_Tamamlanmamis.Controls.Add(this.panel12);
			this.flp_Tamamlanmamis.Dock = System.Windows.Forms.DockStyle.Top;
			this.flp_Tamamlanmamis.Location = new System.Drawing.Point(0, 52);
			this.flp_Tamamlanmamis.Name = "flp_Tamamlanmamis";
			this.flp_Tamamlanmamis.Size = new System.Drawing.Size(300, 52);
			this.flp_Tamamlanmamis.TabIndex = 2;
			// 
			// panel12
			// 
			this.panel12.AutoScroll = true;
			this.panel12.Controls.Add(this.pnl_Tamamlanmamis);
			this.panel12.Location = new System.Drawing.Point(3, 3);
			this.panel12.Name = "panel12";
			this.panel12.Size = new System.Drawing.Size(291, 44);
			this.panel12.TabIndex = 0;
			// 
			// pnl_Tamamlanmamis
			// 
			this.pnl_Tamamlanmamis.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(39)))), ((int)(((byte)(39)))), ((int)(((byte)(39)))));
			this.pnl_Tamamlanmamis.Controls.Add(this.lbl_TamamlanmamisRezervasyonSayisi);
			this.pnl_Tamamlanmamis.Controls.Add(this.label6);
			this.pnl_Tamamlanmamis.Location = new System.Drawing.Point(5, 3);
			this.pnl_Tamamlanmamis.Name = "pnl_Tamamlanmamis";
			this.pnl_Tamamlanmamis.Size = new System.Drawing.Size(283, 37);
			this.pnl_Tamamlanmamis.TabIndex = 0;
			this.pnl_Tamamlanmamis.Click += new System.EventHandler(this.pnl_Tamamlanmamis_Click);
			// 
			// lbl_TamamlanmamisRezervasyonSayisi
			// 
			this.lbl_TamamlanmamisRezervasyonSayisi.Cursor = System.Windows.Forms.Cursors.Hand;
			this.lbl_TamamlanmamisRezervasyonSayisi.Dock = System.Windows.Forms.DockStyle.Right;
			this.lbl_TamamlanmamisRezervasyonSayisi.Font = new System.Drawing.Font("Bahnschrift", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
			this.lbl_TamamlanmamisRezervasyonSayisi.ForeColor = System.Drawing.Color.White;
			this.lbl_TamamlanmamisRezervasyonSayisi.Location = new System.Drawing.Point(199, 0);
			this.lbl_TamamlanmamisRezervasyonSayisi.Name = "lbl_TamamlanmamisRezervasyonSayisi";
			this.lbl_TamamlanmamisRezervasyonSayisi.Size = new System.Drawing.Size(84, 37);
			this.lbl_TamamlanmamisRezervasyonSayisi.TabIndex = 14;
			this.lbl_TamamlanmamisRezervasyonSayisi.Text = "(7)        >     ";
			this.lbl_TamamlanmamisRezervasyonSayisi.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
			// 
			// label6
			// 
			this.label6.Cursor = System.Windows.Forms.Cursors.Hand;
			this.label6.Dock = System.Windows.Forms.DockStyle.Left;
			this.label6.Font = new System.Drawing.Font("Bahnschrift", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
			this.label6.ForeColor = System.Drawing.Color.White;
			this.label6.Location = new System.Drawing.Point(0, 0);
			this.label6.Name = "label6";
			this.label6.Size = new System.Drawing.Size(140, 37);
			this.label6.TabIndex = 13;
			this.label6.Text = "      Tamamlanmamış";
			this.label6.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
			// 
			// flp_Tamamlanan
			// 
			this.flp_Tamamlanan.Controls.Add(this.pnl_Tamamlanmis);
			this.flp_Tamamlanan.Dock = System.Windows.Forms.DockStyle.Top;
			this.flp_Tamamlanan.Location = new System.Drawing.Point(0, 0);
			this.flp_Tamamlanan.Name = "flp_Tamamlanan";
			this.flp_Tamamlanan.Size = new System.Drawing.Size(300, 52);
			this.flp_Tamamlanan.TabIndex = 0;
			// 
			// pnl_Tamamlanmis
			// 
			this.pnl_Tamamlanmis.AutoScroll = true;
			this.pnl_Tamamlanmis.Controls.Add(this.panel9);
			this.pnl_Tamamlanmis.Location = new System.Drawing.Point(3, 3);
			this.pnl_Tamamlanmis.Name = "pnl_Tamamlanmis";
			this.pnl_Tamamlanmis.Size = new System.Drawing.Size(291, 44);
			this.pnl_Tamamlanmis.TabIndex = 0;
			// 
			// panel9
			// 
			this.panel9.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(39)))), ((int)(((byte)(39)))), ((int)(((byte)(39)))));
			this.panel9.Controls.Add(this.lbl_TamamlanmisRezervasyonSayisi);
			this.panel9.Controls.Add(this.label3);
			this.panel9.Location = new System.Drawing.Point(5, 3);
			this.panel9.Name = "panel9";
			this.panel9.Size = new System.Drawing.Size(283, 37);
			this.panel9.TabIndex = 0;
			this.panel9.Click += new System.EventHandler(this.panel9_Click);
			// 
			// lbl_TamamlanmisRezervasyonSayisi
			// 
			this.lbl_TamamlanmisRezervasyonSayisi.Cursor = System.Windows.Forms.Cursors.Hand;
			this.lbl_TamamlanmisRezervasyonSayisi.Dock = System.Windows.Forms.DockStyle.Right;
			this.lbl_TamamlanmisRezervasyonSayisi.Font = new System.Drawing.Font("Bahnschrift", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
			this.lbl_TamamlanmisRezervasyonSayisi.ForeColor = System.Drawing.Color.White;
			this.lbl_TamamlanmisRezervasyonSayisi.Location = new System.Drawing.Point(199, 0);
			this.lbl_TamamlanmisRezervasyonSayisi.Name = "lbl_TamamlanmisRezervasyonSayisi";
			this.lbl_TamamlanmisRezervasyonSayisi.Size = new System.Drawing.Size(84, 37);
			this.lbl_TamamlanmisRezervasyonSayisi.TabIndex = 14;
			this.lbl_TamamlanmisRezervasyonSayisi.Text = "(7)        >     ";
			this.lbl_TamamlanmisRezervasyonSayisi.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
			// 
			// label3
			// 
			this.label3.Cursor = System.Windows.Forms.Cursors.Hand;
			this.label3.Dock = System.Windows.Forms.DockStyle.Left;
			this.label3.Font = new System.Drawing.Font("Bahnschrift", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
			this.label3.ForeColor = System.Drawing.Color.White;
			this.label3.Location = new System.Drawing.Point(0, 0);
			this.label3.Name = "label3";
			this.label3.Size = new System.Drawing.Size(140, 37);
			this.label3.TabIndex = 13;
			this.label3.Text = "      Tamamlanmış";
			this.label3.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
			// 
			// pnl_MasaKategorileri
			// 
			this.pnl_MasaKategorileri.Dock = System.Windows.Forms.DockStyle.Top;
			this.pnl_MasaKategorileri.Location = new System.Drawing.Point(380, 80);
			this.pnl_MasaKategorileri.Name = "pnl_MasaKategorileri";
			this.pnl_MasaKategorileri.Size = new System.Drawing.Size(398, 55);
			this.pnl_MasaKategorileri.TabIndex = 3;
			// 
			// pnl_Masalar
			// 
			this.pnl_Masalar.AutoScroll = true;
			this.pnl_Masalar.Dock = System.Windows.Forms.DockStyle.Fill;
			this.pnl_Masalar.Location = new System.Drawing.Point(380, 135);
			this.pnl_Masalar.Margin = new System.Windows.Forms.Padding(2);
			this.pnl_Masalar.Name = "pnl_Masalar";
			this.pnl_Masalar.Size = new System.Drawing.Size(398, 375);
			this.pnl_Masalar.TabIndex = 4;
			// 
			// GarsonEkrani
			// 
			this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
			this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
			this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(29)))), ((int)(((byte)(29)))), ((int)(((byte)(29)))));
			this.ClientSize = new System.Drawing.Size(778, 510);
			this.Controls.Add(this.pnl_Masalar);
			this.Controls.Add(this.pnl_MasaKategorileri);
			this.Controls.Add(this.panel7);
			this.Controls.Add(this.panel6);
			this.Controls.Add(this.panel1);
			this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
			this.Name = "GarsonEkrani";
			this.Text = "GarsonEkrani";
			this.WindowState = System.Windows.Forms.FormWindowState.Maximized;
			this.Load += new System.EventHandler(this.GarsonEkrani_Load);
			this.panel1.ResumeLayout(false);
			this.pnl_Ayarlar.ResumeLayout(false);
			this.pnl_Ayarlar.PerformLayout();
			((System.ComponentModel.ISupportInitialize)(this.pictureBox4)).EndInit();
			this.panel4.ResumeLayout(false);
			this.panel4.PerformLayout();
			((System.ComponentModel.ISupportInitialize)(this.pictureBox3)).EndInit();
			this.panel3.ResumeLayout(false);
			this.panel3.PerformLayout();
			((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).EndInit();
			this.panel2.ResumeLayout(false);
			this.panel2.PerformLayout();
			((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
			this.panel6.ResumeLayout(false);
			this.panel8.ResumeLayout(false);
			this.panel10.ResumeLayout(false);
			this.panel7.ResumeLayout(false);
			this.panel5.ResumeLayout(false);
			this.flp_Tamamlanmamis.ResumeLayout(false);
			this.panel12.ResumeLayout(false);
			this.pnl_Tamamlanmamis.ResumeLayout(false);
			this.flp_Tamamlanan.ResumeLayout(false);
			this.pnl_Tamamlanmis.ResumeLayout(false);
			this.panel9.ResumeLayout(false);
			this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Panel pnl_Ayarlar;
        private System.Windows.Forms.Panel panel4;
        private System.Windows.Forms.Panel panel3;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.Panel panel6;
        private System.Windows.Forms.Panel panel7;
        private System.Windows.Forms.Panel pnl_MasaKategorileri;
        private System.Windows.Forms.PictureBox pictureBox4;
        private System.Windows.Forms.PictureBox pictureBox3;
        private System.Windows.Forms.PictureBox pictureBox2;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.Panel panel10;
        private System.Windows.Forms.Button btn_Exit;
        private System.Windows.Forms.FlowLayoutPanel flp_Tamamlanan;
        private System.Windows.Forms.Panel panel9;
        private System.Windows.Forms.Label lbl_TamamlanmisRezervasyonSayisi;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Panel pnl_Tamamlanmis;
        private System.Windows.Forms.FlowLayoutPanel flp_Tamamlanmamis;
        private System.Windows.Forms.Panel panel12;
        private System.Windows.Forms.Panel pnl_Tamamlanmamis;
        private System.Windows.Forms.Label lbl_TamamlanmamisRezervasyonSayisi;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Panel pnl_Masalar;
        private System.Windows.Forms.Panel panel8;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label lbl_RestoranAdi;
		private System.Windows.Forms.Panel panel5;
		private System.Windows.Forms.Button btn_YeniRezervasyonEkle;
	}
}