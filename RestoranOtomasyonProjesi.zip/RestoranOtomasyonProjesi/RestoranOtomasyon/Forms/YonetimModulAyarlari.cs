﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace RestoranOtomasyon.Forms
{
    public partial class YonetimModulAyarlari : Form
    {
        // GLOBAL FUNCS

        // CONSTRUCTOR AND LOAD EVENT
        public YonetimModulAyarlari()
        {
            InitializeComponent();
        }

        private void YonetimModulAyarlari_SizeChanged(object sender, EventArgs e)
        {
            locate();
        }
        // FUNCS
        public void modulDuzenlemeEkraniAc(string modulAdi)
        {
            ModulDuzenlemeEkrani modulDuzenlemeEkrani = new ModulDuzenlemeEkrani(modulAdi);
            modulDuzenlemeEkrani.ShowDialog();
        }
        public void locate()
        {
            int marginTop = 5;
            int marginLeft = 5;
            int marginRight = 5;
            int space = 10;
            int x = pnl_Moduller.Width - (marginLeft + marginRight);
            int xWidth = (x - space*2) / 3;
            int locX1 = marginLeft;
            int locX2 = marginLeft + xWidth + space;
            int locX3 = marginLeft + (xWidth*2) + (space*2);

            pnl_Yemeksepeti.Width = xWidth;
            pnl_Yemeksepeti.Location = new Point(locX1, marginTop);
            pnl_Getir.Width = xWidth;
            pnl_Getir.Location = new Point(locX2, marginTop);
            pnl_Trendyol.Width = xWidth;
            pnl_Trendyol.Location = new Point(locX3, marginTop);

            pnl_Telegram.Width = xWidth;
            pnl_Telegram.Location = new Point(locX1, (marginTop + pnl_Yemeksepeti.Height + marginTop));

            pnl_UrunKategori.Width = xWidth;
            pnl_UrunKategori.Location = new Point(locX2, (marginTop + pnl_Yemeksepeti.Height + marginTop));

            pnl_Bayi.Width = xWidth;
            pnl_Bayi.Location = new Point(locX3, (marginTop + pnl_Yemeksepeti.Height + marginTop));
            pnl_Bayi.Height = pnl_Telegram.Height / 2 - (marginTop/2);

            pnl_UrunKategori.Width = xWidth;
            pnl_UrunKategori.Location = new Point(locX2, (marginTop + pnl_Yemeksepeti.Height + marginTop));
            pnl_UrunKategori.Height = pnl_Telegram.Height / 2 - (marginTop / 2);

            pnl_Malzeme.Width = xWidth;
            pnl_Malzeme.Location = new Point(locX2, (marginTop + pnl_Yemeksepeti.Height + marginTop + pnl_UrunKategori.Height + marginTop));
            pnl_Malzeme.Height = pnl_Telegram.Height / 2 - (marginTop/2);

            pnl_Kullanici.Width = xWidth;
            pnl_Kullanici.Location = new Point(locX3, (marginTop + pnl_Yemeksepeti.Height + marginTop + pnl_UrunKategori.Height + marginTop));
            pnl_Kullanici.Height = pnl_Telegram.Height / 2 - (marginTop / 2);

            pnl_MasaKategori.Width = xWidth;
            pnl_MasaKategori.Location = new Point(locX1, (marginTop + pnl_Yemeksepeti.Height + marginTop + pnl_Telegram.Height + marginTop));
        }

        private void btn_Yemeksepeti_Click(object sender, EventArgs e)
        {
            modulDuzenlemeEkraniAc("Yemeksepeti");
        }

        private void btn_Getir_Click(object sender, EventArgs e)
        {
            modulDuzenlemeEkraniAc("Getir");

        }

        private void btn_Trendyol_Click(object sender, EventArgs e)
        {
            modulDuzenlemeEkraniAc("Trendyol");

        }

        private void btn_UrunKategori_Click(object sender, EventArgs e)
        {
            modulDuzenlemeEkraniAc("Ürün Kategori");

        }

        private void btn_Bayi_Click(object sender, EventArgs e)
        {
            modulDuzenlemeEkraniAc("Bayi");

        }

        private void btn_Malzeme_Click(object sender, EventArgs e)
        {
            modulDuzenlemeEkraniAc("Malzeme");

        }

        private void btn_Kullanici_Click(object sender, EventArgs e)
        {
            modulDuzenlemeEkraniAc("Kullanıcı");

        }

        private void btn_MasaKategori_Click(object sender, EventArgs e)
        {
            modulDuzenlemeEkraniAc("Masa Kategori");

        }

        private void btn_Telegram_Click(object sender, EventArgs e)
        {
            modulDuzenlemeEkraniAc("Telegram");

        }

        // EVENTS


    }
}
