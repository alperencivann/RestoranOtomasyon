﻿namespace RestoranOtomasyon.Forms
{
    partial class YeniTelegramBotuEkleForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(YeniTelegramBotuEkleForm));
            this.panel1 = new System.Windows.Forms.Panel();
            this.lbl_Header = new System.Windows.Forms.Label();
            this.panel2 = new System.Windows.Forms.Panel();
            this.panel10 = new System.Windows.Forms.Panel();
            this.btn_Exit = new System.Windows.Forms.Button();
            this.panel3 = new System.Windows.Forms.Panel();
            this.pnl_BildirimAyarlari = new System.Windows.Forms.Panel();
            this.label7 = new System.Windows.Forms.Label();
            this.panel12 = new System.Windows.Forms.Panel();
            this.label10 = new System.Windows.Forms.Label();
            this.pbx_Calisan = new System.Windows.Forms.PictureBox();
            this.panel13 = new System.Windows.Forms.Panel();
            this.label8 = new System.Windows.Forms.Label();
            this.pbx_Siparis = new System.Windows.Forms.PictureBox();
            this.panel14 = new System.Windows.Forms.Panel();
            this.label9 = new System.Windows.Forms.Label();
            this.pbx_Rezervasyon = new System.Windows.Forms.PictureBox();
            this.panel15 = new System.Windows.Forms.Panel();
            this.label11 = new System.Windows.Forms.Label();
            this.pbx_Alinacaklar = new System.Windows.Forms.PictureBox();
            this.panel16 = new System.Windows.Forms.Panel();
            this.label12 = new System.Windows.Forms.Label();
            this.pbx_Yonetim = new System.Windows.Forms.PictureBox();
            this.panel17 = new System.Windows.Forms.Panel();
            this.label13 = new System.Windows.Forms.Label();
            this.pbx_GunlukRapor = new System.Windows.Forms.PictureBox();
            this.panel9 = new System.Windows.Forms.Panel();
            this.btn_Ekle = new System.Windows.Forms.Button();
            this.btn_Iptal = new System.Windows.Forms.Button();
            this.panel7 = new System.Windows.Forms.Panel();
            this.label4 = new System.Windows.Forms.Label();
            this.panel6 = new System.Windows.Forms.Panel();
            this.txb_ChatId = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.panel5 = new System.Windows.Forms.Panel();
            this.txb_BotKey = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.panel4 = new System.Windows.Forms.Panel();
            this.label1 = new System.Windows.Forms.Label();
            this.panel11 = new System.Windows.Forms.Panel();
            this.txb_BotAdi = new System.Windows.Forms.TextBox();
            this.label5 = new System.Windows.Forms.Label();
            this.imageList1 = new System.Windows.Forms.ImageList(this.components);
            this.cbx_Kullanici = new System.Windows.Forms.ComboBox();
            this.cbx_Aktiflik = new System.Windows.Forms.ComboBox();
            this.panel1.SuspendLayout();
            this.panel10.SuspendLayout();
            this.panel3.SuspendLayout();
            this.pnl_BildirimAyarlari.SuspendLayout();
            this.panel12.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pbx_Calisan)).BeginInit();
            this.panel13.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pbx_Siparis)).BeginInit();
            this.panel14.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pbx_Rezervasyon)).BeginInit();
            this.panel15.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pbx_Alinacaklar)).BeginInit();
            this.panel16.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pbx_Yonetim)).BeginInit();
            this.panel17.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pbx_GunlukRapor)).BeginInit();
            this.panel9.SuspendLayout();
            this.panel7.SuspendLayout();
            this.panel6.SuspendLayout();
            this.panel5.SuspendLayout();
            this.panel4.SuspendLayout();
            this.panel11.SuspendLayout();
            this.SuspendLayout();
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(24)))), ((int)(((byte)(24)))), ((int)(((byte)(24)))));
            this.panel1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel1.Controls.Add(this.lbl_Header);
            this.panel1.Controls.Add(this.panel2);
            this.panel1.Controls.Add(this.panel10);
            this.panel1.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel1.Location = new System.Drawing.Point(0, 0);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(523, 50);
            this.panel1.TabIndex = 3;
            // 
            // lbl_Header
            // 
            this.lbl_Header.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(29)))), ((int)(((byte)(29)))), ((int)(((byte)(29)))));
            this.lbl_Header.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lbl_Header.Font = new System.Drawing.Font("Century Gothic", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.lbl_Header.ForeColor = System.Drawing.Color.White;
            this.lbl_Header.Location = new System.Drawing.Point(36, 0);
            this.lbl_Header.Name = "lbl_Header";
            this.lbl_Header.Size = new System.Drawing.Size(449, 48);
            this.lbl_Header.TabIndex = 5;
            this.lbl_Header.Text = "Yeni Telegram Bot Ekle";
            this.lbl_Header.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // panel2
            // 
            this.panel2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(29)))), ((int)(((byte)(29)))), ((int)(((byte)(29)))));
            this.panel2.Dock = System.Windows.Forms.DockStyle.Left;
            this.panel2.Location = new System.Drawing.Point(0, 0);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(36, 48);
            this.panel2.TabIndex = 4;
            // 
            // panel10
            // 
            this.panel10.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(29)))), ((int)(((byte)(29)))), ((int)(((byte)(29)))));
            this.panel10.Controls.Add(this.btn_Exit);
            this.panel10.Dock = System.Windows.Forms.DockStyle.Right;
            this.panel10.Location = new System.Drawing.Point(485, 0);
            this.panel10.Name = "panel10";
            this.panel10.Size = new System.Drawing.Size(36, 48);
            this.panel10.TabIndex = 3;
            // 
            // btn_Exit
            // 
            this.btn_Exit.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(24)))), ((int)(((byte)(24)))), ((int)(((byte)(24)))));
            this.btn_Exit.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_Exit.Font = new System.Drawing.Font("Century Gothic", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.btn_Exit.ForeColor = System.Drawing.Color.Red;
            this.btn_Exit.Location = new System.Drawing.Point(4, 9);
            this.btn_Exit.Name = "btn_Exit";
            this.btn_Exit.Size = new System.Drawing.Size(29, 31);
            this.btn_Exit.TabIndex = 1;
            this.btn_Exit.Text = "x";
            this.btn_Exit.UseVisualStyleBackColor = false;
            this.btn_Exit.Click += new System.EventHandler(this.btn_Exit_Click);
            // 
            // panel3
            // 
            this.panel3.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(29)))), ((int)(((byte)(29)))), ((int)(((byte)(29)))));
            this.panel3.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel3.Controls.Add(this.pnl_BildirimAyarlari);
            this.panel3.Controls.Add(this.panel9);
            this.panel3.Controls.Add(this.panel7);
            this.panel3.Controls.Add(this.panel6);
            this.panel3.Controls.Add(this.panel5);
            this.panel3.Controls.Add(this.panel4);
            this.panel3.Controls.Add(this.panel11);
            this.panel3.Location = new System.Drawing.Point(4, 55);
            this.panel3.Name = "panel3";
            this.panel3.Size = new System.Drawing.Size(515, 350);
            this.panel3.TabIndex = 5;
            // 
            // pnl_BildirimAyarlari
            // 
            this.pnl_BildirimAyarlari.Controls.Add(this.label7);
            this.pnl_BildirimAyarlari.Controls.Add(this.panel12);
            this.pnl_BildirimAyarlari.Controls.Add(this.panel13);
            this.pnl_BildirimAyarlari.Controls.Add(this.panel14);
            this.pnl_BildirimAyarlari.Controls.Add(this.panel15);
            this.pnl_BildirimAyarlari.Controls.Add(this.panel16);
            this.pnl_BildirimAyarlari.Controls.Add(this.panel17);
            this.pnl_BildirimAyarlari.Dock = System.Windows.Forms.DockStyle.Top;
            this.pnl_BildirimAyarlari.Location = new System.Drawing.Point(0, 165);
            this.pnl_BildirimAyarlari.Name = "pnl_BildirimAyarlari";
            this.pnl_BildirimAyarlari.Size = new System.Drawing.Size(513, 142);
            this.pnl_BildirimAyarlari.TabIndex = 22;
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("Century Gothic", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label7.ForeColor = System.Drawing.Color.White;
            this.label7.Location = new System.Drawing.Point(21, 13);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(114, 16);
            this.label7.TabIndex = 13;
            this.label7.Text = "Bildirim Ayarları";
            // 
            // panel12
            // 
            this.panel12.BackColor = System.Drawing.Color.White;
            this.panel12.Controls.Add(this.label10);
            this.panel12.Controls.Add(this.pbx_Calisan);
            this.panel12.Location = new System.Drawing.Point(259, 108);
            this.panel12.Name = "panel12";
            this.panel12.Size = new System.Drawing.Size(230, 32);
            this.panel12.TabIndex = 20;
            // 
            // label10
            // 
            this.label10.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.label10.Font = new System.Drawing.Font("Century Gothic", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label10.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(29)))), ((int)(((byte)(29)))), ((int)(((byte)(29)))));
            this.label10.Location = new System.Drawing.Point(33, 3);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(194, 24);
            this.label10.TabIndex = 16;
            this.label10.Text = "Çalışan Maaş Bildirimleri";
            this.label10.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // pbx_Calisan
            // 
            this.pbx_Calisan.Image = ((System.Drawing.Image)(resources.GetObject("pbx_Calisan.Image")));
            this.pbx_Calisan.Location = new System.Drawing.Point(3, 3);
            this.pbx_Calisan.Name = "pbx_Calisan";
            this.pbx_Calisan.Size = new System.Drawing.Size(26, 26);
            this.pbx_Calisan.SizeMode = System.Windows.Forms.PictureBoxSizeMode.CenterImage;
            this.pbx_Calisan.TabIndex = 15;
            this.pbx_Calisan.TabStop = false;
            this.pbx_Calisan.Click += new System.EventHandler(this.pbx_Calisan_Click);
            // 
            // panel13
            // 
            this.panel13.BackColor = System.Drawing.Color.White;
            this.panel13.Controls.Add(this.label8);
            this.panel13.Controls.Add(this.pbx_Siparis);
            this.panel13.Location = new System.Drawing.Point(24, 32);
            this.panel13.Name = "panel13";
            this.panel13.Size = new System.Drawing.Size(230, 32);
            this.panel13.TabIndex = 14;
            // 
            // label8
            // 
            this.label8.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.label8.Font = new System.Drawing.Font("Century Gothic", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label8.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(29)))), ((int)(((byte)(29)))), ((int)(((byte)(29)))));
            this.label8.Location = new System.Drawing.Point(33, 3);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(194, 24);
            this.label8.TabIndex = 16;
            this.label8.Text = "Sipariş Bildirimleri";
            this.label8.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // pbx_Siparis
            // 
            this.pbx_Siparis.Image = ((System.Drawing.Image)(resources.GetObject("pbx_Siparis.Image")));
            this.pbx_Siparis.Location = new System.Drawing.Point(3, 3);
            this.pbx_Siparis.Name = "pbx_Siparis";
            this.pbx_Siparis.Size = new System.Drawing.Size(26, 26);
            this.pbx_Siparis.SizeMode = System.Windows.Forms.PictureBoxSizeMode.CenterImage;
            this.pbx_Siparis.TabIndex = 15;
            this.pbx_Siparis.TabStop = false;
            this.pbx_Siparis.Click += new System.EventHandler(this.pbx_Siparis_Click);
            // 
            // panel14
            // 
            this.panel14.BackColor = System.Drawing.Color.White;
            this.panel14.Controls.Add(this.label9);
            this.panel14.Controls.Add(this.pbx_Rezervasyon);
            this.panel14.Location = new System.Drawing.Point(24, 108);
            this.panel14.Name = "panel14";
            this.panel14.Size = new System.Drawing.Size(230, 32);
            this.panel14.TabIndex = 17;
            // 
            // label9
            // 
            this.label9.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.label9.Font = new System.Drawing.Font("Century Gothic", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label9.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(29)))), ((int)(((byte)(29)))), ((int)(((byte)(29)))));
            this.label9.Location = new System.Drawing.Point(33, 3);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(194, 24);
            this.label9.TabIndex = 16;
            this.label9.Text = "Rezervasyon Bildirimleri";
            this.label9.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // pbx_Rezervasyon
            // 
            this.pbx_Rezervasyon.Image = ((System.Drawing.Image)(resources.GetObject("pbx_Rezervasyon.Image")));
            this.pbx_Rezervasyon.Location = new System.Drawing.Point(3, 3);
            this.pbx_Rezervasyon.Name = "pbx_Rezervasyon";
            this.pbx_Rezervasyon.Size = new System.Drawing.Size(26, 26);
            this.pbx_Rezervasyon.SizeMode = System.Windows.Forms.PictureBoxSizeMode.CenterImage;
            this.pbx_Rezervasyon.TabIndex = 15;
            this.pbx_Rezervasyon.TabStop = false;
            this.pbx_Rezervasyon.Click += new System.EventHandler(this.pbx_Rezervasyon_Click);
            // 
            // panel15
            // 
            this.panel15.BackColor = System.Drawing.Color.White;
            this.panel15.Controls.Add(this.label11);
            this.panel15.Controls.Add(this.pbx_Alinacaklar);
            this.panel15.Location = new System.Drawing.Point(259, 32);
            this.panel15.Name = "panel15";
            this.panel15.Size = new System.Drawing.Size(230, 32);
            this.panel15.TabIndex = 15;
            // 
            // label11
            // 
            this.label11.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.label11.Font = new System.Drawing.Font("Century Gothic", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label11.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(29)))), ((int)(((byte)(29)))), ((int)(((byte)(29)))));
            this.label11.Location = new System.Drawing.Point(33, 3);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(194, 24);
            this.label11.TabIndex = 16;
            this.label11.Text = "Alınacaklar Listesi  Bildirimleri";
            this.label11.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // pbx_Alinacaklar
            // 
            this.pbx_Alinacaklar.Image = ((System.Drawing.Image)(resources.GetObject("pbx_Alinacaklar.Image")));
            this.pbx_Alinacaklar.Location = new System.Drawing.Point(3, 3);
            this.pbx_Alinacaklar.Name = "pbx_Alinacaklar";
            this.pbx_Alinacaklar.Size = new System.Drawing.Size(26, 26);
            this.pbx_Alinacaklar.SizeMode = System.Windows.Forms.PictureBoxSizeMode.CenterImage;
            this.pbx_Alinacaklar.TabIndex = 15;
            this.pbx_Alinacaklar.TabStop = false;
            this.pbx_Alinacaklar.Click += new System.EventHandler(this.pbx_Alinacaklar_Click);
            // 
            // panel16
            // 
            this.panel16.BackColor = System.Drawing.Color.White;
            this.panel16.Controls.Add(this.label12);
            this.panel16.Controls.Add(this.pbx_Yonetim);
            this.panel16.Location = new System.Drawing.Point(259, 70);
            this.panel16.Name = "panel16";
            this.panel16.Size = new System.Drawing.Size(230, 32);
            this.panel16.TabIndex = 19;
            // 
            // label12
            // 
            this.label12.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.label12.Font = new System.Drawing.Font("Century Gothic", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label12.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(29)))), ((int)(((byte)(29)))), ((int)(((byte)(29)))));
            this.label12.Location = new System.Drawing.Point(33, 3);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(194, 24);
            this.label12.TabIndex = 16;
            this.label12.Text = "Yönetim Ayar Bildirimleri";
            this.label12.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // pbx_Yonetim
            // 
            this.pbx_Yonetim.Image = ((System.Drawing.Image)(resources.GetObject("pbx_Yonetim.Image")));
            this.pbx_Yonetim.Location = new System.Drawing.Point(3, 3);
            this.pbx_Yonetim.Name = "pbx_Yonetim";
            this.pbx_Yonetim.Size = new System.Drawing.Size(26, 26);
            this.pbx_Yonetim.SizeMode = System.Windows.Forms.PictureBoxSizeMode.CenterImage;
            this.pbx_Yonetim.TabIndex = 15;
            this.pbx_Yonetim.TabStop = false;
            this.pbx_Yonetim.Click += new System.EventHandler(this.pbx_Yonetim_Click);
            // 
            // panel17
            // 
            this.panel17.BackColor = System.Drawing.Color.White;
            this.panel17.Controls.Add(this.label13);
            this.panel17.Controls.Add(this.pbx_GunlukRapor);
            this.panel17.Location = new System.Drawing.Point(24, 70);
            this.panel17.Name = "panel17";
            this.panel17.Size = new System.Drawing.Size(230, 32);
            this.panel17.TabIndex = 18;
            // 
            // label13
            // 
            this.label13.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.label13.Font = new System.Drawing.Font("Century Gothic", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label13.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(29)))), ((int)(((byte)(29)))), ((int)(((byte)(29)))));
            this.label13.Location = new System.Drawing.Point(33, 3);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(194, 24);
            this.label13.TabIndex = 16;
            this.label13.Text = "Günlük Rapor  Bildirimleri";
            this.label13.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // pbx_GunlukRapor
            // 
            this.pbx_GunlukRapor.Image = ((System.Drawing.Image)(resources.GetObject("pbx_GunlukRapor.Image")));
            this.pbx_GunlukRapor.Location = new System.Drawing.Point(3, 3);
            this.pbx_GunlukRapor.Name = "pbx_GunlukRapor";
            this.pbx_GunlukRapor.Size = new System.Drawing.Size(26, 26);
            this.pbx_GunlukRapor.SizeMode = System.Windows.Forms.PictureBoxSizeMode.CenterImage;
            this.pbx_GunlukRapor.TabIndex = 15;
            this.pbx_GunlukRapor.TabStop = false;
            this.pbx_GunlukRapor.Click += new System.EventHandler(this.pbx_GunlukRapor_Click);
            // 
            // panel9
            // 
            this.panel9.Controls.Add(this.btn_Ekle);
            this.panel9.Controls.Add(this.btn_Iptal);
            this.panel9.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.panel9.Location = new System.Drawing.Point(0, 309);
            this.panel9.Name = "panel9";
            this.panel9.Size = new System.Drawing.Size(513, 39);
            this.panel9.TabIndex = 13;
            // 
            // btn_Ekle
            // 
            this.btn_Ekle.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.btn_Ekle.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(2)))), ((int)(((byte)(117)))), ((int)(((byte)(252)))));
            this.btn_Ekle.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(89)))), ((int)(((byte)(89)))), ((int)(((byte)(89)))));
            this.btn_Ekle.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_Ekle.Font = new System.Drawing.Font("Century Gothic", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.btn_Ekle.ForeColor = System.Drawing.Color.White;
            this.btn_Ekle.Location = new System.Drawing.Point(24, 4);
            this.btn_Ekle.Name = "btn_Ekle";
            this.btn_Ekle.Size = new System.Drawing.Size(230, 30);
            this.btn_Ekle.TabIndex = 13;
            this.btn_Ekle.Text = "Ekle";
            this.btn_Ekle.UseVisualStyleBackColor = false;
            this.btn_Ekle.Click += new System.EventHandler(this.btn_Ekle_Click);
            // 
            // btn_Iptal
            // 
            this.btn_Iptal.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.btn_Iptal.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(2)))), ((int)(((byte)(2)))));
            this.btn_Iptal.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(89)))), ((int)(((byte)(89)))), ((int)(((byte)(89)))));
            this.btn_Iptal.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_Iptal.Font = new System.Drawing.Font("Century Gothic", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.btn_Iptal.ForeColor = System.Drawing.Color.White;
            this.btn_Iptal.Location = new System.Drawing.Point(259, 4);
            this.btn_Iptal.Name = "btn_Iptal";
            this.btn_Iptal.Size = new System.Drawing.Size(230, 30);
            this.btn_Iptal.TabIndex = 12;
            this.btn_Iptal.Text = "İptal";
            this.btn_Iptal.UseVisualStyleBackColor = false;
            this.btn_Iptal.Click += new System.EventHandler(this.btn_Iptal_Click);
            // 
            // panel7
            // 
            this.panel7.Controls.Add(this.cbx_Aktiflik);
            this.panel7.Controls.Add(this.label4);
            this.panel7.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel7.Location = new System.Drawing.Point(0, 132);
            this.panel7.Name = "panel7";
            this.panel7.Size = new System.Drawing.Size(513, 33);
            this.panel7.TabIndex = 10;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Century Gothic", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label4.ForeColor = System.Drawing.Color.White;
            this.label4.Location = new System.Drawing.Point(22, 9);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(45, 16);
            this.label4.TabIndex = 1;
            this.label4.Text = "Aktiflik";
            // 
            // panel6
            // 
            this.panel6.Controls.Add(this.txb_ChatId);
            this.panel6.Controls.Add(this.label3);
            this.panel6.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel6.Location = new System.Drawing.Point(0, 99);
            this.panel6.Name = "panel6";
            this.panel6.Size = new System.Drawing.Size(513, 33);
            this.panel6.TabIndex = 9;
            // 
            // txb_ChatId
            // 
            this.txb_ChatId.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.txb_ChatId.Font = new System.Drawing.Font("Century Gothic", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.txb_ChatId.Location = new System.Drawing.Point(153, 6);
            this.txb_ChatId.Name = "txb_ChatId";
            this.txb_ChatId.Size = new System.Drawing.Size(336, 22);
            this.txb_ChatId.TabIndex = 2;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Century Gothic", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label3.ForeColor = System.Drawing.Color.White;
            this.label3.Location = new System.Drawing.Point(22, 9);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(49, 16);
            this.label3.TabIndex = 1;
            this.label3.Text = "Chat ID";
            // 
            // panel5
            // 
            this.panel5.Controls.Add(this.txb_BotKey);
            this.panel5.Controls.Add(this.label2);
            this.panel5.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel5.Location = new System.Drawing.Point(0, 66);
            this.panel5.Name = "panel5";
            this.panel5.Size = new System.Drawing.Size(513, 33);
            this.panel5.TabIndex = 8;
            // 
            // txb_BotKey
            // 
            this.txb_BotKey.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.txb_BotKey.Font = new System.Drawing.Font("Century Gothic", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.txb_BotKey.Location = new System.Drawing.Point(153, 6);
            this.txb_BotKey.Name = "txb_BotKey";
            this.txb_BotKey.Size = new System.Drawing.Size(336, 22);
            this.txb_BotKey.TabIndex = 2;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Century Gothic", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label2.ForeColor = System.Drawing.Color.White;
            this.label2.Location = new System.Drawing.Point(22, 9);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(50, 16);
            this.label2.TabIndex = 1;
            this.label2.Text = "Bot Key";
            // 
            // panel4
            // 
            this.panel4.Controls.Add(this.cbx_Kullanici);
            this.panel4.Controls.Add(this.label1);
            this.panel4.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel4.Location = new System.Drawing.Point(0, 33);
            this.panel4.Name = "panel4";
            this.panel4.Size = new System.Drawing.Size(513, 33);
            this.panel4.TabIndex = 7;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Century Gothic", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label1.ForeColor = System.Drawing.Color.White;
            this.label1.Location = new System.Drawing.Point(22, 9);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(56, 16);
            this.label1.TabIndex = 1;
            this.label1.Text = "Kullanıcı";
            // 
            // panel11
            // 
            this.panel11.Controls.Add(this.txb_BotAdi);
            this.panel11.Controls.Add(this.label5);
            this.panel11.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel11.Location = new System.Drawing.Point(0, 0);
            this.panel11.Name = "panel11";
            this.panel11.Size = new System.Drawing.Size(513, 33);
            this.panel11.TabIndex = 6;
            // 
            // txb_BotAdi
            // 
            this.txb_BotAdi.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.txb_BotAdi.Font = new System.Drawing.Font("Century Gothic", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.txb_BotAdi.Location = new System.Drawing.Point(153, 6);
            this.txb_BotAdi.Name = "txb_BotAdi";
            this.txb_BotAdi.Size = new System.Drawing.Size(336, 22);
            this.txb_BotAdi.TabIndex = 2;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Century Gothic", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label5.ForeColor = System.Drawing.Color.White;
            this.label5.Location = new System.Drawing.Point(22, 9);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(48, 16);
            this.label5.TabIndex = 1;
            this.label5.Text = "Bot Adı";
            // 
            // imageList1
            // 
            this.imageList1.ImageStream = ((System.Windows.Forms.ImageListStreamer)(resources.GetObject("imageList1.ImageStream")));
            this.imageList1.TransparentColor = System.Drawing.Color.Transparent;
            this.imageList1.Images.SetKeyName(0, "active.png");
            this.imageList1.Images.SetKeyName(1, "deactive.png");
            // 
            // cbx_Kullanici
            // 
            this.cbx_Kullanici.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cbx_Kullanici.Font = new System.Drawing.Font("Century Gothic", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.cbx_Kullanici.FormattingEnabled = true;
            this.cbx_Kullanici.Location = new System.Drawing.Point(153, 5);
            this.cbx_Kullanici.Name = "cbx_Kullanici";
            this.cbx_Kullanici.Size = new System.Drawing.Size(336, 25);
            this.cbx_Kullanici.TabIndex = 3;
            // 
            // cbx_Aktiflik
            // 
            this.cbx_Aktiflik.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.cbx_Aktiflik.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cbx_Aktiflik.Font = new System.Drawing.Font("Century Gothic", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.cbx_Aktiflik.FormattingEnabled = true;
            this.cbx_Aktiflik.Items.AddRange(new object[] {
            "Aktif",
            "Pasif"});
            this.cbx_Aktiflik.Location = new System.Drawing.Point(153, 4);
            this.cbx_Aktiflik.Name = "cbx_Aktiflik";
            this.cbx_Aktiflik.Size = new System.Drawing.Size(336, 25);
            this.cbx_Aktiflik.TabIndex = 5;
            // 
            // YeniTelegramBotuEkleForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(39)))), ((int)(((byte)(39)))), ((int)(((byte)(39)))));
            this.ClientSize = new System.Drawing.Size(523, 410);
            this.Controls.Add(this.panel3);
            this.Controls.Add(this.panel1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "YeniTelegramBotuEkleForm";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "YeniTelegramBotuEkleForm";
            this.Load += new System.EventHandler(this.YeniTelegramBotuEkleForm_Load);
            this.panel1.ResumeLayout(false);
            this.panel10.ResumeLayout(false);
            this.panel3.ResumeLayout(false);
            this.pnl_BildirimAyarlari.ResumeLayout(false);
            this.pnl_BildirimAyarlari.PerformLayout();
            this.panel12.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.pbx_Calisan)).EndInit();
            this.panel13.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.pbx_Siparis)).EndInit();
            this.panel14.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.pbx_Rezervasyon)).EndInit();
            this.panel15.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.pbx_Alinacaklar)).EndInit();
            this.panel16.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.pbx_Yonetim)).EndInit();
            this.panel17.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.pbx_GunlukRapor)).EndInit();
            this.panel9.ResumeLayout(false);
            this.panel7.ResumeLayout(false);
            this.panel7.PerformLayout();
            this.panel6.ResumeLayout(false);
            this.panel6.PerformLayout();
            this.panel5.ResumeLayout(false);
            this.panel5.PerformLayout();
            this.panel4.ResumeLayout(false);
            this.panel4.PerformLayout();
            this.panel11.ResumeLayout(false);
            this.panel11.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Label lbl_Header;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.Panel panel10;
        private System.Windows.Forms.Button btn_Exit;
        private System.Windows.Forms.Panel panel3;
        private System.Windows.Forms.Panel panel9;
        private System.Windows.Forms.Button btn_Ekle;
        private System.Windows.Forms.Button btn_Iptal;
        private System.Windows.Forms.Panel panel7;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Panel panel6;
        private System.Windows.Forms.TextBox txb_ChatId;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Panel panel5;
        private System.Windows.Forms.TextBox txb_BotKey;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Panel panel4;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Panel panel11;
        private System.Windows.Forms.TextBox txb_BotAdi;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Panel pnl_BildirimAyarlari;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Panel panel12;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.PictureBox pbx_Calisan;
        private System.Windows.Forms.Panel panel13;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.PictureBox pbx_Siparis;
        private System.Windows.Forms.Panel panel14;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.PictureBox pbx_Rezervasyon;
        private System.Windows.Forms.Panel panel15;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.PictureBox pbx_Alinacaklar;
        private System.Windows.Forms.Panel panel16;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.PictureBox pbx_Yonetim;
        private System.Windows.Forms.Panel panel17;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.PictureBox pbx_GunlukRapor;
        private System.Windows.Forms.ImageList imageList1;
        private System.Windows.Forms.ComboBox cbx_Kullanici;
        private System.Windows.Forms.ComboBox cbx_Aktiflik;
    }
}