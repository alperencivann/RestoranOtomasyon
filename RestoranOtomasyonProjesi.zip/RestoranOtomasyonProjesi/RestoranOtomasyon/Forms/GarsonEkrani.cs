﻿using Mail.Forms;
using RestoranOtomasyon.Components;
using RestoranOtomasyon.Functions;
using RestoranOtomasyon.Objects;
using RestoranOtomasyon.Forms;
using System;
using System.Collections.Generic;
using System.Drawing;
using System.Windows.Forms;
using System.Security.Cryptography;
using System.Linq;
using Newtonsoft.Json;

namespace RestoranOtomasyon.Forms
{
    public partial class GarsonEkrani : Form
    {
		// GLOBAL VARIABLES
		List<RezervasyonObject> tamamlananRezervasyonListesi = new List<RezervasyonObject>();
		List<RezervasyonObject> tamamlanmayanRezervasyonListesi = new List<RezervasyonObject>();

		bool tamamlanmis = true;
		bool tamamlanmamis = false;
		Form1 form;
        string yetki;
        bool kategoriModulu;

        // CONSTRUCTOR AND LOAD EVENT
        public GarsonEkrani(Form1 form, string yetki)
        {

            this.form = form;
            this.yetki = yetki;
           
            InitializeComponent();
        }
		private void GarsonEkrani_Load(object sender, EventArgs e)
		{
            Database dbKategori =new Database();

            ModulObject kategori = dbKategori.getModulFromName("Masa Kategori");
            if (string.IsNullOrEmpty(kategori.ModulKey) || kategori.Aktiflik == false)
            {
				pnl_MasaKategorileri.Visible = false;
				listMasa();

			}
			else
            {
                pnl_MasaKategorileri.Visible = true;
				listMasaKategori();

            }
			loadRestoran();
			listTamamlanmisRezervasyonlar();

			if (yetki == "99")
			{
				pnl_Ayarlar.Visible = true;
				pnl_Ayarlar.Enabled = true;
			}
			else
			{
				pnl_Ayarlar.Visible = false;
				pnl_Ayarlar.Enabled = false;
			}
		}

		// FUNCS
        public void loadRestoran()
        {
            Database db = new Database();
            RestoranObject restoran = db.getRestoranBilgileri();
            lbl_RestoranAdi.Text = restoran.RestoranAdi;
        }
		public void listMasaKategori()
        {
            pnl_MasaKategorileri.Controls.Clear();
            Database db = new Database();
            List<MasaKategoriObject> Kategoriler = db.listMasaKategori();
            int x = 10;
            int y = 2;
            int masaCounter = 0;
            foreach (MasaKategoriObject kategori in Kategoriler)
            {
                MasaKategori masaKategori = new MasaKategori(kategori.Id, kategori.KategoriAdi, this);
                if (masaCounter % 6 == 0 && masaCounter!=0)
                {
                    y += masaKategori.Height + 10;
                    x = 10;
                    pnl_MasaKategorileri.Height += masaKategori.Height + 12;
                }
                masaCounter++;

                masaKategori.Location = new Point(x, y);
                x += masaKategori.Width + 10;
                masaKategori.BorderStyle = BorderStyle.FixedSingle;
                pnl_MasaKategorileri.Controls.Add(masaKategori);

            }
        }
        public void listMasa(int kategoriId = 0, string kategoriAdi = "")
        {
            pnl_Masalar.Controls.Clear();
            Database db = new Database();
            List<MasaObject> Masalar;

			if (kategoriId != 0)
            {
				Masalar = db.listMasaWithCategory(kategoriId);
			}
            else
            {
                Masalar = db.listMasa();
            }
			int x = 10;
            int y = 10;
            int masaCounter = 0;
            foreach (MasaObject masaobj in Masalar)
            {
                Database dbMasaKategori = new Database();
                MasaKategoriObject masaKategori = dbMasaKategori.getMasaKategori(masaobj.KategoriId);
                Masa masa = new Masa(masaobj.MasaNo, masaKategori.KategoriAdi, kategoriId, masaobj.Id,this);
                if (masaCounter % 6 == 0 && masaCounter != 0)
                {
                    y += masa.Height + 10;
                    x = 10;
                }
                masa.Location = new Point(x, y);
                x += masa.Width + 10;
                masaCounter += 1;
                masa.BorderStyle = BorderStyle.FixedSingle;
                pnl_Masalar.Controls.Add(masa);
            }

        }
		public void listTamamlanmisRezervasyonlar()
        {
            hideTamamlanmamisRezervasyonlar();
			tamamlananRezervasyonListesi.Clear();
			flp_Tamamlanan.Height = pnl_Tamamlanmis.Height + 4;
            Database db = new Database();
            List<RezervasyonObject> Rezervasyonlar = db.listRezervasyon(2); // 2 değeri tamamlanmamış rezervasyonları tutmaktadır
            foreach (var rez in Rezervasyonlar)
            {
                if (!(tamamlananRezervasyonListesi.Contains(rez)))
                {
					Rezervasyon rezervasyon = new Rezervasyon(rez.Id, rez.IsimSoyisim, rez.RezervasyonSaati, rez.MasaId);
					rezervasyon.Dock = DockStyle.Top;
					tamamlananRezervasyonListesi.Add(rez);
                    flp_Tamamlanan.Controls.Add(rezervasyon);
					flp_Tamamlanan.Height += rezervasyon.Height + 8;
				}
			}
            tamamlanmis = true;
			lbl_TamamlanmisRezervasyonSayisi.Text = "(" + tamamlananRezervasyonListesi.Count.ToString() + ")        >     ";
		}
		public void listTamamlanmamisRezervasyonlar()
        {
            hideTamamlanmisRezervasyonlar();
            tamamlanmayanRezervasyonListesi.Clear();
            flp_Tamamlanmamis.Height = pnl_Tamamlanmamis.Height + 4;
            Database db = new Database();
            List<RezervasyonObject> Rezervasyonlar = db.listRezervasyon(1); // 1 değeri tamamlanmamış rezervasyonları tutmaktadır
            foreach (var rez in Rezervasyonlar)
            {
                if (!(tamamlanmayanRezervasyonListesi.Contains(rez)))
                {
					Rezervasyon rezervasyon = new Rezervasyon(rez.Id, rez.IsimSoyisim, rez.RezervasyonSaati, rez.MasaId);
					rezervasyon.Dock = DockStyle.Top;
					tamamlanmayanRezervasyonListesi.Add(rez);
                    flp_Tamamlanmamis.Controls.Add(rezervasyon);
					flp_Tamamlanmamis.Height += rezervasyon.Height + 8;
                }
            }
            tamamlanmamis = true;
			lbl_TamamlanmamisRezervasyonSayisi.Text = "(" + tamamlanmayanRezervasyonListesi.Count.ToString() + ")        >     ";

		}
		public void hideTamamlanmisRezervasyonlar()
        {
            flp_Tamamlanan.Height = 52;
            tamamlanmis = false;
        }
        public void hideTamamlanmamisRezervasyonlar()
        {
            flp_Tamamlanmamis.Height = 52;
            tamamlanmamis = false;
        }


        // EVENTS
        private void btn_Exit_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void panel9_Click(object sender, EventArgs e)
        {
            if (tamamlanmis == false)
            {
                listTamamlanmisRezervasyonlar();
            }
            else
            {
                hideTamamlanmisRezervasyonlar();
            }
        }

        private void pnl_Tamamlanmamis_Click(object sender, EventArgs e)
        {
            if (tamamlanmamis == false)
            {
				listTamamlanmamisRezervasyonlar();
			}
            else
            {
                hideTamamlanmamisRezervasyonlar();
            }
		}

        private void label4_Click(object sender, EventArgs e)
        {
            this.Hide();
            form.txb_Email.Text = "E-Mail";
            form.txb_Sifre.Text = "Şifre";
            form.lbl_Info.Text = "";
            form.Show();

        }

        private void pictureBox4_Click(object sender, EventArgs e)
        {
            if (yetki == "99")
            {

                YoneticiEkrani yonetici = new YoneticiEkrani(this);
				yonetici.FormBorderStyle = FormBorderStyle.FixedSingle;
				yonetici.Text = "Yönetici Paneli";

				if (Application.OpenForms["YoneticiEkrani"] == null)
                {
					yonetici.Show();
				}
                else
                {
                    Application.OpenForms["YoneticiEkrani"].Activate();
				}
			}
            else
            {
                MyMessageBox myMessageBox = new MyMessageBox("Yönetici ekranına erişim yetkiniz bulunmamaktadır.");
                myMessageBox.Show();
            }

        }

		private void btn_YeniRezervasyonEkle_Click(object sender, EventArgs e)
		{
            RezerveEt rezerveEt = new RezerveEt();
            rezerveEt.ShowDialog();
		}
	}
}
