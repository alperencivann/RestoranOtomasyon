﻿using Mail.Forms;
using RestoranOtomasyon.Functions;
using RestoranOtomasyon.Objects;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace RestoranOtomasyon.Forms
{
    public partial class YeniBayiEkleForm : Form
    {

        // CONSTRUCTOR AND LOAD OBJECT
        public YeniBayiEkleForm()
        {
            InitializeComponent();
        }

        // FUNCTIONS
        public void loadKullanicilar()
        {
            cbx_BayiYoneticisi.Items.Clear();
            Database dbKullanicilar = new Database();
            List<KullaniciObject> kullanicilar = dbKullanicilar.listKullanicilar();
            foreach (var kullanici in kullanicilar)
            {
                cbx_BayiYoneticisi.Items.Add(kullanici.KullaniciAdi);
            }
        }
        public void Message(string message)
        {
            MyMessageBox myMessageBox = new MyMessageBox(message);
            myMessageBox.Show();
        }

        // EVENTS
        private void YeniBayiEkleForm_Load(object sender, EventArgs e)
        {
            loadKullanicilar();
        }

        private async void btn_Ekle_ClickAsync(object sender, EventArgs e)
        {
            Funcs funcs = new Funcs();
            string message = "";
            bool flag = false;
            if (txb_BayiAdi.Text.Length <= 0)
            {
                message += "Lütfen bayi adı bilgisi giriniz.\n";
                flag = true;
            }
            if (!await funcs.isValidPhoneNumber(txb_TelefonNumarasi.Text) && txb_TelefonNumarasi.Text.Length > 0)
            {
                message += "Lütfen geçerli bir telefon numarası giriniz.\n";
                flag = true;
            }
            if (string.IsNullOrEmpty(cbx_BayiYoneticisi.Text))
            {
				message += "Lütfen bir bayi yöneticisi seçiniz.\n";
				flag = true;
			}
            if (flag)
            {
                Message(message);
            }
            else
            {
                Database dbKullaniciId = new Database();
                KullaniciObject kullanici = dbKullaniciId.getKullaniciFromName(cbx_BayiYoneticisi.Text);

                Database database = new Database();
                BayiObject bayiObject = new BayiObject();
                bayiObject.BayiAdi = txb_BayiAdi.Text;
                bayiObject.BayiAdresi = txb_Adres.Text;
                bayiObject.TelefonNo = txb_TelefonNumarasi.Text;
                bayiObject.YoneticiId = kullanici.Id;

                string result = database.insertBayi(bayiObject);
                Message(result);
                this.Close();

            }
        }

        private void btn_YeniKullaniciTanimla_Click(object sender2, EventArgs e)
        {
            YeniKullaniciEkleForm yeniKullanici = new YeniKullaniciEkleForm();
            yeniKullanici.FormClosing += (sender, args) =>
            {
                loadKullanicilar();
            };
            yeniKullanici.ShowDialog();
        }

        private void btn_Iptal_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void btn_Exit_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void txb_TelefonNumarasi_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!char.IsControl(e.KeyChar) && !char.IsDigit(e.KeyChar) && (e.KeyChar != '.'))
            {
                e.Handled = true;
            }
        }
    }
}
