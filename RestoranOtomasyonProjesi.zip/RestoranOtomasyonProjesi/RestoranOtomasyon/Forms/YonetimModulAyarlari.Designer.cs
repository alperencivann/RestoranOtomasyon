﻿namespace RestoranOtomasyon.Forms
{
    partial class YonetimModulAyarlari
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(YonetimModulAyarlari));
            this.pnl_KullaniciDuzenleme = new System.Windows.Forms.Panel();
            this.pnl_Moduller = new System.Windows.Forms.Panel();
            this.panel1 = new System.Windows.Forms.Panel();
            this.panel4 = new System.Windows.Forms.Panel();
            this.panel7 = new System.Windows.Forms.Panel();
            this.label2 = new System.Windows.Forms.Label();
            this.pnl_Getir = new System.Windows.Forms.Panel();
            this.pnl_Trendyol = new System.Windows.Forms.Panel();
            this.panel9 = new System.Windows.Forms.Panel();
            this.panel10 = new System.Windows.Forms.Panel();
            this.pcb_Getir = new System.Windows.Forms.PictureBox();
            this.panel12 = new System.Windows.Forms.Panel();
            this.panel13 = new System.Windows.Forms.Panel();
            this.pcb_Trendyol = new System.Windows.Forms.PictureBox();
            this.panel14 = new System.Windows.Forms.Panel();
            this.btn_Getir = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.panel15 = new System.Windows.Forms.Panel();
            this.btn_Trendyol = new System.Windows.Forms.Button();
            this.label3 = new System.Windows.Forms.Label();
            this.panel3 = new System.Windows.Forms.Panel();
            this.pcb_Yemeksepeti = new System.Windows.Forms.PictureBox();
            this.panel5 = new System.Windows.Forms.Panel();
            this.panel8 = new System.Windows.Forms.Panel();
            this.lbl_Yemeksepeti = new System.Windows.Forms.Label();
            this.btn_Yemeksepeti = new System.Windows.Forms.Button();
            this.pnl_Yemeksepeti = new System.Windows.Forms.Panel();
            this.pnl_Telegram = new System.Windows.Forms.Panel();
            this.panel6 = new System.Windows.Forms.Panel();
            this.panel11 = new System.Windows.Forms.Panel();
            this.btn_Telegram = new System.Windows.Forms.Button();
            this.label4 = new System.Windows.Forms.Label();
            this.panel16 = new System.Windows.Forms.Panel();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.pnl_UrunKategori = new System.Windows.Forms.Panel();
            this.panel18 = new System.Windows.Forms.Panel();
            this.panel19 = new System.Windows.Forms.Panel();
            this.btn_UrunKategori = new System.Windows.Forms.Button();
            this.label5 = new System.Windows.Forms.Label();
            this.pnl_Malzeme = new System.Windows.Forms.Panel();
            this.panel21 = new System.Windows.Forms.Panel();
            this.panel22 = new System.Windows.Forms.Panel();
            this.btn_Malzeme = new System.Windows.Forms.Button();
            this.label6 = new System.Windows.Forms.Label();
            this.pnl_Bayi = new System.Windows.Forms.Panel();
            this.panel24 = new System.Windows.Forms.Panel();
            this.panel25 = new System.Windows.Forms.Panel();
            this.btn_Bayi = new System.Windows.Forms.Button();
            this.label7 = new System.Windows.Forms.Label();
            this.pnl_Kullanici = new System.Windows.Forms.Panel();
            this.panel27 = new System.Windows.Forms.Panel();
            this.panel28 = new System.Windows.Forms.Panel();
            this.btn_Kullanici = new System.Windows.Forms.Button();
            this.label8 = new System.Windows.Forms.Label();
            this.pnl_MasaKategori = new System.Windows.Forms.Panel();
            this.panel30 = new System.Windows.Forms.Panel();
            this.panel31 = new System.Windows.Forms.Panel();
            this.btn_MasaKategori = new System.Windows.Forms.Button();
            this.label9 = new System.Windows.Forms.Label();
            this.pnl_KullaniciDuzenleme.SuspendLayout();
            this.pnl_Moduller.SuspendLayout();
            this.panel7.SuspendLayout();
            this.pnl_Getir.SuspendLayout();
            this.pnl_Trendyol.SuspendLayout();
            this.panel9.SuspendLayout();
            this.panel10.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pcb_Getir)).BeginInit();
            this.panel12.SuspendLayout();
            this.panel13.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pcb_Trendyol)).BeginInit();
            this.panel14.SuspendLayout();
            this.panel15.SuspendLayout();
            this.panel3.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pcb_Yemeksepeti)).BeginInit();
            this.panel5.SuspendLayout();
            this.panel8.SuspendLayout();
            this.pnl_Yemeksepeti.SuspendLayout();
            this.pnl_Telegram.SuspendLayout();
            this.panel6.SuspendLayout();
            this.panel11.SuspendLayout();
            this.panel16.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.pnl_UrunKategori.SuspendLayout();
            this.panel18.SuspendLayout();
            this.panel19.SuspendLayout();
            this.pnl_Malzeme.SuspendLayout();
            this.panel21.SuspendLayout();
            this.panel22.SuspendLayout();
            this.pnl_Bayi.SuspendLayout();
            this.panel24.SuspendLayout();
            this.panel25.SuspendLayout();
            this.pnl_Kullanici.SuspendLayout();
            this.panel27.SuspendLayout();
            this.panel28.SuspendLayout();
            this.pnl_MasaKategori.SuspendLayout();
            this.panel30.SuspendLayout();
            this.panel31.SuspendLayout();
            this.SuspendLayout();
            // 
            // pnl_KullaniciDuzenleme
            // 
            this.pnl_KullaniciDuzenleme.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(39)))), ((int)(((byte)(39)))), ((int)(((byte)(39)))));
            this.pnl_KullaniciDuzenleme.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.pnl_KullaniciDuzenleme.Controls.Add(this.pnl_Moduller);
            this.pnl_KullaniciDuzenleme.Controls.Add(this.panel1);
            this.pnl_KullaniciDuzenleme.Controls.Add(this.panel4);
            this.pnl_KullaniciDuzenleme.Controls.Add(this.panel7);
            this.pnl_KullaniciDuzenleme.Dock = System.Windows.Forms.DockStyle.Fill;
            this.pnl_KullaniciDuzenleme.Location = new System.Drawing.Point(0, 0);
            this.pnl_KullaniciDuzenleme.Name = "pnl_KullaniciDuzenleme";
            this.pnl_KullaniciDuzenleme.Size = new System.Drawing.Size(734, 611);
            this.pnl_KullaniciDuzenleme.TabIndex = 4;
            // 
            // pnl_Moduller
            // 
            this.pnl_Moduller.AutoScroll = true;
            this.pnl_Moduller.Controls.Add(this.pnl_MasaKategori);
            this.pnl_Moduller.Controls.Add(this.pnl_Kullanici);
            this.pnl_Moduller.Controls.Add(this.pnl_Bayi);
            this.pnl_Moduller.Controls.Add(this.pnl_Malzeme);
            this.pnl_Moduller.Controls.Add(this.pnl_UrunKategori);
            this.pnl_Moduller.Controls.Add(this.pnl_Telegram);
            this.pnl_Moduller.Controls.Add(this.pnl_Trendyol);
            this.pnl_Moduller.Controls.Add(this.pnl_Getir);
            this.pnl_Moduller.Controls.Add(this.pnl_Yemeksepeti);
            this.pnl_Moduller.Dock = System.Windows.Forms.DockStyle.Fill;
            this.pnl_Moduller.Location = new System.Drawing.Point(25, 35);
            this.pnl_Moduller.Name = "pnl_Moduller";
            this.pnl_Moduller.Size = new System.Drawing.Size(682, 574);
            this.pnl_Moduller.TabIndex = 8;
            // 
            // panel1
            // 
            this.panel1.Dock = System.Windows.Forms.DockStyle.Right;
            this.panel1.Location = new System.Drawing.Point(707, 35);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(25, 574);
            this.panel1.TabIndex = 7;
            // 
            // panel4
            // 
            this.panel4.Dock = System.Windows.Forms.DockStyle.Left;
            this.panel4.Location = new System.Drawing.Point(0, 35);
            this.panel4.Name = "panel4";
            this.panel4.Size = new System.Drawing.Size(25, 574);
            this.panel4.TabIndex = 5;
            // 
            // panel7
            // 
            this.panel7.Controls.Add(this.label2);
            this.panel7.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel7.Location = new System.Drawing.Point(0, 0);
            this.panel7.Name = "panel7";
            this.panel7.Size = new System.Drawing.Size(732, 35);
            this.panel7.TabIndex = 1;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Century Gothic", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label2.ForeColor = System.Drawing.Color.White;
            this.label2.Location = new System.Drawing.Point(21, 9);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(108, 16);
            this.label2.TabIndex = 0;
            this.label2.Text = "Modül Yönetimi";
            // 
            // pnl_Getir
            // 
            this.pnl_Getir.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(29)))), ((int)(((byte)(29)))), ((int)(((byte)(29)))));
            this.pnl_Getir.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.pnl_Getir.Controls.Add(this.panel9);
            this.pnl_Getir.Controls.Add(this.panel10);
            this.pnl_Getir.Location = new System.Drawing.Point(234, 6);
            this.pnl_Getir.Name = "pnl_Getir";
            this.pnl_Getir.Size = new System.Drawing.Size(214, 178);
            this.pnl_Getir.TabIndex = 2;
            // 
            // pnl_Trendyol
            // 
            this.pnl_Trendyol.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(29)))), ((int)(((byte)(29)))), ((int)(((byte)(29)))));
            this.pnl_Trendyol.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.pnl_Trendyol.Controls.Add(this.panel12);
            this.pnl_Trendyol.Controls.Add(this.panel13);
            this.pnl_Trendyol.Location = new System.Drawing.Point(462, 6);
            this.pnl_Trendyol.Name = "pnl_Trendyol";
            this.pnl_Trendyol.Size = new System.Drawing.Size(214, 178);
            this.pnl_Trendyol.TabIndex = 2;
            // 
            // panel9
            // 
            this.panel9.Controls.Add(this.panel14);
            this.panel9.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel9.Location = new System.Drawing.Point(0, 127);
            this.panel9.Name = "panel9";
            this.panel9.Size = new System.Drawing.Size(212, 49);
            this.panel9.TabIndex = 3;
            // 
            // panel10
            // 
            this.panel10.Controls.Add(this.pcb_Getir);
            this.panel10.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel10.Location = new System.Drawing.Point(0, 0);
            this.panel10.Name = "panel10";
            this.panel10.Size = new System.Drawing.Size(212, 127);
            this.panel10.TabIndex = 2;
            // 
            // pcb_Getir
            // 
            this.pcb_Getir.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.pcb_Getir.Image = ((System.Drawing.Image)(resources.GetObject("pcb_Getir.Image")));
            this.pcb_Getir.Location = new System.Drawing.Point(15, 6);
            this.pcb_Getir.Name = "pcb_Getir";
            this.pcb_Getir.Size = new System.Drawing.Size(182, 118);
            this.pcb_Getir.SizeMode = System.Windows.Forms.PictureBoxSizeMode.CenterImage;
            this.pcb_Getir.TabIndex = 0;
            this.pcb_Getir.TabStop = false;
            // 
            // panel12
            // 
            this.panel12.Controls.Add(this.panel15);
            this.panel12.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel12.Location = new System.Drawing.Point(0, 127);
            this.panel12.Name = "panel12";
            this.panel12.Size = new System.Drawing.Size(212, 49);
            this.panel12.TabIndex = 3;
            // 
            // panel13
            // 
            this.panel13.Controls.Add(this.pcb_Trendyol);
            this.panel13.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel13.Location = new System.Drawing.Point(0, 0);
            this.panel13.Name = "panel13";
            this.panel13.Size = new System.Drawing.Size(212, 127);
            this.panel13.TabIndex = 2;
            // 
            // pcb_Trendyol
            // 
            this.pcb_Trendyol.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.pcb_Trendyol.Image = ((System.Drawing.Image)(resources.GetObject("pcb_Trendyol.Image")));
            this.pcb_Trendyol.Location = new System.Drawing.Point(15, 6);
            this.pcb_Trendyol.Name = "pcb_Trendyol";
            this.pcb_Trendyol.Size = new System.Drawing.Size(182, 118);
            this.pcb_Trendyol.SizeMode = System.Windows.Forms.PictureBoxSizeMode.CenterImage;
            this.pcb_Trendyol.TabIndex = 0;
            this.pcb_Trendyol.TabStop = false;
            // 
            // panel14
            // 
            this.panel14.Controls.Add(this.btn_Getir);
            this.panel14.Controls.Add(this.label1);
            this.panel14.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel14.Location = new System.Drawing.Point(0, 0);
            this.panel14.Name = "panel14";
            this.panel14.Size = new System.Drawing.Size(212, 49);
            this.panel14.TabIndex = 2;
            // 
            // btn_Getir
            // 
            this.btn_Getir.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.btn_Getir.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(2)))), ((int)(((byte)(117)))), ((int)(((byte)(252)))));
            this.btn_Getir.FlatAppearance.BorderSize = 0;
            this.btn_Getir.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_Getir.Font = new System.Drawing.Font("Century Gothic", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.btn_Getir.ForeColor = System.Drawing.Color.White;
            this.btn_Getir.Location = new System.Drawing.Point(15, 22);
            this.btn_Getir.Name = "btn_Getir";
            this.btn_Getir.Size = new System.Drawing.Size(182, 24);
            this.btn_Getir.TabIndex = 6;
            this.btn_Getir.Text = "Düzenle";
            this.btn_Getir.UseVisualStyleBackColor = false;
            this.btn_Getir.Click += new System.EventHandler(this.btn_Getir_Click);
            // 
            // label1
            // 
            this.label1.Dock = System.Windows.Forms.DockStyle.Top;
            this.label1.Font = new System.Drawing.Font("Century Gothic", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label1.ForeColor = System.Drawing.Color.White;
            this.label1.Location = new System.Drawing.Point(0, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(212, 18);
            this.label1.TabIndex = 0;
            this.label1.Text = "Getir Modülü";
            this.label1.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // panel15
            // 
            this.panel15.Controls.Add(this.btn_Trendyol);
            this.panel15.Controls.Add(this.label3);
            this.panel15.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel15.Location = new System.Drawing.Point(0, 0);
            this.panel15.Name = "panel15";
            this.panel15.Size = new System.Drawing.Size(212, 49);
            this.panel15.TabIndex = 2;
            // 
            // btn_Trendyol
            // 
            this.btn_Trendyol.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.btn_Trendyol.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(2)))), ((int)(((byte)(117)))), ((int)(((byte)(252)))));
            this.btn_Trendyol.FlatAppearance.BorderSize = 0;
            this.btn_Trendyol.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_Trendyol.Font = new System.Drawing.Font("Century Gothic", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.btn_Trendyol.ForeColor = System.Drawing.Color.White;
            this.btn_Trendyol.Location = new System.Drawing.Point(15, 22);
            this.btn_Trendyol.Name = "btn_Trendyol";
            this.btn_Trendyol.Size = new System.Drawing.Size(182, 24);
            this.btn_Trendyol.TabIndex = 6;
            this.btn_Trendyol.Text = "Düzenle";
            this.btn_Trendyol.UseVisualStyleBackColor = false;
            this.btn_Trendyol.Click += new System.EventHandler(this.btn_Trendyol_Click);
            // 
            // label3
            // 
            this.label3.Dock = System.Windows.Forms.DockStyle.Top;
            this.label3.Font = new System.Drawing.Font("Century Gothic", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label3.ForeColor = System.Drawing.Color.White;
            this.label3.Location = new System.Drawing.Point(0, 0);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(212, 18);
            this.label3.TabIndex = 0;
            this.label3.Text = "Trendyol Modülü";
            this.label3.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // panel3
            // 
            this.panel3.Controls.Add(this.pcb_Yemeksepeti);
            this.panel3.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel3.Location = new System.Drawing.Point(0, 0);
            this.panel3.Name = "panel3";
            this.panel3.Size = new System.Drawing.Size(212, 127);
            this.panel3.TabIndex = 0;
            // 
            // pcb_Yemeksepeti
            // 
            this.pcb_Yemeksepeti.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.pcb_Yemeksepeti.Image = ((System.Drawing.Image)(resources.GetObject("pcb_Yemeksepeti.Image")));
            this.pcb_Yemeksepeti.Location = new System.Drawing.Point(15, 6);
            this.pcb_Yemeksepeti.Name = "pcb_Yemeksepeti";
            this.pcb_Yemeksepeti.Size = new System.Drawing.Size(182, 118);
            this.pcb_Yemeksepeti.SizeMode = System.Windows.Forms.PictureBoxSizeMode.CenterImage;
            this.pcb_Yemeksepeti.TabIndex = 0;
            this.pcb_Yemeksepeti.TabStop = false;
            // 
            // panel5
            // 
            this.panel5.Controls.Add(this.panel8);
            this.panel5.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel5.Location = new System.Drawing.Point(0, 127);
            this.panel5.Name = "panel5";
            this.panel5.Size = new System.Drawing.Size(212, 49);
            this.panel5.TabIndex = 1;
            // 
            // panel8
            // 
            this.panel8.Controls.Add(this.btn_Yemeksepeti);
            this.panel8.Controls.Add(this.lbl_Yemeksepeti);
            this.panel8.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel8.Location = new System.Drawing.Point(0, 0);
            this.panel8.Name = "panel8";
            this.panel8.Size = new System.Drawing.Size(212, 49);
            this.panel8.TabIndex = 1;
            // 
            // lbl_Yemeksepeti
            // 
            this.lbl_Yemeksepeti.Dock = System.Windows.Forms.DockStyle.Top;
            this.lbl_Yemeksepeti.Font = new System.Drawing.Font("Century Gothic", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.lbl_Yemeksepeti.ForeColor = System.Drawing.Color.White;
            this.lbl_Yemeksepeti.Location = new System.Drawing.Point(0, 0);
            this.lbl_Yemeksepeti.Name = "lbl_Yemeksepeti";
            this.lbl_Yemeksepeti.Size = new System.Drawing.Size(212, 19);
            this.lbl_Yemeksepeti.TabIndex = 0;
            this.lbl_Yemeksepeti.Text = "Yemeksepeti Modülü";
            this.lbl_Yemeksepeti.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // btn_Yemeksepeti
            // 
            this.btn_Yemeksepeti.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.btn_Yemeksepeti.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(2)))), ((int)(((byte)(117)))), ((int)(((byte)(252)))));
            this.btn_Yemeksepeti.FlatAppearance.BorderSize = 0;
            this.btn_Yemeksepeti.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_Yemeksepeti.Font = new System.Drawing.Font("Century Gothic", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.btn_Yemeksepeti.ForeColor = System.Drawing.Color.White;
            this.btn_Yemeksepeti.Location = new System.Drawing.Point(15, 22);
            this.btn_Yemeksepeti.Name = "btn_Yemeksepeti";
            this.btn_Yemeksepeti.Size = new System.Drawing.Size(182, 24);
            this.btn_Yemeksepeti.TabIndex = 6;
            this.btn_Yemeksepeti.Text = "Düzenle";
            this.btn_Yemeksepeti.UseVisualStyleBackColor = false;
            this.btn_Yemeksepeti.Click += new System.EventHandler(this.btn_Yemeksepeti_Click);
            // 
            // pnl_Yemeksepeti
            // 
            this.pnl_Yemeksepeti.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(29)))), ((int)(((byte)(29)))), ((int)(((byte)(29)))));
            this.pnl_Yemeksepeti.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.pnl_Yemeksepeti.Controls.Add(this.panel5);
            this.pnl_Yemeksepeti.Controls.Add(this.panel3);
            this.pnl_Yemeksepeti.Location = new System.Drawing.Point(6, 6);
            this.pnl_Yemeksepeti.Name = "pnl_Yemeksepeti";
            this.pnl_Yemeksepeti.Size = new System.Drawing.Size(214, 178);
            this.pnl_Yemeksepeti.TabIndex = 0;
            // 
            // pnl_Telegram
            // 
            this.pnl_Telegram.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(29)))), ((int)(((byte)(29)))), ((int)(((byte)(29)))));
            this.pnl_Telegram.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.pnl_Telegram.Controls.Add(this.panel6);
            this.pnl_Telegram.Controls.Add(this.panel16);
            this.pnl_Telegram.Location = new System.Drawing.Point(6, 190);
            this.pnl_Telegram.Name = "pnl_Telegram";
            this.pnl_Telegram.Size = new System.Drawing.Size(214, 178);
            this.pnl_Telegram.TabIndex = 3;
            // 
            // panel6
            // 
            this.panel6.Controls.Add(this.panel11);
            this.panel6.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel6.Location = new System.Drawing.Point(0, 127);
            this.panel6.Name = "panel6";
            this.panel6.Size = new System.Drawing.Size(212, 49);
            this.panel6.TabIndex = 1;
            // 
            // panel11
            // 
            this.panel11.Controls.Add(this.btn_Telegram);
            this.panel11.Controls.Add(this.label4);
            this.panel11.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel11.Location = new System.Drawing.Point(0, 0);
            this.panel11.Name = "panel11";
            this.panel11.Size = new System.Drawing.Size(212, 49);
            this.panel11.TabIndex = 1;
            // 
            // btn_Telegram
            // 
            this.btn_Telegram.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.btn_Telegram.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(2)))), ((int)(((byte)(117)))), ((int)(((byte)(252)))));
            this.btn_Telegram.FlatAppearance.BorderSize = 0;
            this.btn_Telegram.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_Telegram.Font = new System.Drawing.Font("Century Gothic", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.btn_Telegram.ForeColor = System.Drawing.Color.White;
            this.btn_Telegram.Location = new System.Drawing.Point(15, 22);
            this.btn_Telegram.Name = "btn_Telegram";
            this.btn_Telegram.Size = new System.Drawing.Size(182, 24);
            this.btn_Telegram.TabIndex = 6;
            this.btn_Telegram.Text = "Düzenle";
            this.btn_Telegram.UseVisualStyleBackColor = false;
            this.btn_Telegram.Click += new System.EventHandler(this.btn_Telegram_Click);
            // 
            // label4
            // 
            this.label4.Dock = System.Windows.Forms.DockStyle.Top;
            this.label4.Font = new System.Drawing.Font("Century Gothic", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label4.ForeColor = System.Drawing.Color.White;
            this.label4.Location = new System.Drawing.Point(0, 0);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(212, 19);
            this.label4.TabIndex = 0;
            this.label4.Text = "Telegram Modülü";
            this.label4.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // panel16
            // 
            this.panel16.Controls.Add(this.pictureBox1);
            this.panel16.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel16.Location = new System.Drawing.Point(0, 0);
            this.panel16.Name = "panel16";
            this.panel16.Size = new System.Drawing.Size(212, 127);
            this.panel16.TabIndex = 0;
            // 
            // pictureBox1
            // 
            this.pictureBox1.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.pictureBox1.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox1.Image")));
            this.pictureBox1.Location = new System.Drawing.Point(15, 6);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(182, 118);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.CenterImage;
            this.pictureBox1.TabIndex = 0;
            this.pictureBox1.TabStop = false;
            // 
            // pnl_UrunKategori
            // 
            this.pnl_UrunKategori.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(29)))), ((int)(((byte)(29)))), ((int)(((byte)(29)))));
            this.pnl_UrunKategori.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.pnl_UrunKategori.Controls.Add(this.panel18);
            this.pnl_UrunKategori.Location = new System.Drawing.Point(234, 190);
            this.pnl_UrunKategori.Name = "pnl_UrunKategori";
            this.pnl_UrunKategori.Size = new System.Drawing.Size(214, 84);
            this.pnl_UrunKategori.TabIndex = 4;
            // 
            // panel18
            // 
            this.panel18.Controls.Add(this.panel19);
            this.panel18.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel18.Location = new System.Drawing.Point(0, 0);
            this.panel18.Name = "panel18";
            this.panel18.Size = new System.Drawing.Size(212, 82);
            this.panel18.TabIndex = 1;
            // 
            // panel19
            // 
            this.panel19.Controls.Add(this.btn_UrunKategori);
            this.panel19.Controls.Add(this.label5);
            this.panel19.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel19.Location = new System.Drawing.Point(0, 0);
            this.panel19.Name = "panel19";
            this.panel19.Size = new System.Drawing.Size(212, 82);
            this.panel19.TabIndex = 1;
            // 
            // btn_UrunKategori
            // 
            this.btn_UrunKategori.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.btn_UrunKategori.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(2)))), ((int)(((byte)(117)))), ((int)(((byte)(252)))));
            this.btn_UrunKategori.FlatAppearance.BorderSize = 0;
            this.btn_UrunKategori.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_UrunKategori.Font = new System.Drawing.Font("Century Gothic", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.btn_UrunKategori.ForeColor = System.Drawing.Color.White;
            this.btn_UrunKategori.Location = new System.Drawing.Point(15, 55);
            this.btn_UrunKategori.Name = "btn_UrunKategori";
            this.btn_UrunKategori.Size = new System.Drawing.Size(182, 24);
            this.btn_UrunKategori.TabIndex = 6;
            this.btn_UrunKategori.Text = "Düzenle";
            this.btn_UrunKategori.UseVisualStyleBackColor = false;
            this.btn_UrunKategori.Click += new System.EventHandler(this.btn_UrunKategori_Click);
            // 
            // label5
            // 
            this.label5.Dock = System.Windows.Forms.DockStyle.Top;
            this.label5.Font = new System.Drawing.Font("Century Gothic", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label5.ForeColor = System.Drawing.Color.White;
            this.label5.Location = new System.Drawing.Point(0, 0);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(212, 52);
            this.label5.TabIndex = 0;
            this.label5.Text = "Ürün Kategori Modülü";
            this.label5.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // pnl_Malzeme
            // 
            this.pnl_Malzeme.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(29)))), ((int)(((byte)(29)))), ((int)(((byte)(29)))));
            this.pnl_Malzeme.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.pnl_Malzeme.Controls.Add(this.panel21);
            this.pnl_Malzeme.Location = new System.Drawing.Point(234, 284);
            this.pnl_Malzeme.Name = "pnl_Malzeme";
            this.pnl_Malzeme.Size = new System.Drawing.Size(214, 84);
            this.pnl_Malzeme.TabIndex = 5;
            // 
            // panel21
            // 
            this.panel21.Controls.Add(this.panel22);
            this.panel21.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel21.Location = new System.Drawing.Point(0, 0);
            this.panel21.Name = "panel21";
            this.panel21.Size = new System.Drawing.Size(212, 82);
            this.panel21.TabIndex = 1;
            // 
            // panel22
            // 
            this.panel22.Controls.Add(this.btn_Malzeme);
            this.panel22.Controls.Add(this.label6);
            this.panel22.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel22.Location = new System.Drawing.Point(0, 0);
            this.panel22.Name = "panel22";
            this.panel22.Size = new System.Drawing.Size(212, 82);
            this.panel22.TabIndex = 1;
            // 
            // btn_Malzeme
            // 
            this.btn_Malzeme.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.btn_Malzeme.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(2)))), ((int)(((byte)(117)))), ((int)(((byte)(252)))));
            this.btn_Malzeme.FlatAppearance.BorderSize = 0;
            this.btn_Malzeme.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_Malzeme.Font = new System.Drawing.Font("Century Gothic", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.btn_Malzeme.ForeColor = System.Drawing.Color.White;
            this.btn_Malzeme.Location = new System.Drawing.Point(15, 55);
            this.btn_Malzeme.Name = "btn_Malzeme";
            this.btn_Malzeme.Size = new System.Drawing.Size(182, 24);
            this.btn_Malzeme.TabIndex = 6;
            this.btn_Malzeme.Text = "Düzenle";
            this.btn_Malzeme.UseVisualStyleBackColor = false;
            this.btn_Malzeme.Click += new System.EventHandler(this.btn_Malzeme_Click);
            // 
            // label6
            // 
            this.label6.Dock = System.Windows.Forms.DockStyle.Top;
            this.label6.Font = new System.Drawing.Font("Century Gothic", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label6.ForeColor = System.Drawing.Color.White;
            this.label6.Location = new System.Drawing.Point(0, 0);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(212, 52);
            this.label6.TabIndex = 0;
            this.label6.Text = "Malzeme Modülü";
            this.label6.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // pnl_Bayi
            // 
            this.pnl_Bayi.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(29)))), ((int)(((byte)(29)))), ((int)(((byte)(29)))));
            this.pnl_Bayi.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.pnl_Bayi.Controls.Add(this.panel24);
            this.pnl_Bayi.Location = new System.Drawing.Point(462, 190);
            this.pnl_Bayi.Name = "pnl_Bayi";
            this.pnl_Bayi.Size = new System.Drawing.Size(214, 84);
            this.pnl_Bayi.TabIndex = 6;
            // 
            // panel24
            // 
            this.panel24.Controls.Add(this.panel25);
            this.panel24.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel24.Location = new System.Drawing.Point(0, 0);
            this.panel24.Name = "panel24";
            this.panel24.Size = new System.Drawing.Size(212, 82);
            this.panel24.TabIndex = 1;
            // 
            // panel25
            // 
            this.panel25.Controls.Add(this.btn_Bayi);
            this.panel25.Controls.Add(this.label7);
            this.panel25.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel25.Location = new System.Drawing.Point(0, 0);
            this.panel25.Name = "panel25";
            this.panel25.Size = new System.Drawing.Size(212, 82);
            this.panel25.TabIndex = 1;
            // 
            // btn_Bayi
            // 
            this.btn_Bayi.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.btn_Bayi.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(2)))), ((int)(((byte)(117)))), ((int)(((byte)(252)))));
            this.btn_Bayi.FlatAppearance.BorderSize = 0;
            this.btn_Bayi.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_Bayi.Font = new System.Drawing.Font("Century Gothic", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.btn_Bayi.ForeColor = System.Drawing.Color.White;
            this.btn_Bayi.Location = new System.Drawing.Point(15, 55);
            this.btn_Bayi.Name = "btn_Bayi";
            this.btn_Bayi.Size = new System.Drawing.Size(182, 24);
            this.btn_Bayi.TabIndex = 6;
            this.btn_Bayi.Text = "Düzenle";
            this.btn_Bayi.UseVisualStyleBackColor = false;
            this.btn_Bayi.Click += new System.EventHandler(this.btn_Bayi_Click);
            // 
            // label7
            // 
            this.label7.Dock = System.Windows.Forms.DockStyle.Top;
            this.label7.Font = new System.Drawing.Font("Century Gothic", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label7.ForeColor = System.Drawing.Color.White;
            this.label7.Location = new System.Drawing.Point(0, 0);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(212, 52);
            this.label7.TabIndex = 0;
            this.label7.Text = "Bayi Modülü";
            this.label7.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // pnl_Kullanici
            // 
            this.pnl_Kullanici.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(29)))), ((int)(((byte)(29)))), ((int)(((byte)(29)))));
            this.pnl_Kullanici.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.pnl_Kullanici.Controls.Add(this.panel27);
            this.pnl_Kullanici.Location = new System.Drawing.Point(462, 284);
            this.pnl_Kullanici.Name = "pnl_Kullanici";
            this.pnl_Kullanici.Size = new System.Drawing.Size(214, 84);
            this.pnl_Kullanici.TabIndex = 6;
            // 
            // panel27
            // 
            this.panel27.Controls.Add(this.panel28);
            this.panel27.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel27.Location = new System.Drawing.Point(0, 0);
            this.panel27.Name = "panel27";
            this.panel27.Size = new System.Drawing.Size(212, 82);
            this.panel27.TabIndex = 1;
            // 
            // panel28
            // 
            this.panel28.Controls.Add(this.btn_Kullanici);
            this.panel28.Controls.Add(this.label8);
            this.panel28.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel28.Location = new System.Drawing.Point(0, 0);
            this.panel28.Name = "panel28";
            this.panel28.Size = new System.Drawing.Size(212, 82);
            this.panel28.TabIndex = 1;
            // 
            // btn_Kullanici
            // 
            this.btn_Kullanici.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.btn_Kullanici.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(2)))), ((int)(((byte)(117)))), ((int)(((byte)(252)))));
            this.btn_Kullanici.FlatAppearance.BorderSize = 0;
            this.btn_Kullanici.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_Kullanici.Font = new System.Drawing.Font("Century Gothic", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.btn_Kullanici.ForeColor = System.Drawing.Color.White;
            this.btn_Kullanici.Location = new System.Drawing.Point(15, 55);
            this.btn_Kullanici.Name = "btn_Kullanici";
            this.btn_Kullanici.Size = new System.Drawing.Size(182, 24);
            this.btn_Kullanici.TabIndex = 6;
            this.btn_Kullanici.Text = "Düzenle";
            this.btn_Kullanici.UseVisualStyleBackColor = false;
            this.btn_Kullanici.Click += new System.EventHandler(this.btn_Kullanici_Click);
            // 
            // label8
            // 
            this.label8.Dock = System.Windows.Forms.DockStyle.Top;
            this.label8.Font = new System.Drawing.Font("Century Gothic", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label8.ForeColor = System.Drawing.Color.White;
            this.label8.Location = new System.Drawing.Point(0, 0);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(212, 52);
            this.label8.TabIndex = 0;
            this.label8.Text = "Kullanıcı Modülü";
            this.label8.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // pnl_MasaKategori
            // 
            this.pnl_MasaKategori.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(29)))), ((int)(((byte)(29)))), ((int)(((byte)(29)))));
            this.pnl_MasaKategori.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.pnl_MasaKategori.Controls.Add(this.panel30);
            this.pnl_MasaKategori.Location = new System.Drawing.Point(6, 374);
            this.pnl_MasaKategori.Name = "pnl_MasaKategori";
            this.pnl_MasaKategori.Size = new System.Drawing.Size(214, 84);
            this.pnl_MasaKategori.TabIndex = 7;
            // 
            // panel30
            // 
            this.panel30.Controls.Add(this.panel31);
            this.panel30.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel30.Location = new System.Drawing.Point(0, 0);
            this.panel30.Name = "panel30";
            this.panel30.Size = new System.Drawing.Size(212, 82);
            this.panel30.TabIndex = 1;
            // 
            // panel31
            // 
            this.panel31.Controls.Add(this.btn_MasaKategori);
            this.panel31.Controls.Add(this.label9);
            this.panel31.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel31.Location = new System.Drawing.Point(0, 0);
            this.panel31.Name = "panel31";
            this.panel31.Size = new System.Drawing.Size(212, 82);
            this.panel31.TabIndex = 1;
            // 
            // btn_MasaKategori
            // 
            this.btn_MasaKategori.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.btn_MasaKategori.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(2)))), ((int)(((byte)(117)))), ((int)(((byte)(252)))));
            this.btn_MasaKategori.FlatAppearance.BorderSize = 0;
            this.btn_MasaKategori.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_MasaKategori.Font = new System.Drawing.Font("Century Gothic", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.btn_MasaKategori.ForeColor = System.Drawing.Color.White;
            this.btn_MasaKategori.Location = new System.Drawing.Point(15, 55);
            this.btn_MasaKategori.Name = "btn_MasaKategori";
            this.btn_MasaKategori.Size = new System.Drawing.Size(182, 24);
            this.btn_MasaKategori.TabIndex = 6;
            this.btn_MasaKategori.Text = "Düzenle";
            this.btn_MasaKategori.UseVisualStyleBackColor = false;
            this.btn_MasaKategori.Click += new System.EventHandler(this.btn_MasaKategori_Click);
            // 
            // label9
            // 
            this.label9.Dock = System.Windows.Forms.DockStyle.Top;
            this.label9.Font = new System.Drawing.Font("Century Gothic", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label9.ForeColor = System.Drawing.Color.White;
            this.label9.Location = new System.Drawing.Point(0, 0);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(212, 52);
            this.label9.TabIndex = 0;
            this.label9.Text = "Masa Kategori Modülü";
            this.label9.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // YonetimModulAyarlari
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(49)))), ((int)(((byte)(49)))), ((int)(((byte)(49)))));
            this.ClientSize = new System.Drawing.Size(734, 611);
            this.Controls.Add(this.pnl_KullaniciDuzenleme);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "YonetimModulAyarlari";
            this.Text = "YonetimModulAyarlari";
            this.SizeChanged += new System.EventHandler(this.YonetimModulAyarlari_SizeChanged);
            this.pnl_KullaniciDuzenleme.ResumeLayout(false);
            this.pnl_Moduller.ResumeLayout(false);
            this.panel7.ResumeLayout(false);
            this.panel7.PerformLayout();
            this.pnl_Getir.ResumeLayout(false);
            this.pnl_Trendyol.ResumeLayout(false);
            this.panel9.ResumeLayout(false);
            this.panel10.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.pcb_Getir)).EndInit();
            this.panel12.ResumeLayout(false);
            this.panel13.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.pcb_Trendyol)).EndInit();
            this.panel14.ResumeLayout(false);
            this.panel15.ResumeLayout(false);
            this.panel3.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.pcb_Yemeksepeti)).EndInit();
            this.panel5.ResumeLayout(false);
            this.panel8.ResumeLayout(false);
            this.pnl_Yemeksepeti.ResumeLayout(false);
            this.pnl_Telegram.ResumeLayout(false);
            this.panel6.ResumeLayout(false);
            this.panel11.ResumeLayout(false);
            this.panel16.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.pnl_UrunKategori.ResumeLayout(false);
            this.panel18.ResumeLayout(false);
            this.panel19.ResumeLayout(false);
            this.pnl_Malzeme.ResumeLayout(false);
            this.panel21.ResumeLayout(false);
            this.panel22.ResumeLayout(false);
            this.pnl_Bayi.ResumeLayout(false);
            this.panel24.ResumeLayout(false);
            this.panel25.ResumeLayout(false);
            this.pnl_Kullanici.ResumeLayout(false);
            this.panel27.ResumeLayout(false);
            this.panel28.ResumeLayout(false);
            this.pnl_MasaKategori.ResumeLayout(false);
            this.panel30.ResumeLayout(false);
            this.panel31.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel pnl_KullaniciDuzenleme;
        private System.Windows.Forms.Panel pnl_Moduller;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Panel panel4;
        private System.Windows.Forms.Panel panel7;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Panel pnl_Trendyol;
        private System.Windows.Forms.Panel pnl_Getir;
        private System.Windows.Forms.Panel panel12;
        private System.Windows.Forms.Panel panel15;
        private System.Windows.Forms.Button btn_Trendyol;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Panel panel13;
        private System.Windows.Forms.PictureBox pcb_Trendyol;
        private System.Windows.Forms.Panel panel9;
        private System.Windows.Forms.Panel panel14;
        private System.Windows.Forms.Button btn_Getir;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Panel panel10;
        private System.Windows.Forms.PictureBox pcb_Getir;
        private System.Windows.Forms.Panel pnl_MasaKategori;
        private System.Windows.Forms.Panel panel30;
        private System.Windows.Forms.Panel panel31;
        private System.Windows.Forms.Button btn_MasaKategori;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Panel pnl_Kullanici;
        private System.Windows.Forms.Panel panel27;
        private System.Windows.Forms.Panel panel28;
        private System.Windows.Forms.Button btn_Kullanici;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Panel pnl_Bayi;
        private System.Windows.Forms.Panel panel24;
        private System.Windows.Forms.Panel panel25;
        private System.Windows.Forms.Button btn_Bayi;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Panel pnl_Malzeme;
        private System.Windows.Forms.Panel panel21;
        private System.Windows.Forms.Panel panel22;
        private System.Windows.Forms.Button btn_Malzeme;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Panel pnl_UrunKategori;
        private System.Windows.Forms.Panel panel18;
        private System.Windows.Forms.Panel panel19;
        private System.Windows.Forms.Button btn_UrunKategori;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Panel pnl_Telegram;
        private System.Windows.Forms.Panel panel6;
        private System.Windows.Forms.Panel panel11;
        private System.Windows.Forms.Button btn_Telegram;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Panel panel16;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.Panel pnl_Yemeksepeti;
        private System.Windows.Forms.Panel panel5;
        private System.Windows.Forms.Panel panel8;
        private System.Windows.Forms.Button btn_Yemeksepeti;
        private System.Windows.Forms.Label lbl_Yemeksepeti;
        private System.Windows.Forms.Panel panel3;
        private System.Windows.Forms.PictureBox pcb_Yemeksepeti;
    }
}