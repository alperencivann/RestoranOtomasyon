﻿namespace RestoranOtomasyon.Forms
{
    partial class YonetimUrunYonetimi
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
			this.panel1 = new System.Windows.Forms.Panel();
			this.pnl_UrunKategoriUst = new System.Windows.Forms.Panel();
			this.pnl_UrunKategorileri = new System.Windows.Forms.Panel();
			this.panel6 = new System.Windows.Forms.Panel();
			this.panel7 = new System.Windows.Forms.Panel();
			this.panel11 = new System.Windows.Forms.Panel();
			this.panel12 = new System.Windows.Forms.Panel();
			this.btn_YeniUrunKategorisiEkle = new System.Windows.Forms.Button();
			this.label2 = new System.Windows.Forms.Label();
			this.pnl_UrunUst = new System.Windows.Forms.Panel();
			this.pnl_Urunler = new System.Windows.Forms.Panel();
			this.panel8 = new System.Windows.Forms.Panel();
			this.panel9 = new System.Windows.Forms.Panel();
			this.panel5 = new System.Windows.Forms.Panel();
			this.panel10 = new System.Windows.Forms.Panel();
			this.button1 = new System.Windows.Forms.Button();
			this.label1 = new System.Windows.Forms.Label();
			this.panel1.SuspendLayout();
			this.pnl_UrunKategoriUst.SuspendLayout();
			this.panel11.SuspendLayout();
			this.panel12.SuspendLayout();
			this.pnl_UrunUst.SuspendLayout();
			this.panel5.SuspendLayout();
			this.panel10.SuspendLayout();
			this.SuspendLayout();
			// 
			// panel1
			// 
			this.panel1.AutoScroll = true;
			this.panel1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(49)))), ((int)(((byte)(49)))), ((int)(((byte)(49)))));
			this.panel1.Controls.Add(this.pnl_UrunKategoriUst);
			this.panel1.Controls.Add(this.pnl_UrunUst);
			this.panel1.Dock = System.Windows.Forms.DockStyle.Fill;
			this.panel1.Location = new System.Drawing.Point(0, 0);
			this.panel1.Name = "panel1";
			this.panel1.Size = new System.Drawing.Size(734, 555);
			this.panel1.TabIndex = 0;
			// 
			// pnl_UrunKategoriUst
			// 
			this.pnl_UrunKategoriUst.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(39)))), ((int)(((byte)(39)))), ((int)(((byte)(39)))));
			this.pnl_UrunKategoriUst.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
			this.pnl_UrunKategoriUst.Controls.Add(this.pnl_UrunKategorileri);
			this.pnl_UrunKategoriUst.Controls.Add(this.panel6);
			this.pnl_UrunKategoriUst.Controls.Add(this.panel7);
			this.pnl_UrunKategoriUst.Controls.Add(this.panel11);
			this.pnl_UrunKategoriUst.Dock = System.Windows.Forms.DockStyle.Top;
			this.pnl_UrunKategoriUst.Location = new System.Drawing.Point(0, 286);
			this.pnl_UrunKategoriUst.Name = "pnl_UrunKategoriUst";
			this.pnl_UrunKategoriUst.Size = new System.Drawing.Size(734, 267);
			this.pnl_UrunKategoriUst.TabIndex = 7;
			// 
			// pnl_UrunKategorileri
			// 
			this.pnl_UrunKategorileri.AutoScroll = true;
			this.pnl_UrunKategorileri.Dock = System.Windows.Forms.DockStyle.Fill;
			this.pnl_UrunKategorileri.Location = new System.Drawing.Point(25, 35);
			this.pnl_UrunKategorileri.Name = "pnl_UrunKategorileri";
			this.pnl_UrunKategorileri.Size = new System.Drawing.Size(682, 230);
			this.pnl_UrunKategorileri.TabIndex = 11;
			// 
			// panel6
			// 
			this.panel6.Dock = System.Windows.Forms.DockStyle.Right;
			this.panel6.Location = new System.Drawing.Point(707, 35);
			this.panel6.Name = "panel6";
			this.panel6.Size = new System.Drawing.Size(25, 230);
			this.panel6.TabIndex = 10;
			// 
			// panel7
			// 
			this.panel7.Dock = System.Windows.Forms.DockStyle.Left;
			this.panel7.Location = new System.Drawing.Point(0, 35);
			this.panel7.Name = "panel7";
			this.panel7.Size = new System.Drawing.Size(25, 230);
			this.panel7.TabIndex = 9;
			// 
			// panel11
			// 
			this.panel11.Controls.Add(this.panel12);
			this.panel11.Controls.Add(this.label2);
			this.panel11.Dock = System.Windows.Forms.DockStyle.Top;
			this.panel11.Location = new System.Drawing.Point(0, 0);
			this.panel11.Name = "panel11";
			this.panel11.Size = new System.Drawing.Size(732, 35);
			this.panel11.TabIndex = 1;
			// 
			// panel12
			// 
			this.panel12.Controls.Add(this.btn_YeniUrunKategorisiEkle);
			this.panel12.Dock = System.Windows.Forms.DockStyle.Right;
			this.panel12.Location = new System.Drawing.Point(532, 0);
			this.panel12.Name = "panel12";
			this.panel12.Size = new System.Drawing.Size(200, 35);
			this.panel12.TabIndex = 2;
			// 
			// btn_YeniUrunKategorisiEkle
			// 
			this.btn_YeniUrunKategorisiEkle.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(2)))), ((int)(((byte)(117)))), ((int)(((byte)(252)))));
			this.btn_YeniUrunKategorisiEkle.FlatAppearance.BorderSize = 0;
			this.btn_YeniUrunKategorisiEkle.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
			this.btn_YeniUrunKategorisiEkle.Font = new System.Drawing.Font("Century Gothic", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
			this.btn_YeniUrunKategorisiEkle.ForeColor = System.Drawing.Color.White;
			this.btn_YeniUrunKategorisiEkle.Location = new System.Drawing.Point(13, 5);
			this.btn_YeniUrunKategorisiEkle.Name = "btn_YeniUrunKategorisiEkle";
			this.btn_YeniUrunKategorisiEkle.Size = new System.Drawing.Size(162, 24);
			this.btn_YeniUrunKategorisiEkle.TabIndex = 5;
			this.btn_YeniUrunKategorisiEkle.Text = "Yeni Ürün Kategorisi Ekle";
			this.btn_YeniUrunKategorisiEkle.UseVisualStyleBackColor = false;
			this.btn_YeniUrunKategorisiEkle.Click += new System.EventHandler(this.btn_YeniUrunKategorisiEkle_Click);
			// 
			// label2
			// 
			this.label2.AutoSize = true;
			this.label2.Font = new System.Drawing.Font("Century Gothic", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
			this.label2.ForeColor = System.Drawing.Color.White;
			this.label2.Location = new System.Drawing.Point(21, 9);
			this.label2.Name = "label2";
			this.label2.Size = new System.Drawing.Size(155, 16);
			this.label2.TabIndex = 0;
			this.label2.Text = "Ürün Kategori Yönetimi";
			// 
			// pnl_UrunUst
			// 
			this.pnl_UrunUst.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(39)))), ((int)(((byte)(39)))), ((int)(((byte)(39)))));
			this.pnl_UrunUst.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
			this.pnl_UrunUst.Controls.Add(this.pnl_Urunler);
			this.pnl_UrunUst.Controls.Add(this.panel8);
			this.pnl_UrunUst.Controls.Add(this.panel9);
			this.pnl_UrunUst.Controls.Add(this.panel5);
			this.pnl_UrunUst.Dock = System.Windows.Forms.DockStyle.Top;
			this.pnl_UrunUst.Location = new System.Drawing.Point(0, 0);
			this.pnl_UrunUst.Name = "pnl_UrunUst";
			this.pnl_UrunUst.Size = new System.Drawing.Size(734, 286);
			this.pnl_UrunUst.TabIndex = 5;
			// 
			// pnl_Urunler
			// 
			this.pnl_Urunler.AutoScroll = true;
			this.pnl_Urunler.Dock = System.Windows.Forms.DockStyle.Fill;
			this.pnl_Urunler.Location = new System.Drawing.Point(25, 35);
			this.pnl_Urunler.Name = "pnl_Urunler";
			this.pnl_Urunler.Size = new System.Drawing.Size(682, 249);
			this.pnl_Urunler.TabIndex = 11;
			// 
			// panel8
			// 
			this.panel8.Dock = System.Windows.Forms.DockStyle.Right;
			this.panel8.Location = new System.Drawing.Point(707, 35);
			this.panel8.Name = "panel8";
			this.panel8.Size = new System.Drawing.Size(25, 249);
			this.panel8.TabIndex = 10;
			// 
			// panel9
			// 
			this.panel9.Dock = System.Windows.Forms.DockStyle.Left;
			this.panel9.Location = new System.Drawing.Point(0, 35);
			this.panel9.Name = "panel9";
			this.panel9.Size = new System.Drawing.Size(25, 249);
			this.panel9.TabIndex = 9;
			// 
			// panel5
			// 
			this.panel5.Controls.Add(this.panel10);
			this.panel5.Controls.Add(this.label1);
			this.panel5.Dock = System.Windows.Forms.DockStyle.Top;
			this.panel5.Location = new System.Drawing.Point(0, 0);
			this.panel5.Name = "panel5";
			this.panel5.Size = new System.Drawing.Size(732, 35);
			this.panel5.TabIndex = 1;
			// 
			// panel10
			// 
			this.panel10.Controls.Add(this.button1);
			this.panel10.Dock = System.Windows.Forms.DockStyle.Right;
			this.panel10.Location = new System.Drawing.Point(532, 0);
			this.panel10.Name = "panel10";
			this.panel10.Size = new System.Drawing.Size(200, 35);
			this.panel10.TabIndex = 2;
			// 
			// button1
			// 
			this.button1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(2)))), ((int)(((byte)(117)))), ((int)(((byte)(252)))));
			this.button1.FlatAppearance.BorderSize = 0;
			this.button1.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
			this.button1.Font = new System.Drawing.Font("Century Gothic", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
			this.button1.ForeColor = System.Drawing.Color.White;
			this.button1.Location = new System.Drawing.Point(13, 5);
			this.button1.Name = "button1";
			this.button1.Size = new System.Drawing.Size(162, 24);
			this.button1.TabIndex = 5;
			this.button1.Text = "Yeni Ürün Ekle";
			this.button1.UseVisualStyleBackColor = false;
			this.button1.Click += new System.EventHandler(this.button1_Click);
			// 
			// label1
			// 
			this.label1.AutoSize = true;
			this.label1.Font = new System.Drawing.Font("Century Gothic", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
			this.label1.ForeColor = System.Drawing.Color.White;
			this.label1.Location = new System.Drawing.Point(21, 9);
			this.label1.Name = "label1";
			this.label1.Size = new System.Drawing.Size(96, 16);
			this.label1.TabIndex = 0;
			this.label1.Text = "Ürün Yönetimi";
			// 
			// YonetimUrunYonetimi
			// 
			this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
			this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
			this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(39)))), ((int)(((byte)(39)))), ((int)(((byte)(39)))));
			this.ClientSize = new System.Drawing.Size(734, 555);
			this.Controls.Add(this.panel1);
			this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
			this.Name = "YonetimUrunYonetimi";
			this.Text = "YonetimUrunYonetimi";
			this.Load += new System.EventHandler(this.YonetimUrunYonetimi_Load);
			this.SizeChanged += new System.EventHandler(this.YonetimUrunYonetimi_SizeChanged);
			this.panel1.ResumeLayout(false);
			this.pnl_UrunKategoriUst.ResumeLayout(false);
			this.panel11.ResumeLayout(false);
			this.panel11.PerformLayout();
			this.panel12.ResumeLayout(false);
			this.pnl_UrunUst.ResumeLayout(false);
			this.panel5.ResumeLayout(false);
			this.panel5.PerformLayout();
			this.panel10.ResumeLayout(false);
			this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Panel pnl_UrunUst;
        private System.Windows.Forms.Panel pnl_Urunler;
        private System.Windows.Forms.Panel panel8;
        private System.Windows.Forms.Panel panel9;
        private System.Windows.Forms.Panel panel5;
        private System.Windows.Forms.Panel panel10;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Label label1;
		private System.Windows.Forms.Panel pnl_UrunKategoriUst;
		private System.Windows.Forms.Panel pnl_UrunKategorileri;
		private System.Windows.Forms.Panel panel6;
		private System.Windows.Forms.Panel panel7;
		private System.Windows.Forms.Panel panel11;
		private System.Windows.Forms.Panel panel12;
		private System.Windows.Forms.Button btn_YeniUrunKategorisiEkle;
		private System.Windows.Forms.Label label2;
	}
}