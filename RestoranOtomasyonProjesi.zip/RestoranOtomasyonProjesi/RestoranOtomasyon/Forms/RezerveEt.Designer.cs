﻿namespace RestoranOtomasyon.Forms
{
    partial class RezerveEt
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
			this.panel1 = new System.Windows.Forms.Panel();
			this.lbl_Header = new System.Windows.Forms.Label();
			this.panel2 = new System.Windows.Forms.Panel();
			this.panel10 = new System.Windows.Forms.Panel();
			this.btn_Exit = new System.Windows.Forms.Button();
			this.panel3 = new System.Windows.Forms.Panel();
			this.button1 = new System.Windows.Forms.Button();
			this.button2 = new System.Windows.Forms.Button();
			this.panel4 = new System.Windows.Forms.Panel();
			this.rtb_GecmisRezervasyonlar = new System.Windows.Forms.RichTextBox();
			this.panel11 = new System.Windows.Forms.Panel();
			this.label6 = new System.Windows.Forms.Label();
			this.panel5 = new System.Windows.Forms.Panel();
			this.btn_RezervasyonuIptalEt = new System.Windows.Forms.Button();
			this.btn_RezervasyonuKaydet = new System.Windows.Forms.Button();
			this.panel9 = new System.Windows.Forms.Panel();
			this.cbx_MasaNumarasi = new System.Windows.Forms.ComboBox();
			this.label5 = new System.Windows.Forms.Label();
			this.panel8 = new System.Windows.Forms.Panel();
			this.cbx_kategori = new System.Windows.Forms.ComboBox();
			this.label4 = new System.Windows.Forms.Label();
			this.panel7 = new System.Windows.Forms.Panel();
			this.dtp_RezervasyonSaati = new System.Windows.Forms.DateTimePicker();
			this.label3 = new System.Windows.Forms.Label();
			this.panel6 = new System.Windows.Forms.Panel();
			this.txb_TelefonNumarasi = new System.Windows.Forms.TextBox();
			this.label2 = new System.Windows.Forms.Label();
			this.panel12 = new System.Windows.Forms.Panel();
			this.txb_IsimSoyisim = new System.Windows.Forms.TextBox();
			this.label1 = new System.Windows.Forms.Label();
			this.panel1.SuspendLayout();
			this.panel10.SuspendLayout();
			this.panel3.SuspendLayout();
			this.panel4.SuspendLayout();
			this.panel11.SuspendLayout();
			this.panel5.SuspendLayout();
			this.panel9.SuspendLayout();
			this.panel8.SuspendLayout();
			this.panel7.SuspendLayout();
			this.panel6.SuspendLayout();
			this.panel12.SuspendLayout();
			this.SuspendLayout();
			// 
			// panel1
			// 
			this.panel1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(24)))), ((int)(((byte)(24)))), ((int)(((byte)(24)))));
			this.panel1.Controls.Add(this.lbl_Header);
			this.panel1.Controls.Add(this.panel2);
			this.panel1.Controls.Add(this.panel10);
			this.panel1.Dock = System.Windows.Forms.DockStyle.Top;
			this.panel1.Location = new System.Drawing.Point(0, 0);
			this.panel1.Name = "panel1";
			this.panel1.Size = new System.Drawing.Size(539, 50);
			this.panel1.TabIndex = 0;
			// 
			// lbl_Header
			// 
			this.lbl_Header.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(29)))), ((int)(((byte)(29)))), ((int)(((byte)(29)))));
			this.lbl_Header.Dock = System.Windows.Forms.DockStyle.Fill;
			this.lbl_Header.Font = new System.Drawing.Font("Century Gothic", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
			this.lbl_Header.ForeColor = System.Drawing.Color.White;
			this.lbl_Header.Location = new System.Drawing.Point(36, 0);
			this.lbl_Header.Name = "lbl_Header";
			this.lbl_Header.Size = new System.Drawing.Size(467, 50);
			this.lbl_Header.TabIndex = 5;
			this.lbl_Header.Text = "Rezervasyon";
			this.lbl_Header.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
			// 
			// panel2
			// 
			this.panel2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(29)))), ((int)(((byte)(29)))), ((int)(((byte)(29)))));
			this.panel2.Dock = System.Windows.Forms.DockStyle.Left;
			this.panel2.Location = new System.Drawing.Point(0, 0);
			this.panel2.Name = "panel2";
			this.panel2.Size = new System.Drawing.Size(36, 50);
			this.panel2.TabIndex = 4;
			// 
			// panel10
			// 
			this.panel10.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(29)))), ((int)(((byte)(29)))), ((int)(((byte)(29)))));
			this.panel10.Controls.Add(this.btn_Exit);
			this.panel10.Dock = System.Windows.Forms.DockStyle.Right;
			this.panel10.Location = new System.Drawing.Point(503, 0);
			this.panel10.Name = "panel10";
			this.panel10.Size = new System.Drawing.Size(36, 50);
			this.panel10.TabIndex = 3;
			// 
			// btn_Exit
			// 
			this.btn_Exit.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(24)))), ((int)(((byte)(24)))), ((int)(((byte)(24)))));
			this.btn_Exit.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
			this.btn_Exit.Font = new System.Drawing.Font("Century Gothic", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
			this.btn_Exit.ForeColor = System.Drawing.Color.Red;
			this.btn_Exit.Location = new System.Drawing.Point(4, 9);
			this.btn_Exit.Name = "btn_Exit";
			this.btn_Exit.Size = new System.Drawing.Size(29, 31);
			this.btn_Exit.TabIndex = 1;
			this.btn_Exit.Text = "x";
			this.btn_Exit.UseVisualStyleBackColor = false;
			this.btn_Exit.Click += new System.EventHandler(this.btn_Exit_Click);
			// 
			// panel3
			// 
			this.panel3.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
			this.panel3.Controls.Add(this.button1);
			this.panel3.Controls.Add(this.button2);
			this.panel3.Controls.Add(this.panel4);
			this.panel3.Controls.Add(this.panel5);
			this.panel3.Dock = System.Windows.Forms.DockStyle.Fill;
			this.panel3.Location = new System.Drawing.Point(0, 50);
			this.panel3.Name = "panel3";
			this.panel3.Size = new System.Drawing.Size(539, 371);
			this.panel3.TabIndex = 1;
			// 
			// button1
			// 
			this.button1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(200)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
			this.button1.FlatAppearance.BorderSize = 0;
			this.button1.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
			this.button1.Font = new System.Drawing.Font("Century Gothic", 9F, System.Drawing.FontStyle.Bold);
			this.button1.ForeColor = System.Drawing.Color.White;
			this.button1.Location = new System.Drawing.Point(275, 333);
			this.button1.Name = "button1";
			this.button1.Size = new System.Drawing.Size(258, 32);
			this.button1.TabIndex = 14;
			this.button1.Text = "Gelmedi Olarak İşaretle\r\n";
			this.button1.UseVisualStyleBackColor = false;
			this.button1.Click += new System.EventHandler(this.button1_Click);
			// 
			// button2
			// 
			this.button2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(117)))), ((int)(((byte)(255)))));
			this.button2.FlatAppearance.BorderSize = 0;
			this.button2.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
			this.button2.Font = new System.Drawing.Font("Century Gothic", 9F, System.Drawing.FontStyle.Bold);
			this.button2.ForeColor = System.Drawing.Color.White;
			this.button2.Location = new System.Drawing.Point(7, 333);
			this.button2.Name = "button2";
			this.button2.Size = new System.Drawing.Size(258, 32);
			this.button2.TabIndex = 13;
			this.button2.Text = "Geldi Olarak İşaretle";
			this.button2.UseVisualStyleBackColor = false;
			this.button2.Click += new System.EventHandler(this.button2_Click);
			// 
			// panel4
			// 
			this.panel4.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(29)))), ((int)(((byte)(29)))), ((int)(((byte)(29)))));
			this.panel4.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
			this.panel4.Controls.Add(this.rtb_GecmisRezervasyonlar);
			this.panel4.Controls.Add(this.panel11);
			this.panel4.Location = new System.Drawing.Point(6, 204);
			this.panel4.Name = "panel4";
			this.panel4.Size = new System.Drawing.Size(527, 125);
			this.panel4.TabIndex = 12;
			// 
			// rtb_GecmisRezervasyonlar
			// 
			this.rtb_GecmisRezervasyonlar.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(24)))), ((int)(((byte)(24)))), ((int)(((byte)(24)))));
			this.rtb_GecmisRezervasyonlar.Dock = System.Windows.Forms.DockStyle.Fill;
			this.rtb_GecmisRezervasyonlar.Font = new System.Drawing.Font("Century Gothic", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
			this.rtb_GecmisRezervasyonlar.ForeColor = System.Drawing.Color.White;
			this.rtb_GecmisRezervasyonlar.Location = new System.Drawing.Point(0, 26);
			this.rtb_GecmisRezervasyonlar.Name = "rtb_GecmisRezervasyonlar";
			this.rtb_GecmisRezervasyonlar.Size = new System.Drawing.Size(525, 97);
			this.rtb_GecmisRezervasyonlar.TabIndex = 1;
			this.rtb_GecmisRezervasyonlar.Text = "";
			// 
			// panel11
			// 
			this.panel11.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(29)))), ((int)(((byte)(29)))), ((int)(((byte)(29)))));
			this.panel11.Controls.Add(this.label6);
			this.panel11.Dock = System.Windows.Forms.DockStyle.Top;
			this.panel11.Location = new System.Drawing.Point(0, 0);
			this.panel11.Name = "panel11";
			this.panel11.Size = new System.Drawing.Size(525, 26);
			this.panel11.TabIndex = 0;
			// 
			// label6
			// 
			this.label6.Font = new System.Drawing.Font("Century Gothic", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
			this.label6.ForeColor = System.Drawing.Color.White;
			this.label6.Location = new System.Drawing.Point(5, 3);
			this.label6.Name = "label6";
			this.label6.Size = new System.Drawing.Size(175, 18);
			this.label6.TabIndex = 7;
			this.label6.Text = "Geçmiş Rezervasyonlar";
			this.label6.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
			// 
			// panel5
			// 
			this.panel5.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(29)))), ((int)(((byte)(29)))), ((int)(((byte)(29)))));
			this.panel5.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
			this.panel5.Controls.Add(this.btn_RezervasyonuIptalEt);
			this.panel5.Controls.Add(this.btn_RezervasyonuKaydet);
			this.panel5.Controls.Add(this.panel9);
			this.panel5.Controls.Add(this.panel8);
			this.panel5.Controls.Add(this.panel7);
			this.panel5.Controls.Add(this.panel6);
			this.panel5.Controls.Add(this.panel12);
			this.panel5.Location = new System.Drawing.Point(6, 4);
			this.panel5.Name = "panel5";
			this.panel5.Size = new System.Drawing.Size(527, 194);
			this.panel5.TabIndex = 11;
			// 
			// btn_RezervasyonuIptalEt
			// 
			this.btn_RezervasyonuIptalEt.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(200)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
			this.btn_RezervasyonuIptalEt.FlatAppearance.BorderSize = 0;
			this.btn_RezervasyonuIptalEt.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
			this.btn_RezervasyonuIptalEt.Font = new System.Drawing.Font("Century Gothic", 9F, System.Drawing.FontStyle.Bold);
			this.btn_RezervasyonuIptalEt.ForeColor = System.Drawing.Color.White;
			this.btn_RezervasyonuIptalEt.Location = new System.Drawing.Point(268, 151);
			this.btn_RezervasyonuIptalEt.Name = "btn_RezervasyonuIptalEt";
			this.btn_RezervasyonuIptalEt.Size = new System.Drawing.Size(250, 32);
			this.btn_RezervasyonuIptalEt.TabIndex = 8;
			this.btn_RezervasyonuIptalEt.Text = "Rezervasyonu İptal Et";
			this.btn_RezervasyonuIptalEt.UseVisualStyleBackColor = false;
			this.btn_RezervasyonuIptalEt.Click += new System.EventHandler(this.btn_RezervasyonuIptalEt_Click);
			// 
			// btn_RezervasyonuKaydet
			// 
			this.btn_RezervasyonuKaydet.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(117)))), ((int)(((byte)(255)))));
			this.btn_RezervasyonuKaydet.FlatAppearance.BorderSize = 0;
			this.btn_RezervasyonuKaydet.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
			this.btn_RezervasyonuKaydet.Font = new System.Drawing.Font("Century Gothic", 9F, System.Drawing.FontStyle.Bold);
			this.btn_RezervasyonuKaydet.ForeColor = System.Drawing.Color.White;
			this.btn_RezervasyonuKaydet.Location = new System.Drawing.Point(8, 151);
			this.btn_RezervasyonuKaydet.Name = "btn_RezervasyonuKaydet";
			this.btn_RezervasyonuKaydet.Size = new System.Drawing.Size(250, 32);
			this.btn_RezervasyonuKaydet.TabIndex = 7;
			this.btn_RezervasyonuKaydet.Text = "Rezervasyonu Kaydet";
			this.btn_RezervasyonuKaydet.UseVisualStyleBackColor = false;
			this.btn_RezervasyonuKaydet.Click += new System.EventHandler(this.btn_RezervasyonuKaydet_Click);
			// 
			// panel9
			// 
			this.panel9.Controls.Add(this.cbx_MasaNumarasi);
			this.panel9.Controls.Add(this.label5);
			this.panel9.Dock = System.Windows.Forms.DockStyle.Top;
			this.panel9.Location = new System.Drawing.Point(0, 115);
			this.panel9.Name = "panel9";
			this.panel9.Size = new System.Drawing.Size(525, 30);
			this.panel9.TabIndex = 6;
			// 
			// cbx_MasaNumarasi
			// 
			this.cbx_MasaNumarasi.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
			this.cbx_MasaNumarasi.Font = new System.Drawing.Font("Century Gothic", 9F, System.Drawing.FontStyle.Bold);
			this.cbx_MasaNumarasi.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(19)))), ((int)(((byte)(19)))), ((int)(((byte)(19)))));
			this.cbx_MasaNumarasi.FormattingEnabled = true;
			this.cbx_MasaNumarasi.Location = new System.Drawing.Point(142, 2);
			this.cbx_MasaNumarasi.Name = "cbx_MasaNumarasi";
			this.cbx_MasaNumarasi.Size = new System.Drawing.Size(376, 24);
			this.cbx_MasaNumarasi.TabIndex = 6;
			this.cbx_MasaNumarasi.SelectedIndexChanged += new System.EventHandler(this.cbx_MasaNumarasi_SelectedIndexChanged);
			// 
			// label5
			// 
			this.label5.Font = new System.Drawing.Font("Century Gothic", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
			this.label5.ForeColor = System.Drawing.Color.White;
			this.label5.Location = new System.Drawing.Point(5, 5);
			this.label5.Name = "label5";
			this.label5.Size = new System.Drawing.Size(131, 20);
			this.label5.TabIndex = 0;
			this.label5.Text = "Masa Numarası";
			this.label5.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
			// 
			// panel8
			// 
			this.panel8.Controls.Add(this.cbx_kategori);
			this.panel8.Controls.Add(this.label4);
			this.panel8.Dock = System.Windows.Forms.DockStyle.Top;
			this.panel8.Location = new System.Drawing.Point(0, 87);
			this.panel8.Name = "panel8";
			this.panel8.Size = new System.Drawing.Size(525, 28);
			this.panel8.TabIndex = 5;
			// 
			// cbx_kategori
			// 
			this.cbx_kategori.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
			this.cbx_kategori.Font = new System.Drawing.Font("Century Gothic", 9F, System.Drawing.FontStyle.Bold);
			this.cbx_kategori.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(19)))), ((int)(((byte)(19)))), ((int)(((byte)(19)))));
			this.cbx_kategori.FormattingEnabled = true;
			this.cbx_kategori.Location = new System.Drawing.Point(142, 2);
			this.cbx_kategori.Name = "cbx_kategori";
			this.cbx_kategori.Size = new System.Drawing.Size(376, 24);
			this.cbx_kategori.TabIndex = 6;
			this.cbx_kategori.SelectedIndexChanged += new System.EventHandler(this.cbx_kategori_SelectedIndexChanged);
			// 
			// label4
			// 
			this.label4.Font = new System.Drawing.Font("Century Gothic", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
			this.label4.ForeColor = System.Drawing.Color.White;
			this.label4.Location = new System.Drawing.Point(5, 4);
			this.label4.Name = "label4";
			this.label4.Size = new System.Drawing.Size(131, 20);
			this.label4.TabIndex = 0;
			this.label4.Text = "Masa Kategorisi";
			this.label4.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
			// 
			// panel7
			// 
			this.panel7.Controls.Add(this.dtp_RezervasyonSaati);
			this.panel7.Controls.Add(this.label3);
			this.panel7.Dock = System.Windows.Forms.DockStyle.Top;
			this.panel7.Location = new System.Drawing.Point(0, 58);
			this.panel7.Name = "panel7";
			this.panel7.Size = new System.Drawing.Size(525, 29);
			this.panel7.TabIndex = 4;
			// 
			// dtp_RezervasyonSaati
			// 
			this.dtp_RezervasyonSaati.CalendarForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(19)))), ((int)(((byte)(19)))), ((int)(((byte)(19)))));
			this.dtp_RezervasyonSaati.CustomFormat = "MM/dd/yyyy hh:mm:ss";
			this.dtp_RezervasyonSaati.Font = new System.Drawing.Font("Century Gothic", 9F, System.Drawing.FontStyle.Bold);
			this.dtp_RezervasyonSaati.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
			this.dtp_RezervasyonSaati.Location = new System.Drawing.Point(142, 4);
			this.dtp_RezervasyonSaati.Name = "dtp_RezervasyonSaati";
			this.dtp_RezervasyonSaati.Size = new System.Drawing.Size(376, 22);
			this.dtp_RezervasyonSaati.TabIndex = 1;
			// 
			// label3
			// 
			this.label3.Font = new System.Drawing.Font("Century Gothic", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
			this.label3.ForeColor = System.Drawing.Color.White;
			this.label3.Location = new System.Drawing.Point(5, 5);
			this.label3.Name = "label3";
			this.label3.Size = new System.Drawing.Size(131, 20);
			this.label3.TabIndex = 0;
			this.label3.Text = "Rezervasyon Tarihi";
			this.label3.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
			// 
			// panel6
			// 
			this.panel6.Controls.Add(this.txb_TelefonNumarasi);
			this.panel6.Controls.Add(this.label2);
			this.panel6.Dock = System.Windows.Forms.DockStyle.Top;
			this.panel6.Location = new System.Drawing.Point(0, 29);
			this.panel6.Name = "panel6";
			this.panel6.Size = new System.Drawing.Size(525, 29);
			this.panel6.TabIndex = 3;
			// 
			// txb_TelefonNumarasi
			// 
			this.txb_TelefonNumarasi.Font = new System.Drawing.Font("Century Gothic", 9F, System.Drawing.FontStyle.Bold);
			this.txb_TelefonNumarasi.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(19)))), ((int)(((byte)(19)))), ((int)(((byte)(19)))));
			this.txb_TelefonNumarasi.Location = new System.Drawing.Point(142, 4);
			this.txb_TelefonNumarasi.Name = "txb_TelefonNumarasi";
			this.txb_TelefonNumarasi.Size = new System.Drawing.Size(376, 22);
			this.txb_TelefonNumarasi.TabIndex = 1;
			this.txb_TelefonNumarasi.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txb_TelefonNumarasi_KeyPress);
			// 
			// label2
			// 
			this.label2.Font = new System.Drawing.Font("Century Gothic", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
			this.label2.ForeColor = System.Drawing.Color.White;
			this.label2.Location = new System.Drawing.Point(5, 5);
			this.label2.Name = "label2";
			this.label2.Size = new System.Drawing.Size(131, 19);
			this.label2.TabIndex = 0;
			this.label2.Text = "Telefon Numarası";
			this.label2.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
			// 
			// panel12
			// 
			this.panel12.Controls.Add(this.txb_IsimSoyisim);
			this.panel12.Controls.Add(this.label1);
			this.panel12.Dock = System.Windows.Forms.DockStyle.Top;
			this.panel12.Location = new System.Drawing.Point(0, 0);
			this.panel12.Name = "panel12";
			this.panel12.Size = new System.Drawing.Size(525, 29);
			this.panel12.TabIndex = 2;
			// 
			// txb_IsimSoyisim
			// 
			this.txb_IsimSoyisim.Font = new System.Drawing.Font("Century Gothic", 9F, System.Drawing.FontStyle.Bold);
			this.txb_IsimSoyisim.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(19)))), ((int)(((byte)(19)))), ((int)(((byte)(19)))));
			this.txb_IsimSoyisim.Location = new System.Drawing.Point(142, 4);
			this.txb_IsimSoyisim.Name = "txb_IsimSoyisim";
			this.txb_IsimSoyisim.Size = new System.Drawing.Size(376, 22);
			this.txb_IsimSoyisim.TabIndex = 1;
			// 
			// label1
			// 
			this.label1.Font = new System.Drawing.Font("Century Gothic", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
			this.label1.ForeColor = System.Drawing.Color.White;
			this.label1.Location = new System.Drawing.Point(5, 5);
			this.label1.Name = "label1";
			this.label1.Size = new System.Drawing.Size(131, 18);
			this.label1.TabIndex = 0;
			this.label1.Text = "İsim Soyisim";
			this.label1.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
			// 
			// RezerveEt
			// 
			this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
			this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
			this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(39)))), ((int)(((byte)(39)))), ((int)(((byte)(39)))));
			this.ClientSize = new System.Drawing.Size(539, 421);
			this.Controls.Add(this.panel3);
			this.Controls.Add(this.panel1);
			this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
			this.Name = "RezerveEt";
			this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
			this.Text = "RezerveEt";
			this.Load += new System.EventHandler(this.RezerveEt_Load);
			this.panel1.ResumeLayout(false);
			this.panel10.ResumeLayout(false);
			this.panel3.ResumeLayout(false);
			this.panel4.ResumeLayout(false);
			this.panel11.ResumeLayout(false);
			this.panel5.ResumeLayout(false);
			this.panel9.ResumeLayout(false);
			this.panel8.ResumeLayout(false);
			this.panel7.ResumeLayout(false);
			this.panel6.ResumeLayout(false);
			this.panel6.PerformLayout();
			this.panel12.ResumeLayout(false);
			this.panel12.PerformLayout();
			this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Label lbl_Header;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.Panel panel10;
        private System.Windows.Forms.Button btn_Exit;
        private System.Windows.Forms.Panel panel3;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.Panel panel4;
        private System.Windows.Forms.RichTextBox rtb_GecmisRezervasyonlar;
        private System.Windows.Forms.Panel panel11;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Panel panel5;
        private System.Windows.Forms.Button btn_RezervasyonuIptalEt;
        private System.Windows.Forms.Button btn_RezervasyonuKaydet;
        private System.Windows.Forms.Panel panel9;
        private System.Windows.Forms.ComboBox cbx_MasaNumarasi;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Panel panel8;
        private System.Windows.Forms.ComboBox cbx_kategori;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Panel panel7;
        private System.Windows.Forms.DateTimePicker dtp_RezervasyonSaati;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Panel panel6;
        private System.Windows.Forms.TextBox txb_TelefonNumarasi;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Panel panel12;
        private System.Windows.Forms.TextBox txb_IsimSoyisim;
        private System.Windows.Forms.Label label1;
    }
}