﻿namespace RestoranOtomasyon.Forms
{
    partial class SiparisAl
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
			this.panel1 = new System.Windows.Forms.Panel();
			this.lbl_Header = new System.Windows.Forms.Label();
			this.panel2 = new System.Windows.Forms.Panel();
			this.panel10 = new System.Windows.Forms.Panel();
			this.btn_Exit = new System.Windows.Forms.Button();
			this.pnl_Urunler = new System.Windows.Forms.Panel();
			this.pnl_Urun = new System.Windows.Forms.Panel();
			this.pnl_Kategori = new System.Windows.Forms.Panel();
			this.pnl_Adisyon = new System.Windows.Forms.Panel();
			this.panel4 = new System.Windows.Forms.Panel();
			this.btn_Azalt = new System.Windows.Forms.Button();
			this.btn_Arttir = new System.Windows.Forms.Button();
			this.panel5 = new System.Windows.Forms.Panel();
			this.lbl_ToplamTutar = new System.Windows.Forms.Label();
			this.label1 = new System.Windows.Forms.Label();
			this.btn_SiparisiKaydet = new System.Windows.Forms.Button();
			this.dataGridView1 = new System.Windows.Forms.DataGridView();
			this.ad = new System.Windows.Forms.DataGridViewTextBoxColumn();
			this.adet = new System.Windows.Forms.DataGridViewTextBoxColumn();
			this.adetFiyat = new System.Windows.Forms.DataGridViewTextBoxColumn();
			this.toplamFiyat = new System.Windows.Forms.DataGridViewTextBoxColumn();
			this.panel3 = new System.Windows.Forms.Panel();
			this.lbl_MasaAdi = new System.Windows.Forms.Label();
			this.panel1.SuspendLayout();
			this.panel10.SuspendLayout();
			this.pnl_Urunler.SuspendLayout();
			this.pnl_Adisyon.SuspendLayout();
			this.panel4.SuspendLayout();
			this.panel5.SuspendLayout();
			((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).BeginInit();
			this.panel3.SuspendLayout();
			this.SuspendLayout();
			// 
			// panel1
			// 
			this.panel1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(24)))), ((int)(((byte)(24)))), ((int)(((byte)(24)))));
			this.panel1.Controls.Add(this.lbl_Header);
			this.panel1.Controls.Add(this.panel2);
			this.panel1.Controls.Add(this.panel10);
			this.panel1.Dock = System.Windows.Forms.DockStyle.Top;
			this.panel1.Location = new System.Drawing.Point(0, 0);
			this.panel1.Name = "panel1";
			this.panel1.Size = new System.Drawing.Size(1179, 50);
			this.panel1.TabIndex = 1;
			// 
			// lbl_Header
			// 
			this.lbl_Header.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(29)))), ((int)(((byte)(29)))), ((int)(((byte)(29)))));
			this.lbl_Header.Dock = System.Windows.Forms.DockStyle.Fill;
			this.lbl_Header.Font = new System.Drawing.Font("Century Gothic", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
			this.lbl_Header.ForeColor = System.Drawing.Color.White;
			this.lbl_Header.Location = new System.Drawing.Point(36, 0);
			this.lbl_Header.Name = "lbl_Header";
			this.lbl_Header.Size = new System.Drawing.Size(1107, 50);
			this.lbl_Header.TabIndex = 5;
			this.lbl_Header.Text = "Sipariş Al";
			this.lbl_Header.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
			// 
			// panel2
			// 
			this.panel2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(29)))), ((int)(((byte)(29)))), ((int)(((byte)(29)))));
			this.panel2.Dock = System.Windows.Forms.DockStyle.Left;
			this.panel2.Location = new System.Drawing.Point(0, 0);
			this.panel2.Name = "panel2";
			this.panel2.Size = new System.Drawing.Size(36, 50);
			this.panel2.TabIndex = 4;
			// 
			// panel10
			// 
			this.panel10.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(29)))), ((int)(((byte)(29)))), ((int)(((byte)(29)))));
			this.panel10.Controls.Add(this.btn_Exit);
			this.panel10.Dock = System.Windows.Forms.DockStyle.Right;
			this.panel10.Location = new System.Drawing.Point(1143, 0);
			this.panel10.Name = "panel10";
			this.panel10.Size = new System.Drawing.Size(36, 50);
			this.panel10.TabIndex = 3;
			// 
			// btn_Exit
			// 
			this.btn_Exit.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(24)))), ((int)(((byte)(24)))), ((int)(((byte)(24)))));
			this.btn_Exit.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
			this.btn_Exit.Font = new System.Drawing.Font("Century Gothic", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
			this.btn_Exit.ForeColor = System.Drawing.Color.Red;
			this.btn_Exit.Location = new System.Drawing.Point(4, 9);
			this.btn_Exit.Name = "btn_Exit";
			this.btn_Exit.Size = new System.Drawing.Size(29, 31);
			this.btn_Exit.TabIndex = 1;
			this.btn_Exit.Text = "x";
			this.btn_Exit.UseVisualStyleBackColor = false;
			this.btn_Exit.Click += new System.EventHandler(this.btn_Exit_Click);
			// 
			// pnl_Urunler
			// 
			this.pnl_Urunler.Controls.Add(this.pnl_Urun);
			this.pnl_Urunler.Controls.Add(this.pnl_Kategori);
			this.pnl_Urunler.Dock = System.Windows.Forms.DockStyle.Left;
			this.pnl_Urunler.Location = new System.Drawing.Point(0, 50);
			this.pnl_Urunler.Name = "pnl_Urunler";
			this.pnl_Urunler.Size = new System.Drawing.Size(890, 460);
			this.pnl_Urunler.TabIndex = 2;
			// 
			// pnl_Urun
			// 
			this.pnl_Urun.AutoScroll = true;
			this.pnl_Urun.Dock = System.Windows.Forms.DockStyle.Fill;
			this.pnl_Urun.Location = new System.Drawing.Point(0, 55);
			this.pnl_Urun.Name = "pnl_Urun";
			this.pnl_Urun.Size = new System.Drawing.Size(890, 405);
			this.pnl_Urun.TabIndex = 1;
			// 
			// pnl_Kategori
			// 
			this.pnl_Kategori.AutoScroll = true;
			this.pnl_Kategori.Dock = System.Windows.Forms.DockStyle.Top;
			this.pnl_Kategori.Location = new System.Drawing.Point(0, 0);
			this.pnl_Kategori.Name = "pnl_Kategori";
			this.pnl_Kategori.Size = new System.Drawing.Size(890, 55);
			this.pnl_Kategori.TabIndex = 0;
			// 
			// pnl_Adisyon
			// 
			this.pnl_Adisyon.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(29)))), ((int)(((byte)(29)))), ((int)(((byte)(29)))));
			this.pnl_Adisyon.Controls.Add(this.panel4);
			this.pnl_Adisyon.Controls.Add(this.dataGridView1);
			this.pnl_Adisyon.Controls.Add(this.panel3);
			this.pnl_Adisyon.Dock = System.Windows.Forms.DockStyle.Fill;
			this.pnl_Adisyon.Location = new System.Drawing.Point(890, 50);
			this.pnl_Adisyon.Name = "pnl_Adisyon";
			this.pnl_Adisyon.Size = new System.Drawing.Size(289, 460);
			this.pnl_Adisyon.TabIndex = 3;
			// 
			// panel4
			// 
			this.panel4.Controls.Add(this.btn_Azalt);
			this.panel4.Controls.Add(this.btn_Arttir);
			this.panel4.Controls.Add(this.panel5);
			this.panel4.Controls.Add(this.btn_SiparisiKaydet);
			this.panel4.Dock = System.Windows.Forms.DockStyle.Bottom;
			this.panel4.Location = new System.Drawing.Point(0, 332);
			this.panel4.Margin = new System.Windows.Forms.Padding(2);
			this.panel4.Name = "panel4";
			this.panel4.Size = new System.Drawing.Size(289, 128);
			this.panel4.TabIndex = 2;
			// 
			// btn_Azalt
			// 
			this.btn_Azalt.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(15)))), ((int)(((byte)(15)))));
			this.btn_Azalt.FlatAppearance.BorderSize = 0;
			this.btn_Azalt.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
			this.btn_Azalt.Font = new System.Drawing.Font("Century Gothic", 7.875F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
			this.btn_Azalt.ForeColor = System.Drawing.Color.White;
			this.btn_Azalt.Location = new System.Drawing.Point(148, 14);
			this.btn_Azalt.Margin = new System.Windows.Forms.Padding(2);
			this.btn_Azalt.Name = "btn_Azalt";
			this.btn_Azalt.Size = new System.Drawing.Size(136, 31);
			this.btn_Azalt.TabIndex = 3;
			this.btn_Azalt.Text = "Seçili Ürünü Azalt";
			this.btn_Azalt.UseVisualStyleBackColor = false;
			this.btn_Azalt.Click += new System.EventHandler(this.btn_Azalt_Click);
			// 
			// btn_Arttir
			// 
			this.btn_Arttir.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(33)))), ((int)(((byte)(218)))), ((int)(((byte)(9)))));
			this.btn_Arttir.FlatAppearance.BorderSize = 0;
			this.btn_Arttir.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
			this.btn_Arttir.Font = new System.Drawing.Font("Century Gothic", 7.875F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
			this.btn_Arttir.ForeColor = System.Drawing.Color.White;
			this.btn_Arttir.Location = new System.Drawing.Point(6, 14);
			this.btn_Arttir.Margin = new System.Windows.Forms.Padding(2);
			this.btn_Arttir.Name = "btn_Arttir";
			this.btn_Arttir.Size = new System.Drawing.Size(136, 31);
			this.btn_Arttir.TabIndex = 2;
			this.btn_Arttir.Text = "Seçili Ürünü Arttır";
			this.btn_Arttir.UseVisualStyleBackColor = false;
			this.btn_Arttir.Click += new System.EventHandler(this.btn_Arttir_Click);
			// 
			// panel5
			// 
			this.panel5.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(29)))), ((int)(((byte)(29)))), ((int)(((byte)(29)))));
			this.panel5.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
			this.panel5.Controls.Add(this.lbl_ToplamTutar);
			this.panel5.Controls.Add(this.label1);
			this.panel5.Location = new System.Drawing.Point(6, 48);
			this.panel5.Margin = new System.Windows.Forms.Padding(2);
			this.panel5.Name = "panel5";
			this.panel5.Size = new System.Drawing.Size(278, 39);
			this.panel5.TabIndex = 1;
			// 
			// lbl_ToplamTutar
			// 
			this.lbl_ToplamTutar.Font = new System.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
			this.lbl_ToplamTutar.ForeColor = System.Drawing.Color.Lime;
			this.lbl_ToplamTutar.Location = new System.Drawing.Point(160, -1);
			this.lbl_ToplamTutar.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
			this.lbl_ToplamTutar.Name = "lbl_ToplamTutar";
			this.lbl_ToplamTutar.Size = new System.Drawing.Size(104, 38);
			this.lbl_ToplamTutar.TabIndex = 1;
			this.lbl_ToplamTutar.Text = "300₺";
			this.lbl_ToplamTutar.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
			// 
			// label1
			// 
			this.label1.Font = new System.Drawing.Font("Century Gothic", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
			this.label1.ForeColor = System.Drawing.Color.White;
			this.label1.Location = new System.Drawing.Point(6, 0);
			this.label1.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
			this.label1.Name = "label1";
			this.label1.Size = new System.Drawing.Size(150, 37);
			this.label1.TabIndex = 0;
			this.label1.Text = "Toplam Tutar";
			this.label1.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
			// 
			// btn_SiparisiKaydet
			// 
			this.btn_SiparisiKaydet.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(252)))), ((int)(((byte)(92)))), ((int)(((byte)(2)))));
			this.btn_SiparisiKaydet.FlatAppearance.BorderSize = 0;
			this.btn_SiparisiKaydet.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
			this.btn_SiparisiKaydet.Font = new System.Drawing.Font("Century Gothic", 10.125F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
			this.btn_SiparisiKaydet.ForeColor = System.Drawing.Color.White;
			this.btn_SiparisiKaydet.Location = new System.Drawing.Point(6, 90);
			this.btn_SiparisiKaydet.Margin = new System.Windows.Forms.Padding(2);
			this.btn_SiparisiKaydet.Name = "btn_SiparisiKaydet";
			this.btn_SiparisiKaydet.Size = new System.Drawing.Size(278, 31);
			this.btn_SiparisiKaydet.TabIndex = 0;
			this.btn_SiparisiKaydet.Text = "Siparişi Kaydet";
			this.btn_SiparisiKaydet.UseVisualStyleBackColor = false;
			this.btn_SiparisiKaydet.Click += new System.EventHandler(this.btn_SiparisiKaydet_Click);
			// 
			// dataGridView1
			// 
			this.dataGridView1.AllowUserToAddRows = false;
			this.dataGridView1.AllowUserToDeleteRows = false;
			this.dataGridView1.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
			this.dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
			this.dataGridView1.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.ad,
            this.adet,
            this.adetFiyat,
            this.toplamFiyat});
			this.dataGridView1.Dock = System.Windows.Forms.DockStyle.Fill;
			this.dataGridView1.Location = new System.Drawing.Point(0, 55);
			this.dataGridView1.Margin = new System.Windows.Forms.Padding(2);
			this.dataGridView1.Name = "dataGridView1";
			this.dataGridView1.ReadOnly = true;
			this.dataGridView1.RowHeadersVisible = false;
			this.dataGridView1.RowHeadersWidth = 82;
			this.dataGridView1.RowTemplate.Height = 33;
			this.dataGridView1.Size = new System.Drawing.Size(289, 405);
			this.dataGridView1.TabIndex = 1;
			// 
			// ad
			// 
			this.ad.HeaderText = "Ürün Adı";
			this.ad.Name = "ad";
			this.ad.ReadOnly = true;
			// 
			// adet
			// 
			this.adet.HeaderText = "Ürün Adedi";
			this.adet.Name = "adet";
			this.adet.ReadOnly = true;
			// 
			// adetFiyat
			// 
			this.adetFiyat.HeaderText = "Adet Fiyatı";
			this.adetFiyat.Name = "adetFiyat";
			this.adetFiyat.ReadOnly = true;
			// 
			// toplamFiyat
			// 
			this.toplamFiyat.HeaderText = "Toplam Fiyat";
			this.toplamFiyat.Name = "toplamFiyat";
			this.toplamFiyat.ReadOnly = true;
			// 
			// panel3
			// 
			this.panel3.Controls.Add(this.lbl_MasaAdi);
			this.panel3.Dock = System.Windows.Forms.DockStyle.Top;
			this.panel3.Location = new System.Drawing.Point(0, 0);
			this.panel3.Margin = new System.Windows.Forms.Padding(2);
			this.panel3.Name = "panel3";
			this.panel3.Size = new System.Drawing.Size(289, 55);
			this.panel3.TabIndex = 0;
			// 
			// lbl_MasaAdi
			// 
			this.lbl_MasaAdi.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(29)))), ((int)(((byte)(29)))), ((int)(((byte)(29)))));
			this.lbl_MasaAdi.Dock = System.Windows.Forms.DockStyle.Fill;
			this.lbl_MasaAdi.Font = new System.Drawing.Font("Century Gothic", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
			this.lbl_MasaAdi.ForeColor = System.Drawing.Color.White;
			this.lbl_MasaAdi.Location = new System.Drawing.Point(0, 0);
			this.lbl_MasaAdi.Name = "lbl_MasaAdi";
			this.lbl_MasaAdi.Size = new System.Drawing.Size(289, 55);
			this.lbl_MasaAdi.TabIndex = 7;
			this.lbl_MasaAdi.Text = "Rezervasyon";
			this.lbl_MasaAdi.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
			// 
			// SiparisAl
			// 
			this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
			this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
			this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(39)))), ((int)(((byte)(39)))), ((int)(((byte)(39)))));
			this.ClientSize = new System.Drawing.Size(1179, 510);
			this.Controls.Add(this.pnl_Adisyon);
			this.Controls.Add(this.pnl_Urunler);
			this.Controls.Add(this.panel1);
			this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
			this.Name = "SiparisAl";
			this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
			this.Text = "SiparisAl";
			this.Load += new System.EventHandler(this.SiparisAl_Load);
			this.panel1.ResumeLayout(false);
			this.panel10.ResumeLayout(false);
			this.pnl_Urunler.ResumeLayout(false);
			this.pnl_Adisyon.ResumeLayout(false);
			this.panel4.ResumeLayout(false);
			this.panel5.ResumeLayout(false);
			((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).EndInit();
			this.panel3.ResumeLayout(false);
			this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Label lbl_Header;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.Panel panel10;
        private System.Windows.Forms.Button btn_Exit;
        private System.Windows.Forms.Panel pnl_Urunler;
        private System.Windows.Forms.Panel pnl_Kategori;
        private System.Windows.Forms.Panel pnl_Adisyon;
        private System.Windows.Forms.Panel pnl_Urun;
        private System.Windows.Forms.Panel panel3;
        private System.Windows.Forms.Label lbl_MasaAdi;
        private System.Windows.Forms.Panel panel4;
        private System.Windows.Forms.Button btn_Azalt;
        private System.Windows.Forms.Button btn_Arttir;
        private System.Windows.Forms.Panel panel5;
        private System.Windows.Forms.Label lbl_ToplamTutar;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button btn_SiparisiKaydet;
        private System.Windows.Forms.DataGridView dataGridView1;
		private System.Windows.Forms.DataGridViewTextBoxColumn ad;
		private System.Windows.Forms.DataGridViewTextBoxColumn adet;
		private System.Windows.Forms.DataGridViewTextBoxColumn adetFiyat;
		private System.Windows.Forms.DataGridViewTextBoxColumn toplamFiyat;
	}
}