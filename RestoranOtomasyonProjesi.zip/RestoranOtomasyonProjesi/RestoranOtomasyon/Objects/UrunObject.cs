﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace RestoranOtomasyon.Objects
{
    internal class UrunObject
    {
        private int id;
        private int kategoriId;
        private string urunAdi;
        private float satisFiyati;
        private string imagePath;

        public UrunObject()
        {
        }

        public int Id { get => id; set => id = value; }
        public int KategoriId { get => kategoriId; set => kategoriId = value; }
        public string UrunAdi { get => urunAdi; set => urunAdi = value; }
        public float SatisFiyati { get => satisFiyati; set => satisFiyati = value; }
		public string ImagePath { get => imagePath; set => imagePath = value; }
	}
}
