﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace RestoranOtomasyon.Objects
{
    internal class RezervasyonObject
    {
        private int id;
        private int kullaniciId;
        private string isimSoyisim;
        private string rezervasyonTelefonNo;
        private DateTime rezervasyonSaati;
        private DateTime rezervasyonOlusturmaTarihi;
        private int masaId;
        private int rezervasyonDurumu;



        public RezervasyonObject() { 
            
        }

        public int Id { get => id; set => id = value; }
        public int KullaniciId { get => kullaniciId; set => kullaniciId = value; }
        public string IsimSoyisim { get => isimSoyisim; set => isimSoyisim = value; }
        public string RezervasyonTelefonNo { get => rezervasyonTelefonNo; set => rezervasyonTelefonNo = value; }
        public DateTime RezervasyonSaati { get => rezervasyonSaati; set => rezervasyonSaati = value; }
        public DateTime RezervasyonOlusturmaTarihi { get => rezervasyonOlusturmaTarihi; set => rezervasyonOlusturmaTarihi = value; }
        public int MasaId { get => masaId; set => masaId = value; }
        public int RezervasyonDurumu { get => rezervasyonDurumu; set => rezervasyonDurumu = value; }
    }
}
