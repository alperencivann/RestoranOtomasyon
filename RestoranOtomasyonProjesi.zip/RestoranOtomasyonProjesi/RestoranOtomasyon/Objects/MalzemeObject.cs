﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace RestoranOtomasyon.Objects
{
    internal class MalzemeObject
    {
        private int id;
        private string malzemeAdi;
        private double birimFiyati;
        private int olcuBirimi;

        public MalzemeObject()
        {
        
        }

        public int Id { get => id; set => id = value; }
        public string MalzemeAdi { get => malzemeAdi; set => malzemeAdi = value; }
        public double BirimFiyati { get => birimFiyati; set => birimFiyati = value; }
        public int OlcuBirimi { get => olcuBirimi; set => olcuBirimi = value; }
    }
}
