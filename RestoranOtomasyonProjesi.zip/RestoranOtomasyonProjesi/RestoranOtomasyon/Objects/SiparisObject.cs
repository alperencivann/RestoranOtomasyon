﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace RestoranOtomasyon.Objects
{
	internal class SiparisObject
	{
		int id;
		int adisyonId;
		int urunId;
		int siparisAdedi;
		float siparisTutari;
		DateTime? siparisTarihi;
		DateTime? mutfakTeslimTarihi;
		bool siparisTeslimDurumu;
		bool siparisOdenmeDurumu;

		public SiparisObject()
		{
		}

		public int Id { get => id; set => id = value; }
		public int AdisyonId { get => adisyonId; set => adisyonId = value; }
		public int UrunId { get => urunId; set => urunId = value; }
		public int SiparisAdedi { get => siparisAdedi; set => siparisAdedi = value; }
		public float SiparisTutari { get => siparisTutari; set => siparisTutari = value; }
		//public DateTime SiparisTarihi { get => siparisTarihi; set => siparisTarihi = value; }
		//public DateTime MutfakTeslimTarihi { get => mutfakTeslimTarihi; set => mutfakTeslimTarihi = value; }
		public DateTime? SiparisTarihi { get => siparisTarihi; set => siparisTarihi = value; }
		public DateTime? MutfakTeslimTarihi { get => mutfakTeslimTarihi; set => mutfakTeslimTarihi = value; }
		public bool SiparisTeslimDurumu { get => siparisTeslimDurumu; set => siparisTeslimDurumu = value; }
		public bool SiparisOdenmeDurumu { get => siparisOdenmeDurumu; set => siparisOdenmeDurumu = value; }
	}
}
