﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace RestoranOtomasyon.Objects
{
    internal class MasaObject
    {
        private int id;
        private string masaNo;
        private int kategoriId;
        private bool aktiflik;

        public MasaObject()
        {
        }

        public int Id { get => id; set => id = value; }
        public string MasaNo { get => masaNo; set => masaNo = value; }
        public int KategoriId { get => kategoriId; set => kategoriId = value; }
        public bool Aktiflik { get => aktiflik; set => aktiflik = value; }
    }
}
