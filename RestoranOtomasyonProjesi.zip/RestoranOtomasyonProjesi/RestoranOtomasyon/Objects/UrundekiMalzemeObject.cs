﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace RestoranOtomasyon.Objects
{
    internal class UrundekiMalzemeObject
    {
        int id;
        int urunId;
        int malzemeId;
        int miktar;

        public UrundekiMalzemeObject()
        {
        }

        public int Id { get => id; set => id = value; }
        public int UrunId { get => urunId; set => urunId = value; }
        public int MalzemeId { get => malzemeId; set => malzemeId = value; }
        public int Miktar { get => miktar; set => miktar = value; }
    }
}
