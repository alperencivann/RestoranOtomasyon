﻿using Mail.Forms;
using RestoranOtomasyon.Forms;
using RestoranOtomasyon.Functions;
using RestoranOtomasyon.Objects;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Web;
using System.Windows.Forms;

namespace RestoranOtomasyon.Components
{
    public partial class YonetimBayi : UserControl
    {
        // GLOBAL VARIABLES
        bool toggle = false;
        int id;
        string bayiAdi;
        string adres;
        string telefonNo;
        int yoneticiId;
        YonetimBayiAyarlari yonetim;

        // CONSTRUCTOR AND LOAD OBJECT
        public YonetimBayi(int id, string bayiAdi, string adres, string telefonNo, int yoneticiId, YonetimBayiAyarlari yonetim)
        {
            InitializeComponent();
            this.id = id;
            this.bayiAdi = bayiAdi;
            this.adres = adres;
            this.telefonNo = telefonNo;
            this.yoneticiId = yoneticiId;
            this.yonetim = yonetim;
        }

        private void YonetimBayi_Load(object sender, EventArgs e)
        {
            locate();
            string yetkiliAdi = "";
            Database dbKullanicilar = new Database();
            List<KullaniciObject> kullanicilar = dbKullanicilar.listKullanicilar();
            foreach (var kullanici in kullanicilar)
            {
                cbx_BayiYoneticisi.Items.Add(kullanici.KullaniciAdi);
                if (yoneticiId == kullanici.Id)
                {
                    yetkiliAdi = kullanici.KullaniciAdi;
                }
            }
            txb_BayiAdi.Text = bayiAdi;
            txb_BayiAdresi.Text = adres;
            txb_TelefonNumarasi.Text = telefonNo;
            cbx_BayiYoneticisi.SelectedItem = yetkiliAdi;
        }



        // FUNCS
        public void Message(string message)
        {
            MyMessageBox myMessageBox = new MyMessageBox(message);
            myMessageBox.ShowDialog();
        }
        public void locate()
        {
            int guncelleLocX = btn_Guncelle.Location.X;
            int right = (cbx_BayiYoneticisi.Location.X + cbx_BayiYoneticisi.Width);
            int xArea = right - guncelleLocX;
            btn_Guncelle.Width = xArea / 2 - 14;
            btn_Sil.Location = new Point(btn_Guncelle.Location.X + btn_Guncelle.Width + 14, btn_Guncelle.Location.Y);
            btn_Sil.Width = xArea / 2 - 7;
        }
        public void hideDetails()
        {
            toggle = false;
            this.Height = 38;
            pnl_Adres.Visible = false;
            pnl_TelefonNumarasi.Visible = false;
            pnl_BayiYoneticisi.Visible = false;
            pnl_Buttons.Visible = false;
        }
        public void showDetails()
        {
            toggle = true;
            this.Height = 175;
            pnl_Adres.Visible = true;
            pnl_TelefonNumarasi.Visible = true;
            pnl_BayiYoneticisi.Visible = true;
            pnl_Buttons.Visible = true;
        }


        // EVENTS
        private void label5_Click_1(object sender, EventArgs e)
        {
            if (toggle)
                hideDetails();
            else
                showDetails();
        }

        private void YonetimBayi_SizeChanged(object sender, EventArgs e)
        {
            locate();
        }

        private async void btn_Guncelle_Click(object sender, EventArgs e)
        {
            Funcs func = new Funcs();
            bool isKullaniciSelected = !(string.IsNullOrEmpty(cbx_BayiYoneticisi.Text));
            string message = "";
            bool flag = false;
            if (!isKullaniciSelected)
            {
                flag = true;
                message += "Lütfen bir kullanıcı seçiniz.\n";
            }
            if (txb_BayiAdi.Text.Length <= 0)
            {
                flag = true;
                message += "Lütfen bayi adı giriniz.\n";
            }
            if (txb_TelefonNumarasi.Text.Length > 0 && await func.isValidPhoneNumber(txb_BayiAdresi.Text))
            {
                flag = true;
                message += "Lütfen geçerli bir telefon numarası giriniz.\n";
            }
            if (flag)
            {
                Message(message);
            }
            else
            {
                Database dbKullanici = new Database();
                BayiObject bayi = new BayiObject();
                KullaniciObject kullanici = dbKullanici.getKullaniciFromName(cbx_BayiYoneticisi.Text);
                bayi.Id = this.id;
                bayi.YoneticiId = kullanici.Id;
                bayi.BayiAdresi = txb_BayiAdresi.Text;
                bayi.BayiAdi = txb_BayiAdi.Text;
                bayi.TelefonNo = txb_TelefonNumarasi.Text;
                Database database = new Database();
                string result = database.updateBayi(bayi);
                Message(result);
                yonetim.loadBayiler();
            }
        }

        private void btn_Sil_Click(object sender, EventArgs e)
        {
            Database database = new Database();
            string result = database.deleteBayi(id);
            Message(result);
        }

		private void txb_TelefonNumarasi_KeyPress(object sender, KeyPressEventArgs e)
		{
			if (!char.IsControl(e.KeyChar) && !char.IsDigit(e.KeyChar) && (e.KeyChar != '.'))
			{
				e.Handled = true;
			}
		}
	}
}
