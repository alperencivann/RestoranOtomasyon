﻿namespace RestoranOtomasyon.Components
{
	partial class YonetimUrunComp
	{
		/// <summary> 
		/// Required designer variable.
		/// </summary>
		private System.ComponentModel.IContainer components = null;

		/// <summary> 
		/// Clean up any resources being used.
		/// </summary>
		/// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
		protected override void Dispose(bool disposing)
		{
			if (disposing && (components != null))
			{
				components.Dispose();
			}
			base.Dispose(disposing);
		}

		#region Component Designer generated code

		/// <summary> 
		/// Required method for Designer support - do not modify 
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			this.pnl_KullaniciAdi = new System.Windows.Forms.Panel();
			this.btn_YeniKategoriEkle = new System.Windows.Forms.Button();
			this.txb_UrunAdi = new System.Windows.Forms.TextBox();
			this.label5 = new System.Windows.Forms.Label();
			this.pnl_KullaniciAdi.SuspendLayout();
			this.SuspendLayout();
			// 
			// pnl_KullaniciAdi
			// 
			this.pnl_KullaniciAdi.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(29)))), ((int)(((byte)(29)))), ((int)(((byte)(29)))));
			this.pnl_KullaniciAdi.Controls.Add(this.btn_YeniKategoriEkle);
			this.pnl_KullaniciAdi.Controls.Add(this.txb_UrunAdi);
			this.pnl_KullaniciAdi.Controls.Add(this.label5);
			this.pnl_KullaniciAdi.Dock = System.Windows.Forms.DockStyle.Fill;
			this.pnl_KullaniciAdi.Location = new System.Drawing.Point(0, 0);
			this.pnl_KullaniciAdi.Name = "pnl_KullaniciAdi";
			this.pnl_KullaniciAdi.Size = new System.Drawing.Size(708, 36);
			this.pnl_KullaniciAdi.TabIndex = 7;
			// 
			// btn_YeniKategoriEkle
			// 
			this.btn_YeniKategoriEkle.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
			this.btn_YeniKategoriEkle.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(2)))), ((int)(((byte)(117)))), ((int)(((byte)(252)))));
			this.btn_YeniKategoriEkle.FlatAppearance.BorderSize = 0;
			this.btn_YeniKategoriEkle.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
			this.btn_YeniKategoriEkle.Font = new System.Drawing.Font("Century Gothic", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
			this.btn_YeniKategoriEkle.ForeColor = System.Drawing.Color.White;
			this.btn_YeniKategoriEkle.Location = new System.Drawing.Point(550, 7);
			this.btn_YeniKategoriEkle.Name = "btn_YeniKategoriEkle";
			this.btn_YeniKategoriEkle.Size = new System.Drawing.Size(153, 22);
			this.btn_YeniKategoriEkle.TabIndex = 6;
			this.btn_YeniKategoriEkle.Text = "Düzenle";
			this.btn_YeniKategoriEkle.UseVisualStyleBackColor = false;
			this.btn_YeniKategoriEkle.Click += new System.EventHandler(this.btn_YeniKategoriEkle_Click);
			// 
			// txb_UrunAdi
			// 
			this.txb_UrunAdi.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
			this.txb_UrunAdi.Font = new System.Drawing.Font("Century Gothic", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
			this.txb_UrunAdi.Location = new System.Drawing.Point(151, 7);
			this.txb_UrunAdi.Name = "txb_UrunAdi";
			this.txb_UrunAdi.Size = new System.Drawing.Size(393, 22);
			this.txb_UrunAdi.TabIndex = 2;
			// 
			// label5
			// 
			this.label5.AutoSize = true;
			this.label5.Font = new System.Drawing.Font("Century Gothic", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
			this.label5.ForeColor = System.Drawing.Color.White;
			this.label5.Location = new System.Drawing.Point(19, 10);
			this.label5.Name = "label5";
			this.label5.Size = new System.Drawing.Size(56, 16);
			this.label5.TabIndex = 1;
			this.label5.Text = "Ürün Adı";
			// 
			// YonetimUrunComp
			// 
			this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
			this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
			this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(39)))), ((int)(((byte)(39)))), ((int)(((byte)(39)))));
			this.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
			this.Controls.Add(this.pnl_KullaniciAdi);
			this.Name = "YonetimUrunComp";
			this.Size = new System.Drawing.Size(708, 36);
			this.Load += new System.EventHandler(this.YonetimUrunComp_Load);
			this.pnl_KullaniciAdi.ResumeLayout(false);
			this.pnl_KullaniciAdi.PerformLayout();
			this.ResumeLayout(false);

		}

		#endregion

		private System.Windows.Forms.Panel pnl_KullaniciAdi;
		private System.Windows.Forms.TextBox txb_UrunAdi;
		private System.Windows.Forms.Label label5;
		private System.Windows.Forms.Button btn_YeniKategoriEkle;
	}
}
