﻿using Mail.Forms;
using RestoranOtomasyon.Forms;
using RestoranOtomasyon.Functions;
using RestoranOtomasyon.Objects;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Runtime.InteropServices;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace RestoranOtomasyon.Components
{
    public partial class YonetimMasaKategori : UserControl
    {
        int id;
        string kategoriAdi;
        int masaSayisi;
        GarsonEkrani garson;
        YonetimRestoranAyarlari yonetimRestoran;

        // CONSTRUCTOR AND LOAD EVENT
        public YonetimMasaKategori(int id, string kategoriAdi, int masaSayisi, GarsonEkrani garson, YonetimRestoranAyarlari yonetimRestoran)
        {
            InitializeComponent();
            this.id= id;
            this.kategoriAdi= kategoriAdi;
            this.masaSayisi = masaSayisi;
            this.garson = garson;
            this.yonetimRestoran = yonetimRestoran;
            txb_KategoriAdi.Text = kategoriAdi;
            txb_MasaSayisi.Text = masaSayisi.ToString();
        }
        private void YonetimMasaKategori_Load_1(object sender, EventArgs e)
        {
            locate();
        }


        // FUNCTIONS

        public void locate()
        {
            int guncelleLocX = btn_Guncelle.Location.X;
            int right = (txb_MasaSayisi.Location.X + txb_MasaSayisi.Width);
            int xArea =  right - guncelleLocX;
            btn_Guncelle.Width = xArea / 2 - 7;
            btn_Sil.Location = new Point(btn_Guncelle.Location.X + btn_Guncelle.Width + 14, btn_Guncelle.Location.Y);
            btn_Sil.Width = xArea / 2 - 7;
        }
        public void Message(string message)
        {
            MyMessageBox messageBox = new MyMessageBox(message);
            messageBox.Show();
        }

        // EVENTS
       
        private void YonetimMasaKategori_SizeChanged_1(object sender, EventArgs e)
        {
            locate();
        }

        private void btn_Guncelle_Click(object sender, EventArgs e)
        {
            Database deleteTablesDb = new Database();
            string deleteResult = deleteTablesDb.deleteMasaWithCategoryId(id);
            Database database= new Database();
            MasaKategoriObject masa = new MasaKategoriObject();
            masa.Id = id;
            masa.KategoriAdi = txb_KategoriAdi.Text.ToString();
            try
            {
                masa.KategoriMasaSayisi = Convert.ToInt32(txb_MasaSayisi.Text);
            }
            catch
            {
                masa.KategoriMasaSayisi = 0;
            }
            masa.Aktiflik = true;
            string result = database.updateMasaKategori(masa);
            Message(result);
            if (result.ToLower().Contains("başarılı"))
            {
                garson.listMasaKategori();
				yonetimRestoran.loadMasaKategorileri();

			}
		}

        private void button4_Click(object sender, EventArgs e)
        {
            Database database = new Database();
            string result = database.deleteMasaKategori(id);
			Database databaseMasa = new Database();
            string resultMasa = databaseMasa.deleteMasaWithCategoryId(id);    
            Message(result + "\n" + resultMasa);
            if (result.ToLower().Contains("başarılı"))
            {
                garson.listMasaKategori();
                yonetimRestoran.loadMasaKategorileri();
            }
        }

        private void txb_MasaSayisi_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!char.IsControl(e.KeyChar) && !char.IsDigit(e.KeyChar) &&
        (e.KeyChar != '.'))
            {
                e.Handled = true;
            }
        }
    }
}
