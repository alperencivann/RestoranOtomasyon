﻿using Mail.Forms;
using RestoranOtomasyon.Forms;
using RestoranOtomasyon.Functions;
using RestoranOtomasyon.Objects;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Runtime.InteropServices;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace RestoranOtomasyon.Components
{
    public partial class YonetimTelegramBot : UserControl
    {
        // GLOBAL VARIABLES
        int id;
        int kullaniciId;
        string botKey;
        string chatId;
        bool siparisBildirim;
        bool alinacaklarListesiBildirim;
        bool rezervasyonBildirim;
        bool gunlukRaporBildirim;
        bool yonetimAyariBildirim;
        bool calisanMaasBildirim;
        string botAdi;
        bool aktiflik;
        bool active = false;
        bool isOpen = false;
        YonetimTelegramBotAyarlari yonetim;

        // CONSTRUCTOR AND LOAD EVENT
        public YonetimTelegramBot(int id, int kullaniciId, string botKey, string chatId, bool siparis, bool alinacaklar, bool rezervasyon, bool gunluk, bool yonetim, bool calisan, string botAdi, bool aktiflik, YonetimTelegramBotAyarlari yonetimTelegram)
        {
            InitializeComponent();
            this.id = id;
            this.kullaniciId = kullaniciId;
            this.botKey = botKey;
            this.chatId = chatId;
            this.siparisBildirim = siparis;
            this.alinacaklarListesiBildirim = alinacaklar;
            this.rezervasyonBildirim = rezervasyon;
            this.gunlukRaporBildirim = gunluk;
            this.yonetimAyariBildirim = yonetim;
            this.calisanMaasBildirim = calisan;
            this.botAdi = botAdi;
            this.aktiflik = aktiflik;
            this.yonetim = yonetimTelegram;
        }
        private void YonetimTelegramBot_Load(object sender, EventArgs e)
        {
            txb_BotAdi.Text = botAdi;
            txb_BotKey.Text = botKey;
            txb_ChatId.Text = chatId;
            Database dbKullanicilar = new Database();
            List<KullaniciObject> kullanicilar = dbKullanicilar.listKullanicilar();
            string seciliKullanici = "";
            foreach (var kullanici in kullanicilar)
            {
                if (this.kullaniciId == kullanici.Id)
                {
                    seciliKullanici = kullanici.KullaniciAdi;
                }
                cbx_Kullanici.Items.Add(kullanici.KullaniciAdi);
            }
            cbx_Kullanici.SelectedText = seciliKullanici;
            if (this.aktiflik)
                cbx_Aktiflik.SelectedText = "Aktif";
            else
                cbx_Aktiflik.SelectedText = "Pasif";
            setSiparisBildirimleri(siparisBildirim);
            setAlinacaklarBildirimleri(alinacaklarListesiBildirim);
            setRezervasyonBildirimleri(rezervasyonBildirim);
            setGunlukBildirimleri(gunlukRaporBildirim);
            setYonetimBildirimleri(yonetimAyariBildirim);
            setCalisanBildirimleri(calisanMaasBildirim);
            hidePanels();

        }

        // FUNCS

        public void showPanels()
        {
            isOpen = true;
            pnl_Kullanici.Visible = true;
            pnl_BotKey.Visible = true;
            pnl_ChatId.Visible = true;
            pnlAktiflik.Visible = true;
            pnl_BildirimAyarlari.Visible = true;
            pnl_Kaydet.Visible = true;
            this.Height = 315;
        }
        public void hidePanels()
        {
            isOpen = false;
            pnl_Kullanici.Visible = false;
            pnl_BotKey.Visible = false;
            pnl_ChatId.Visible = false;
            pnlAktiflik.Visible = false;
            pnl_BildirimAyarlari.Visible = false;
            pnl_Kaydet.Visible = false;
            this.Height = pnl_BotAdi.Height + 2;
        }

        public void Message(string message)
        {
            MyMessageBox myMessageBox = new MyMessageBox(message);
            myMessageBox.Show();
        }
        public void setSiparisBildirimleri(bool active)
        {
            if (active)
                pbx_Siparis.Image = imageList1.Images[0];
            else
                pbx_Siparis.Image = imageList1.Images[1];
        }
        public void setAlinacaklarBildirimleri(bool active)
        {
            if (active)
                pbx_Alinacaklar.Image = imageList1.Images[0];
            else
                pbx_Alinacaklar.Image = imageList1.Images[1];
        }
        public void setRezervasyonBildirimleri(bool active)
        {
            if (active)
                pbx_Rezervasyon.Image = imageList1.Images[0];
            else
                pbx_Rezervasyon.Image = imageList1.Images[1];
        }
        public void setGunlukBildirimleri(bool active)
        {
            if (active)
                pbx_GunlukRapor.Image = imageList1.Images[0];
            else
                pbx_GunlukRapor.Image = imageList1.Images[1];
        }
        public void setYonetimBildirimleri(bool active)
        {
            if (active)
                pbx_Yonetim.Image = imageList1.Images[0];
            else
                pbx_Yonetim.Image = imageList1.Images[1];
        }
        public void setCalisanBildirimleri(bool active)
        {
            if (active)
                pbx_Calisan.Image = imageList1.Images[0];
            else
                pbx_Calisan.Image = imageList1.Images[1];
        }

        // EVENTS

        private void pnl_KullaniciAdi_Click(object sender, EventArgs e)
        {
            if (!isOpen)
                showPanels();
            else
                hidePanels();
            
        }

        private void pbx_Siparis_Click(object sender, EventArgs e)
        {
            siparisBildirim = !siparisBildirim;
            setSiparisBildirimleri(siparisBildirim);
        }

        private void pbx_Alinacaklar_Click(object sender, EventArgs e)
        {
            alinacaklarListesiBildirim = !alinacaklarListesiBildirim;
            setAlinacaklarBildirimleri(alinacaklarListesiBildirim);
        }

        private void pbx_Rezervasyon_Click(object sender, EventArgs e)
        {
            rezervasyonBildirim = !rezervasyonBildirim;
            setRezervasyonBildirimleri(rezervasyonBildirim);
        }

        private void pbx_GunlukRapor_Click(object sender, EventArgs e)
        {
            gunlukRaporBildirim = !gunlukRaporBildirim;
            setGunlukBildirimleri(gunlukRaporBildirim);
        }

        private void pbx_Yonetim_Click(object sender, EventArgs e)
        {
            yonetimAyariBildirim = !yonetimAyariBildirim;
            setYonetimBildirimleri(yonetimAyariBildirim);
        }

        private void pbx_Calisan_Click(object sender, EventArgs e)
        {
            calisanMaasBildirim = !calisanMaasBildirim;
            setCalisanBildirimleri(calisanMaasBildirim);
        }

        private void button2_Click(object sender, EventArgs e)
        {
            bool isKullaniciSelected = !(string.IsNullOrEmpty(cbx_Kullanici.Text));
            string message = "";
            bool flag = false;
            if (!isKullaniciSelected)
            {
                flag = true;
                message += "Lütfen bir kullanıcı seçiniz.\n";
            }
            if (txb_BotKey.Text.Length <= 0)
            {
                flag = true;
                message += "Lütfen bot adı giriniz.\n";
            }
            if (txb_ChatId.Text.Length <= 0)
            {
                flag = true;
                message += "Lütfen chat id giriniz.\n";
            }
            if (cbx_Aktiflik.Text.Length <= 0)
            {
                flag = true;
                message += "Lütfen aktiflik bilgisi giriniz.\n";
            }
            if (flag) {
                Message(message);
            }
            else
            {
                Database dbKullanici = new Database();
                TelegramBotObject telegram = new TelegramBotObject();
                KullaniciObject kullanici = dbKullanici.getKullaniciFromName(cbx_Kullanici.Text);
                telegram.Id = id;
                telegram.KullaniciId = kullanici.Id;
                telegram.Aktiflik = (cbx_Aktiflik.Text == "Aktif") ? true: false;
                telegram.BotKey = txb_BotKey.Text;
                telegram.ChatId = txb_ChatId.Text;
                telegram.SiparisBildirim = siparisBildirim;
                telegram.AlinacaklarListesiBildirim = alinacaklarListesiBildirim;
                telegram.RezervasyonBildirim = rezervasyonBildirim;
                telegram.GunlukRaporBildirim = gunlukRaporBildirim;
                telegram.YonetimAyariBildirim = yonetimAyariBildirim;
                telegram.CalisanMaasBildirim = calisanMaasBildirim;
                telegram.BotAdi = txb_BotAdi.Text;
                Database database = new Database();
                string result = database.updateTelegram(telegram);
                Message(result);
                yonetim.loadTelegram();
            }
            
        }

        private void pnl_BotAdi_Paint(object sender, PaintEventArgs e)
        {

        }

        private void txb_BotAdi_TextChanged(object sender, EventArgs e)
        {

        }
    }
}
