﻿namespace RestoranOtomasyon.Components
{
    partial class MasaKategori
    {

        #region Bileşen Tasarımcısı üretimi kod

        #endregion

        private System.Windows.Forms.Label lbl_KategoriAdi;
    }
}
