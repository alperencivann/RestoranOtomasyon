﻿namespace RestoranOtomasyon.Components
{
    partial class YonetimBayi
    {
        /// <summary> 
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Component Designer generated code

        /// <summary> 
        /// Required method for Designer support - do not modify 
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
			this.panel1 = new System.Windows.Forms.Panel();
			this.pnl_Buttons = new System.Windows.Forms.Panel();
			this.btn_Sil = new System.Windows.Forms.Button();
			this.btn_Guncelle = new System.Windows.Forms.Button();
			this.pnl_BayiYoneticisi = new System.Windows.Forms.Panel();
			this.cbx_BayiYoneticisi = new System.Windows.Forms.ComboBox();
			this.label3 = new System.Windows.Forms.Label();
			this.pnl_TelefonNumarasi = new System.Windows.Forms.Panel();
			this.txb_TelefonNumarasi = new System.Windows.Forms.TextBox();
			this.label2 = new System.Windows.Forms.Label();
			this.pnl_Adres = new System.Windows.Forms.Panel();
			this.txb_BayiAdresi = new System.Windows.Forms.TextBox();
			this.label1 = new System.Windows.Forms.Label();
			this.pnl_Bayi = new System.Windows.Forms.Panel();
			this.txb_BayiAdi = new System.Windows.Forms.TextBox();
			this.label5 = new System.Windows.Forms.Label();
			this.panel1.SuspendLayout();
			this.pnl_Buttons.SuspendLayout();
			this.pnl_BayiYoneticisi.SuspendLayout();
			this.pnl_TelefonNumarasi.SuspendLayout();
			this.pnl_Adres.SuspendLayout();
			this.pnl_Bayi.SuspendLayout();
			this.SuspendLayout();
			// 
			// panel1
			// 
			this.panel1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(29)))), ((int)(((byte)(29)))), ((int)(((byte)(29)))));
			this.panel1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
			this.panel1.Controls.Add(this.pnl_Buttons);
			this.panel1.Controls.Add(this.pnl_BayiYoneticisi);
			this.panel1.Controls.Add(this.pnl_TelefonNumarasi);
			this.panel1.Controls.Add(this.pnl_Adres);
			this.panel1.Controls.Add(this.pnl_Bayi);
			this.panel1.Dock = System.Windows.Forms.DockStyle.Fill;
			this.panel1.Location = new System.Drawing.Point(0, 0);
			this.panel1.Name = "panel1";
			this.panel1.Size = new System.Drawing.Size(732, 175);
			this.panel1.TabIndex = 1;
			// 
			// pnl_Buttons
			// 
			this.pnl_Buttons.Controls.Add(this.btn_Sil);
			this.pnl_Buttons.Controls.Add(this.btn_Guncelle);
			this.pnl_Buttons.Dock = System.Windows.Forms.DockStyle.Top;
			this.pnl_Buttons.Location = new System.Drawing.Point(0, 132);
			this.pnl_Buttons.Name = "pnl_Buttons";
			this.pnl_Buttons.Size = new System.Drawing.Size(730, 39);
			this.pnl_Buttons.TabIndex = 14;
			// 
			// btn_Sil
			// 
			this.btn_Sil.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(252)))), ((int)(((byte)(2)))), ((int)(((byte)(2)))));
			this.btn_Sil.FlatAppearance.BorderSize = 0;
			this.btn_Sil.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
			this.btn_Sil.Font = new System.Drawing.Font("Century Gothic", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
			this.btn_Sil.ForeColor = System.Drawing.Color.White;
			this.btn_Sil.Location = new System.Drawing.Point(432, 6);
			this.btn_Sil.Name = "btn_Sil";
			this.btn_Sil.Size = new System.Drawing.Size(265, 25);
			this.btn_Sil.TabIndex = 13;
			this.btn_Sil.Text = "Sil";
			this.btn_Sil.UseVisualStyleBackColor = false;
			this.btn_Sil.Click += new System.EventHandler(this.btn_Sil_Click);
			// 
			// btn_Guncelle
			// 
			this.btn_Guncelle.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(2)))), ((int)(((byte)(117)))), ((int)(((byte)(252)))));
			this.btn_Guncelle.FlatAppearance.BorderSize = 0;
			this.btn_Guncelle.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
			this.btn_Guncelle.Font = new System.Drawing.Font("Century Gothic", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
			this.btn_Guncelle.ForeColor = System.Drawing.Color.White;
			this.btn_Guncelle.Location = new System.Drawing.Point(151, 6);
			this.btn_Guncelle.Name = "btn_Guncelle";
			this.btn_Guncelle.Size = new System.Drawing.Size(265, 25);
			this.btn_Guncelle.TabIndex = 12;
			this.btn_Guncelle.Text = "Güncelle";
			this.btn_Guncelle.UseVisualStyleBackColor = false;
			this.btn_Guncelle.Click += new System.EventHandler(this.btn_Guncelle_Click);
			// 
			// pnl_BayiYoneticisi
			// 
			this.pnl_BayiYoneticisi.Controls.Add(this.cbx_BayiYoneticisi);
			this.pnl_BayiYoneticisi.Controls.Add(this.label3);
			this.pnl_BayiYoneticisi.Dock = System.Windows.Forms.DockStyle.Top;
			this.pnl_BayiYoneticisi.Location = new System.Drawing.Point(0, 99);
			this.pnl_BayiYoneticisi.Name = "pnl_BayiYoneticisi";
			this.pnl_BayiYoneticisi.Size = new System.Drawing.Size(730, 33);
			this.pnl_BayiYoneticisi.TabIndex = 9;
			// 
			// cbx_BayiYoneticisi
			// 
			this.cbx_BayiYoneticisi.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
			this.cbx_BayiYoneticisi.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
			this.cbx_BayiYoneticisi.Font = new System.Drawing.Font("Century Gothic", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
			this.cbx_BayiYoneticisi.FormattingEnabled = true;
			this.cbx_BayiYoneticisi.Location = new System.Drawing.Point(151, 5);
			this.cbx_BayiYoneticisi.Name = "cbx_BayiYoneticisi";
			this.cbx_BayiYoneticisi.Size = new System.Drawing.Size(546, 25);
			this.cbx_BayiYoneticisi.TabIndex = 4;
			// 
			// label3
			// 
			this.label3.AutoSize = true;
			this.label3.Font = new System.Drawing.Font("Century Gothic", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
			this.label3.ForeColor = System.Drawing.Color.White;
			this.label3.Location = new System.Drawing.Point(21, 9);
			this.label3.Name = "label3";
			this.label3.Size = new System.Drawing.Size(92, 17);
			this.label3.TabIndex = 1;
			this.label3.Text = "Bayi Yöneticisi";
			// 
			// pnl_TelefonNumarasi
			// 
			this.pnl_TelefonNumarasi.Controls.Add(this.txb_TelefonNumarasi);
			this.pnl_TelefonNumarasi.Controls.Add(this.label2);
			this.pnl_TelefonNumarasi.Dock = System.Windows.Forms.DockStyle.Top;
			this.pnl_TelefonNumarasi.Location = new System.Drawing.Point(0, 66);
			this.pnl_TelefonNumarasi.Name = "pnl_TelefonNumarasi";
			this.pnl_TelefonNumarasi.Size = new System.Drawing.Size(730, 33);
			this.pnl_TelefonNumarasi.TabIndex = 8;
			// 
			// txb_TelefonNumarasi
			// 
			this.txb_TelefonNumarasi.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
			this.txb_TelefonNumarasi.Font = new System.Drawing.Font("Century Gothic", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
			this.txb_TelefonNumarasi.Location = new System.Drawing.Point(153, 6);
			this.txb_TelefonNumarasi.Name = "txb_TelefonNumarasi";
			this.txb_TelefonNumarasi.Size = new System.Drawing.Size(544, 22);
			this.txb_TelefonNumarasi.TabIndex = 2;
			this.txb_TelefonNumarasi.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txb_TelefonNumarasi_KeyPress);
			// 
			// label2
			// 
			this.label2.AutoSize = true;
			this.label2.Font = new System.Drawing.Font("Century Gothic", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
			this.label2.ForeColor = System.Drawing.Color.White;
			this.label2.Location = new System.Drawing.Point(21, 9);
			this.label2.Name = "label2";
			this.label2.Size = new System.Drawing.Size(109, 17);
			this.label2.TabIndex = 1;
			this.label2.Text = "Telefon Numarası";
			// 
			// pnl_Adres
			// 
			this.pnl_Adres.Controls.Add(this.txb_BayiAdresi);
			this.pnl_Adres.Controls.Add(this.label1);
			this.pnl_Adres.Dock = System.Windows.Forms.DockStyle.Top;
			this.pnl_Adres.Location = new System.Drawing.Point(0, 33);
			this.pnl_Adres.Name = "pnl_Adres";
			this.pnl_Adres.Size = new System.Drawing.Size(730, 33);
			this.pnl_Adres.TabIndex = 7;
			// 
			// txb_BayiAdresi
			// 
			this.txb_BayiAdresi.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
			this.txb_BayiAdresi.Font = new System.Drawing.Font("Century Gothic", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
			this.txb_BayiAdresi.Location = new System.Drawing.Point(153, 6);
			this.txb_BayiAdresi.Name = "txb_BayiAdresi";
			this.txb_BayiAdresi.Size = new System.Drawing.Size(544, 22);
			this.txb_BayiAdresi.TabIndex = 2;
			// 
			// label1
			// 
			this.label1.AutoSize = true;
			this.label1.Font = new System.Drawing.Font("Century Gothic", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
			this.label1.ForeColor = System.Drawing.Color.White;
			this.label1.Location = new System.Drawing.Point(21, 9);
			this.label1.Name = "label1";
			this.label1.Size = new System.Drawing.Size(72, 17);
			this.label1.TabIndex = 1;
			this.label1.Text = "Bayi Adresi";
			// 
			// pnl_Bayi
			// 
			this.pnl_Bayi.Controls.Add(this.txb_BayiAdi);
			this.pnl_Bayi.Controls.Add(this.label5);
			this.pnl_Bayi.Dock = System.Windows.Forms.DockStyle.Top;
			this.pnl_Bayi.Location = new System.Drawing.Point(0, 0);
			this.pnl_Bayi.Name = "pnl_Bayi";
			this.pnl_Bayi.Size = new System.Drawing.Size(730, 33);
			this.pnl_Bayi.TabIndex = 6;
			this.pnl_Bayi.Click += new System.EventHandler(this.label5_Click_1);
			// 
			// txb_BayiAdi
			// 
			this.txb_BayiAdi.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
			this.txb_BayiAdi.Font = new System.Drawing.Font("Century Gothic", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
			this.txb_BayiAdi.Location = new System.Drawing.Point(153, 6);
			this.txb_BayiAdi.Name = "txb_BayiAdi";
			this.txb_BayiAdi.Size = new System.Drawing.Size(544, 22);
			this.txb_BayiAdi.TabIndex = 2;
			this.txb_BayiAdi.Click += new System.EventHandler(this.label5_Click_1);
			// 
			// label5
			// 
			this.label5.AutoSize = true;
			this.label5.Font = new System.Drawing.Font("Century Gothic", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
			this.label5.ForeColor = System.Drawing.Color.White;
			this.label5.Location = new System.Drawing.Point(21, 9);
			this.label5.Name = "label5";
			this.label5.Size = new System.Drawing.Size(55, 17);
			this.label5.TabIndex = 1;
			this.label5.Text = "Bayi Adı";
			this.label5.Click += new System.EventHandler(this.label5_Click_1);
			// 
			// YonetimBayi
			// 
			this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
			this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
			this.Controls.Add(this.panel1);
			this.Name = "YonetimBayi";
			this.Size = new System.Drawing.Size(732, 175);
			this.Load += new System.EventHandler(this.YonetimBayi_Load);
			this.SizeChanged += new System.EventHandler(this.YonetimBayi_SizeChanged);
			this.panel1.ResumeLayout(false);
			this.pnl_Buttons.ResumeLayout(false);
			this.pnl_BayiYoneticisi.ResumeLayout(false);
			this.pnl_BayiYoneticisi.PerformLayout();
			this.pnl_TelefonNumarasi.ResumeLayout(false);
			this.pnl_TelefonNumarasi.PerformLayout();
			this.pnl_Adres.ResumeLayout(false);
			this.pnl_Adres.PerformLayout();
			this.pnl_Bayi.ResumeLayout(false);
			this.pnl_Bayi.PerformLayout();
			this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Panel pnl_Buttons;
        private System.Windows.Forms.Button btn_Sil;
        private System.Windows.Forms.Button btn_Guncelle;
        private System.Windows.Forms.Panel pnl_BayiYoneticisi;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Panel pnl_TelefonNumarasi;
        private System.Windows.Forms.TextBox txb_TelefonNumarasi;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Panel pnl_Adres;
        private System.Windows.Forms.TextBox txb_BayiAdresi;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Panel pnl_Bayi;
        private System.Windows.Forms.TextBox txb_BayiAdi;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.ComboBox cbx_BayiYoneticisi;
    }
}
