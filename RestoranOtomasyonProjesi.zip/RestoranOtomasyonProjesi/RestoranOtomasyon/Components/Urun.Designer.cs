﻿namespace RestoranOtomasyon.Components
{
    partial class Urun
    {
        /// <summary> 
        ///Gerekli tasarımcı değişkeni.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        ///Kullanılan tüm kaynakları temizleyin.
        /// </summary>
        ///<param name="disposing">yönetilen kaynaklar dispose edilmeliyse doğru; aksi halde yanlış.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Bileşen Tasarımcısı üretimi kod

        /// <summary> 
        /// Tasarımcı desteği için gerekli metot - bu metodun 
        ///içeriğini kod düzenleyici ile değiştirmeyin.
        /// </summary>
        private void InitializeComponent()
        {
			System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Urun));
			this.panel1 = new System.Windows.Forms.Panel();
			this.panel2 = new System.Windows.Forms.Panel();
			this.panel3 = new System.Windows.Forms.Panel();
			this.panel5 = new System.Windows.Forms.Panel();
			this.lbl_Fiyat = new System.Windows.Forms.Label();
			this.lbl_UrunAdi = new System.Windows.Forms.Label();
			this.panel4 = new System.Windows.Forms.Panel();
			this.pictureBox1 = new System.Windows.Forms.PictureBox();
			this.panel3.SuspendLayout();
			this.panel5.SuspendLayout();
			this.panel4.SuspendLayout();
			((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
			this.SuspendLayout();
			// 
			// panel1
			// 
			this.panel1.Dock = System.Windows.Forms.DockStyle.Left;
			this.panel1.Location = new System.Drawing.Point(0, 0);
			this.panel1.Name = "panel1";
			this.panel1.Size = new System.Drawing.Size(5, 112);
			this.panel1.TabIndex = 0;
			this.panel1.Click += new System.EventHandler(this.pictureBox1_Click);
			// 
			// panel2
			// 
			this.panel2.Dock = System.Windows.Forms.DockStyle.Right;
			this.panel2.Location = new System.Drawing.Point(155, 0);
			this.panel2.Name = "panel2";
			this.panel2.Size = new System.Drawing.Size(5, 112);
			this.panel2.TabIndex = 1;
			this.panel2.Click += new System.EventHandler(this.pictureBox1_Click);
			// 
			// panel3
			// 
			this.panel3.Controls.Add(this.panel5);
			this.panel3.Controls.Add(this.panel4);
			this.panel3.Cursor = System.Windows.Forms.Cursors.Hand;
			this.panel3.Dock = System.Windows.Forms.DockStyle.Fill;
			this.panel3.Location = new System.Drawing.Point(5, 0);
			this.panel3.Name = "panel3";
			this.panel3.Size = new System.Drawing.Size(150, 112);
			this.panel3.TabIndex = 2;
			this.panel3.Click += new System.EventHandler(this.pictureBox1_Click);
			// 
			// panel5
			// 
			this.panel5.Controls.Add(this.lbl_Fiyat);
			this.panel5.Controls.Add(this.lbl_UrunAdi);
			this.panel5.Cursor = System.Windows.Forms.Cursors.Hand;
			this.panel5.Dock = System.Windows.Forms.DockStyle.Fill;
			this.panel5.Location = new System.Drawing.Point(0, 87);
			this.panel5.Name = "panel5";
			this.panel5.Size = new System.Drawing.Size(150, 25);
			this.panel5.TabIndex = 1;
			this.panel5.Click += new System.EventHandler(this.pictureBox1_Click);
			// 
			// lbl_Fiyat
			// 
			this.lbl_Fiyat.Cursor = System.Windows.Forms.Cursors.Hand;
			this.lbl_Fiyat.Dock = System.Windows.Forms.DockStyle.Right;
			this.lbl_Fiyat.Font = new System.Drawing.Font("Century Gothic", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
			this.lbl_Fiyat.ForeColor = System.Drawing.Color.Lime;
			this.lbl_Fiyat.Location = new System.Drawing.Point(92, 0);
			this.lbl_Fiyat.Name = "lbl_Fiyat";
			this.lbl_Fiyat.RightToLeft = System.Windows.Forms.RightToLeft.No;
			this.lbl_Fiyat.Size = new System.Drawing.Size(58, 25);
			this.lbl_Fiyat.TabIndex = 1;
			this.lbl_Fiyat.Text = "label1";
			this.lbl_Fiyat.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
			this.lbl_Fiyat.Click += new System.EventHandler(this.pictureBox1_Click);
			// 
			// lbl_UrunAdi
			// 
			this.lbl_UrunAdi.Cursor = System.Windows.Forms.Cursors.Hand;
			this.lbl_UrunAdi.Dock = System.Windows.Forms.DockStyle.Left;
			this.lbl_UrunAdi.Font = new System.Drawing.Font("Century Gothic", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
			this.lbl_UrunAdi.ForeColor = System.Drawing.Color.White;
			this.lbl_UrunAdi.Location = new System.Drawing.Point(0, 0);
			this.lbl_UrunAdi.Name = "lbl_UrunAdi";
			this.lbl_UrunAdi.RightToLeft = System.Windows.Forms.RightToLeft.No;
			this.lbl_UrunAdi.Size = new System.Drawing.Size(86, 25);
			this.lbl_UrunAdi.TabIndex = 0;
			this.lbl_UrunAdi.Text = "lbl_UrunAdi";
			this.lbl_UrunAdi.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
			this.lbl_UrunAdi.Click += new System.EventHandler(this.pictureBox1_Click);
			// 
			// panel4
			// 
			this.panel4.Controls.Add(this.pictureBox1);
			this.panel4.Cursor = System.Windows.Forms.Cursors.Hand;
			this.panel4.Dock = System.Windows.Forms.DockStyle.Top;
			this.panel4.Location = new System.Drawing.Point(0, 0);
			this.panel4.Name = "panel4";
			this.panel4.Size = new System.Drawing.Size(150, 87);
			this.panel4.TabIndex = 0;
			this.panel4.Click += new System.EventHandler(this.pictureBox1_Click);
			// 
			// pictureBox1
			// 
			this.pictureBox1.Cursor = System.Windows.Forms.Cursors.Hand;
			this.pictureBox1.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox1.Image")));
			this.pictureBox1.Location = new System.Drawing.Point(6, 9);
			this.pictureBox1.Name = "pictureBox1";
			this.pictureBox1.Size = new System.Drawing.Size(138, 78);
			this.pictureBox1.TabIndex = 0;
			this.pictureBox1.TabStop = false;
			this.pictureBox1.Click += new System.EventHandler(this.pictureBox1_Click_1);
			// 
			// Urun
			// 
			this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
			this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
			this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(29)))), ((int)(((byte)(29)))), ((int)(((byte)(29)))));
			this.Controls.Add(this.panel3);
			this.Controls.Add(this.panel2);
			this.Controls.Add(this.panel1);
			this.Name = "Urun";
			this.Size = new System.Drawing.Size(160, 112);
			this.panel3.ResumeLayout(false);
			this.panel5.ResumeLayout(false);
			this.panel4.ResumeLayout(false);
			((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
			this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.Panel panel3;
        private System.Windows.Forms.Panel panel5;
        private System.Windows.Forms.Label lbl_Fiyat;
        private System.Windows.Forms.Label lbl_UrunAdi;
        private System.Windows.Forms.Panel panel4;
        private System.Windows.Forms.PictureBox pictureBox1;
    }
}
