﻿using RestoranOtomasyon.Forms;
using RestoranOtomasyon.Functions;
using RestoranOtomasyon.Objects;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace RestoranOtomasyon.Components
{
    public partial class Masa : UserControl
    {
        int id;
        int kategoriId;
        string No;
        string KategoriAdi;
        GarsonEkrani garson;
        public Masa(string masaNo, string kategoriAdi, int kategoriId, int id, GarsonEkrani garson)
        {
            InitializeComponent();
            this.No = masaNo;
            this.KategoriAdi = kategoriAdi;
            this.id = id;
            this.kategoriId = kategoriId;
            this.garson = garson;
            label5.Text = kategoriAdi + " - " + No;
            Database db = new Database();
            AdisyonObject adisyon = db.getAdisyonFromMasaIdWhereIsActive(id);
            if (adisyon.Id > 0)
            {
                this.BackColor = Color.ForestGreen;
                
            }
        }

        private void pictureBox2_Click(object sender, EventArgs e)
        { // rezerve et
            RezerveEt rezervasyonForm = new RezerveEt();
            rezervasyonForm.secilenMasaId = this.id;
            rezervasyonForm.secilenKategoriId = this.kategoriId;
            rezervasyonForm.ShowDialog();
        }

        private void pictureBox1_Click(object sender2, EventArgs e)
        { // sipariş al
            SiparisAl siparisForm = new SiparisAl(this.id);
			siparisForm.FormClosing += (sender, args) =>
			{
				garson.listMasa(kategoriId,KategoriAdi);
			};
			siparisForm.ShowDialog();

        }

        private void pictureBox3_Click(object sender, EventArgs e)
        { // hesabı böl
            HesapAl hesapAl = new HesapAl(id,kategoriId,KategoriAdi, No);
            hesapAl.ShowDialog();
        }

        private void pictureBox4_Click(object sender2, EventArgs e)
        { // hesap al
			HesapAl hesapAl = new HesapAl(id, kategoriId, KategoriAdi, No);
			hesapAl.FormClosing += (sender, args) =>
			{
				garson.listMasa(kategoriId, KategoriAdi);
			};
			hesapAl.ShowDialog();
		}

		private void panel4_Paint(object sender, PaintEventArgs e)
		{

		}
	}
}
