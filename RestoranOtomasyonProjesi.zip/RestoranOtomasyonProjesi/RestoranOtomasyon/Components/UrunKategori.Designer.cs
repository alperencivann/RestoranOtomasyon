﻿namespace RestoranOtomasyon.Components
{
    partial class UrunKategori
    {

        #region Bileşen Tasarımcısı üretimi kod

        #endregion

        private System.Windows.Forms.Label label1;
    }
}
