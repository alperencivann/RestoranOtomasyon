﻿using Mail.Forms;
using RestoranOtomasyon.Forms;
using RestoranOtomasyon.Functions;
using RestoranOtomasyon.Objects;
using System;
using System.Collections.Generic;
using System.Drawing;
using System.Windows.Forms;

namespace RestoranOtomasyon.Components
{
    public partial class YonetimKullanici : UserControl
    {

        // GLOBAL VARIABLES
        public int id;
        public string kullaniciAdi;
        public string telefonNo;
        public string adres;
        public string iban;
        public int maas;
        public int yetkiId;
        public YonetimKullaniciAyarlari kullaniciAyarEkrani;

        bool toggle = false;

        // CONSTRUCTOR AND LOAD EVENT

        public YonetimKullanici(int id, string kullaniciAdi, string telefonNo, string adres, string iban, int maas, int yetkiId, YonetimKullaniciAyarlari kullaniciAyarEkrani)
        {
            InitializeComponent();
            this.id = id;
            this.kullaniciAdi = kullaniciAdi;
            this.telefonNo = telefonNo;
            this.adres = adres;
            this.iban = iban;
            this.maas = maas;
            this.yetkiId = yetkiId;
            this.kullaniciAyarEkrani = kullaniciAyarEkrani;
            txb_KullaniciAdi.Text = kullaniciAdi;
            txb_Adres.Text = adres;
            txb_TelefonNumarasi.Text = telefonNo;
            txb_Iban.Text = iban;
            txb_Maas.Text = maas.ToString();
            // db'den yetki id'nin yetki adı çekilecek

        }
        private void YonetimKullanici_Load(object sender, EventArgs e)
        {
            locate();
            hideDetails();
            cbx_YetkiTipi.DropDownStyle = ComboBoxStyle.DropDownList;
            loadYetkiler();

        }
        // FUNCS
        public void Message(string message)
        {
            MyMessageBox msg = new MyMessageBox(message);
            msg.ShowDialog();
        }
        public void loadYetkiler()
        {
            Database database = new Database();
            List<YetkiObject> yetkiler = database.listYetkiler();
            string yetkiName = "";
            foreach (var yetki in yetkiler)
            {
                cbx_YetkiTipi.Items.Add(yetki.YetkiAdi);
                if (yetki.Id == yetkiId)
                {
                    yetkiName = yetki.YetkiAdi;
                }
            }
            cbx_YetkiTipi.SelectedItem = yetkiName;

        }
        public void locate()
        {
            int guncelleLocX = btn_Guncelle.Location.X;
            int right = (cbx_YetkiTipi.Location.X + cbx_YetkiTipi.Width);
            int xArea = right - guncelleLocX;
            btn_Guncelle.Width = xArea / 2 - 7;
            btn_Sil.Location = new Point(btn_Guncelle.Location.X + btn_Guncelle.Width + 14, btn_Guncelle.Location.Y);
            btn_Sil.Width = xArea / 2 - 7;
        }
        public void hideDetails()
        {
            toggle = false;
            this.Height = 38;
            pnl_TelefonNumarasi.Visible = false;
            pnl_Adres.Visible = false;
            pnl_Iban.Visible = false;
            pnl_Maas.Visible = false;
            pnl_YetkiTipi.Visible = false;
            pnl_Buttons.Visible = false;
        }
        public void showDetails()
        {
            toggle = true;
            this.Height = 238;
            pnl_TelefonNumarasi.Visible = true;
            pnl_Adres.Visible = true;
            pnl_Iban.Visible = true;
            pnl_Maas.Visible = true;
            pnl_YetkiTipi.Visible = true;
            pnl_Buttons.Visible = true;
        }

        public void focusThis()
        {
            kullaniciAyarEkrani.focusKullaniciId(id);
        }

        // EVENTS

        private void YonetimKullanici_SizeChanged(object sender, EventArgs e)
        {
            locate();
        }

        private void btn_Guncelle_Click(object sender, EventArgs e)
        {
            
            KullaniciObject kullanici = new KullaniciObject();
            kullanici.Id = id;
            kullanici.KullaniciAdi = txb_KullaniciAdi.Text;
            kullanici.KullaniciTelefonNumarasi = txb_TelefonNumarasi.Text;
            kullanici.KullaniciIban = txb_Iban.Text;
            try
            {
                kullanici.KullaniciMaasi = Convert.ToInt32(txb_Maas.Text);
            }
            catch
            {
                kullanici.KullaniciMaasi = 0;
            }
            kullanici.KullaniciAdresi = txb_Adres.Text;

            if (kullanici.KullaniciAdi.Length < 1)
            {
                Message("Lütfen bir kullanici adı giriniz.");
            }
            else if (kullanici.KullaniciTelefonNumarasi.Length < 1)
            {
                Message("Lütfen telefon numarası giriniz.");
            }
            else if (kullanici.KullaniciAdresi.Length < 1)
            {
                Message("Lütfen adres bilgisi giriniz.");
            }
            else if (string.IsNullOrEmpty(cbx_YetkiTipi.Text))
            {
                Message("Lütfen yetki seçiniz.");
            }
            else
            {
                Database yetkiDb = new Database();
                YetkiObject yetkisi = yetkiDb.getYetkiFromName(cbx_YetkiTipi.Text);
                kullanici.YetkiId = yetkisi.Id;
                Database database = new Database();
                string result = database.updateKullanici(kullanici);
                Message(result);
                kullaniciAyarEkrani.loadKullanicilar();
            }

        }

        private void btn_Sil_Click(object sender, EventArgs e)
        {
            Database database = new Database();
            string result = database.deleteKullanici(id);
            Message(result);
            kullaniciAyarEkrani.loadKullanicilar();

        }

        private void label5_Click(object sender, EventArgs e)
        {
            if (toggle == true)
            {
                hideDetails();
                locate();
            }
            else
            {
                focusThis();
                locate();
            }
        }

		private void txb_TelefonNumarasi_KeyPress(object sender, KeyPressEventArgs e)
		{
			if (!char.IsControl(e.KeyChar) && !char.IsDigit(e.KeyChar) &&
		(e.KeyChar != '.'))
			{
				e.Handled = true;
			}
		}

		private void txb_Maas_KeyPress(object sender, KeyPressEventArgs e)
		{
			if (!char.IsControl(e.KeyChar) && !char.IsDigit(e.KeyChar) &&
		(e.KeyChar != '.'))
			{
				e.Handled = true;
			}
		}
	}
}
