﻿using Mail.Forms;
using RestoranOtomasyon.Forms;
using RestoranOtomasyon.Functions;
using RestoranOtomasyon.Objects;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace RestoranOtomasyon.Components
{
	public partial class MutfakSiparisComponent : UserControl
	{
		// global variables
		int siparisId;
		string imagePath;
		string urunAdi;
		int adet;
		string siparisSaati;
		string siparisNotlari;
		MutfakEkrani mutfak;

		// constructor 
		public MutfakSiparisComponent(int siparisId,string imagePath, string urunAdi, int adet, string siparisSaati, string siparisNotlari,MutfakEkrani mutfak)
		{
			InitializeComponent();
			this.siparisId = siparisId;
			this.imagePath = imagePath;
			this.urunAdi = urunAdi;
			this.adet = adet;
			this.siparisSaati = siparisSaati;
			this.siparisNotlari = siparisNotlari;
			this.mutfak = mutfak;
			try
			{
				pcb_UrunResmi.Image = Image.FromFile(this.imagePath);
			}
			catch{}
			lbl_UrunAdi.Text = this.urunAdi;
			lbl_Adet.Text = this.adet.ToString();
			lbl_SiparisSaati.Text = this.siparisSaati;
			lbl_Notlar.Text = this.siparisNotlari;
			lbl_Id.Text = siparisId.ToString();
			panel11.Dock = DockStyle.Fill;
		}
		// funcs
		public void Message(string message)
		{
			MyMessageBox myMessageBox = new MyMessageBox(message);
			myMessageBox.ShowDialog();
		}
		// events

		private void btn_TeslimEt_Click(object sender, EventArgs e)
		{
			Database db = new Database();
			SiparisObject siparis = db.getSiparis(siparisId);
			siparis.SiparisTeslimDurumu = true;
			Database updateDb = new Database();
			siparis.MutfakTeslimTarihi = DateTime.Now;
			string result = updateDb.updateSiparis(siparis);
			Message(result);
			mutfak.loadSiparisler();

		}

		private void btn_IptalEt_Click_1(object sender, EventArgs e)
		{
			Database db = new Database();
			string result = db.deleteSiparis(siparisId);
			Message(result);
			mutfak.loadSiparisler();
		}
	}
}
