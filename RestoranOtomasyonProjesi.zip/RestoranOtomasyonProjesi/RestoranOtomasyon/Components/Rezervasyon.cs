﻿using RestoranOtomasyon.Forms;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace RestoranOtomasyon.Components
{
    public partial class Rezervasyon : UserControl
    {
        int id;
        string isimSoyisim;
        DateTime rezervasyonSaati;
        int masaId;

        public Rezervasyon(int id, string isim, DateTime rezervasyonSaati, int masaId)
        {
            InitializeComponent();
            this.id = id;
            this.isimSoyisim = isim;
            this.rezervasyonSaati = rezervasyonSaati;
            this.masaId = masaId;
            string rezSaat = "";
            lbl_IsimSoyisim.Text = isimSoyisim;
            if (rezervasyonSaati.Minute < 10)
                rezSaat = rezervasyonSaati.Hour.ToString() + ":0" + rezervasyonSaati.Minute.ToString();
            else
				rezSaat = rezervasyonSaati.Hour.ToString() + ":" + rezervasyonSaati.Minute.ToString();

			lbl_RezervasyonSaati.Text = rezSaat + " Rezervasyon";
            
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

		private void pictureBox1_Click(object sender, EventArgs e)
		{
            RezerveEt rezerve = new RezerveEt(id);
            rezerve.ShowDialog();
		}
	}
}
