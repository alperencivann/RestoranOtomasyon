﻿namespace RestoranOtomasyon.Components
{
    partial class YonetimTelegramBot
    {
        /// <summary> 
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Component Designer generated code

        /// <summary> 
        /// Required method for Designer support - do not modify 
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(YonetimTelegramBot));
            this.pnl_BotAdi = new System.Windows.Forms.Panel();
            this.txb_BotAdi = new System.Windows.Forms.TextBox();
            this.label5 = new System.Windows.Forms.Label();
            this.pnl_Kullanici = new System.Windows.Forms.Panel();
            this.cbx_Kullanici = new System.Windows.Forms.ComboBox();
            this.label1 = new System.Windows.Forms.Label();
            this.pnl_BotKey = new System.Windows.Forms.Panel();
            this.txb_BotKey = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.pnl_ChatId = new System.Windows.Forms.Panel();
            this.txb_ChatId = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.pnlAktiflik = new System.Windows.Forms.Panel();
            this.cbx_Aktiflik = new System.Windows.Forms.ComboBox();
            this.label4 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.panel5 = new System.Windows.Forms.Panel();
            this.label7 = new System.Windows.Forms.Label();
            this.pbx_Siparis = new System.Windows.Forms.PictureBox();
            this.panel6 = new System.Windows.Forms.Panel();
            this.label8 = new System.Windows.Forms.Label();
            this.pbx_Alinacaklar = new System.Windows.Forms.PictureBox();
            this.panel7 = new System.Windows.Forms.Panel();
            this.label9 = new System.Windows.Forms.Label();
            this.pbx_Rezervasyon = new System.Windows.Forms.PictureBox();
            this.panel8 = new System.Windows.Forms.Panel();
            this.label10 = new System.Windows.Forms.Label();
            this.pbx_Calisan = new System.Windows.Forms.PictureBox();
            this.panel9 = new System.Windows.Forms.Panel();
            this.label11 = new System.Windows.Forms.Label();
            this.pbx_Yonetim = new System.Windows.Forms.PictureBox();
            this.panel10 = new System.Windows.Forms.Panel();
            this.label12 = new System.Windows.Forms.Label();
            this.pbx_GunlukRapor = new System.Windows.Forms.PictureBox();
            this.imageList1 = new System.Windows.Forms.ImageList(this.components);
            this.pnl_BildirimAyarlari = new System.Windows.Forms.Panel();
            this.pnl_Kaydet = new System.Windows.Forms.Panel();
            this.button2 = new System.Windows.Forms.Button();
            this.pnl_BotAdi.SuspendLayout();
            this.pnl_Kullanici.SuspendLayout();
            this.pnl_BotKey.SuspendLayout();
            this.pnl_ChatId.SuspendLayout();
            this.pnlAktiflik.SuspendLayout();
            this.panel5.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pbx_Siparis)).BeginInit();
            this.panel6.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pbx_Alinacaklar)).BeginInit();
            this.panel7.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pbx_Rezervasyon)).BeginInit();
            this.panel8.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pbx_Calisan)).BeginInit();
            this.panel9.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pbx_Yonetim)).BeginInit();
            this.panel10.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pbx_GunlukRapor)).BeginInit();
            this.pnl_BildirimAyarlari.SuspendLayout();
            this.pnl_Kaydet.SuspendLayout();
            this.SuspendLayout();
            // 
            // pnl_BotAdi
            // 
            this.pnl_BotAdi.Controls.Add(this.txb_BotAdi);
            this.pnl_BotAdi.Controls.Add(this.label5);
            this.pnl_BotAdi.Dock = System.Windows.Forms.DockStyle.Top;
            this.pnl_BotAdi.Location = new System.Drawing.Point(0, 0);
            this.pnl_BotAdi.Name = "pnl_BotAdi";
            this.pnl_BotAdi.Size = new System.Drawing.Size(732, 33);
            this.pnl_BotAdi.TabIndex = 8;
            this.pnl_BotAdi.Click += new System.EventHandler(this.pnl_KullaniciAdi_Click);
            this.pnl_BotAdi.Paint += new System.Windows.Forms.PaintEventHandler(this.pnl_BotAdi_Paint);
            // 
            // txb_BotAdi
            // 
            this.txb_BotAdi.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.txb_BotAdi.Font = new System.Drawing.Font("Century Gothic", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.txb_BotAdi.Location = new System.Drawing.Point(153, 6);
            this.txb_BotAdi.Name = "txb_BotAdi";
            this.txb_BotAdi.Size = new System.Drawing.Size(546, 22);
            this.txb_BotAdi.TabIndex = 2;
            this.txb_BotAdi.Click += new System.EventHandler(this.pnl_KullaniciAdi_Click);
            this.txb_BotAdi.TextChanged += new System.EventHandler(this.txb_BotAdi_TextChanged);
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Century Gothic", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label5.ForeColor = System.Drawing.Color.White;
            this.label5.Location = new System.Drawing.Point(21, 9);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(51, 17);
            this.label5.TabIndex = 1;
            this.label5.Text = "Bot Adı";
            this.label5.Click += new System.EventHandler(this.pnl_KullaniciAdi_Click);
            // 
            // pnl_Kullanici
            // 
            this.pnl_Kullanici.Controls.Add(this.cbx_Kullanici);
            this.pnl_Kullanici.Controls.Add(this.label1);
            this.pnl_Kullanici.Dock = System.Windows.Forms.DockStyle.Top;
            this.pnl_Kullanici.Location = new System.Drawing.Point(0, 33);
            this.pnl_Kullanici.Name = "pnl_Kullanici";
            this.pnl_Kullanici.Size = new System.Drawing.Size(732, 33);
            this.pnl_Kullanici.TabIndex = 9;
            // 
            // cbx_Kullanici
            // 
            this.cbx_Kullanici.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.cbx_Kullanici.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cbx_Kullanici.Font = new System.Drawing.Font("Century Gothic", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.cbx_Kullanici.FormattingEnabled = true;
            this.cbx_Kullanici.Location = new System.Drawing.Point(153, 5);
            this.cbx_Kullanici.Name = "cbx_Kullanici";
            this.cbx_Kullanici.Size = new System.Drawing.Size(546, 25);
            this.cbx_Kullanici.TabIndex = 4;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Century Gothic", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label1.ForeColor = System.Drawing.Color.White;
            this.label1.Location = new System.Drawing.Point(21, 9);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(57, 17);
            this.label1.TabIndex = 1;
            this.label1.Text = "Kullanıcı";
            // 
            // pnl_BotKey
            // 
            this.pnl_BotKey.Controls.Add(this.txb_BotKey);
            this.pnl_BotKey.Controls.Add(this.label2);
            this.pnl_BotKey.Dock = System.Windows.Forms.DockStyle.Top;
            this.pnl_BotKey.Location = new System.Drawing.Point(0, 66);
            this.pnl_BotKey.Name = "pnl_BotKey";
            this.pnl_BotKey.Size = new System.Drawing.Size(732, 33);
            this.pnl_BotKey.TabIndex = 10;
            // 
            // txb_BotKey
            // 
            this.txb_BotKey.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.txb_BotKey.Font = new System.Drawing.Font("Century Gothic", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.txb_BotKey.Location = new System.Drawing.Point(153, 6);
            this.txb_BotKey.Name = "txb_BotKey";
            this.txb_BotKey.Size = new System.Drawing.Size(546, 22);
            this.txb_BotKey.TabIndex = 2;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Century Gothic", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label2.ForeColor = System.Drawing.Color.White;
            this.label2.Location = new System.Drawing.Point(21, 9);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(52, 17);
            this.label2.TabIndex = 1;
            this.label2.Text = "Bot Key";
            // 
            // pnl_ChatId
            // 
            this.pnl_ChatId.Controls.Add(this.txb_ChatId);
            this.pnl_ChatId.Controls.Add(this.label3);
            this.pnl_ChatId.Dock = System.Windows.Forms.DockStyle.Top;
            this.pnl_ChatId.Location = new System.Drawing.Point(0, 99);
            this.pnl_ChatId.Name = "pnl_ChatId";
            this.pnl_ChatId.Size = new System.Drawing.Size(732, 33);
            this.pnl_ChatId.TabIndex = 11;
            // 
            // txb_ChatId
            // 
            this.txb_ChatId.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.txb_ChatId.Font = new System.Drawing.Font("Century Gothic", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.txb_ChatId.Location = new System.Drawing.Point(153, 6);
            this.txb_ChatId.Name = "txb_ChatId";
            this.txb_ChatId.Size = new System.Drawing.Size(546, 22);
            this.txb_ChatId.TabIndex = 2;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Century Gothic", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label3.ForeColor = System.Drawing.Color.White;
            this.label3.Location = new System.Drawing.Point(21, 9);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(52, 17);
            this.label3.TabIndex = 1;
            this.label3.Text = "Chat ID";
            // 
            // pnlAktiflik
            // 
            this.pnlAktiflik.Controls.Add(this.cbx_Aktiflik);
            this.pnlAktiflik.Controls.Add(this.label4);
            this.pnlAktiflik.Dock = System.Windows.Forms.DockStyle.Top;
            this.pnlAktiflik.Location = new System.Drawing.Point(0, 132);
            this.pnlAktiflik.Name = "pnlAktiflik";
            this.pnlAktiflik.Size = new System.Drawing.Size(732, 33);
            this.pnlAktiflik.TabIndex = 12;
            // 
            // cbx_Aktiflik
            // 
            this.cbx_Aktiflik.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.cbx_Aktiflik.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cbx_Aktiflik.Font = new System.Drawing.Font("Century Gothic", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.cbx_Aktiflik.FormattingEnabled = true;
            this.cbx_Aktiflik.Items.AddRange(new object[] {
            "Aktif",
            "Pasif"});
            this.cbx_Aktiflik.Location = new System.Drawing.Point(153, 5);
            this.cbx_Aktiflik.Name = "cbx_Aktiflik";
            this.cbx_Aktiflik.Size = new System.Drawing.Size(546, 25);
            this.cbx_Aktiflik.TabIndex = 4;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Century Gothic", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label4.ForeColor = System.Drawing.Color.White;
            this.label4.Location = new System.Drawing.Point(21, 9);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(47, 17);
            this.label4.TabIndex = 1;
            this.label4.Text = "Aktiflik";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Century Gothic", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label6.ForeColor = System.Drawing.Color.White;
            this.label6.Location = new System.Drawing.Point(21, 13);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(114, 16);
            this.label6.TabIndex = 13;
            this.label6.Text = "Bildirim Ayarları";
            // 
            // panel5
            // 
            this.panel5.BackColor = System.Drawing.Color.White;
            this.panel5.Controls.Add(this.label7);
            this.panel5.Controls.Add(this.pbx_Siparis);
            this.panel5.Location = new System.Drawing.Point(24, 32);
            this.panel5.Name = "panel5";
            this.panel5.Size = new System.Drawing.Size(220, 32);
            this.panel5.TabIndex = 14;
            // 
            // label7
            // 
            this.label7.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.label7.Font = new System.Drawing.Font("Century Gothic", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label7.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(29)))), ((int)(((byte)(29)))), ((int)(((byte)(29)))));
            this.label7.Location = new System.Drawing.Point(33, 3);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(184, 24);
            this.label7.TabIndex = 16;
            this.label7.Text = "Sipariş Bildirimleri";
            this.label7.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // pbx_Siparis
            // 
            this.pbx_Siparis.Image = ((System.Drawing.Image)(resources.GetObject("pbx_Siparis.Image")));
            this.pbx_Siparis.Location = new System.Drawing.Point(3, 3);
            this.pbx_Siparis.Name = "pbx_Siparis";
            this.pbx_Siparis.Size = new System.Drawing.Size(26, 26);
            this.pbx_Siparis.SizeMode = System.Windows.Forms.PictureBoxSizeMode.CenterImage;
            this.pbx_Siparis.TabIndex = 15;
            this.pbx_Siparis.TabStop = false;
            this.pbx_Siparis.Click += new System.EventHandler(this.pbx_Siparis_Click);
            // 
            // panel6
            // 
            this.panel6.BackColor = System.Drawing.Color.White;
            this.panel6.Controls.Add(this.label8);
            this.panel6.Controls.Add(this.pbx_Alinacaklar);
            this.panel6.Location = new System.Drawing.Point(251, 32);
            this.panel6.Name = "panel6";
            this.panel6.Size = new System.Drawing.Size(220, 32);
            this.panel6.TabIndex = 15;
            // 
            // label8
            // 
            this.label8.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.label8.Font = new System.Drawing.Font("Century Gothic", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label8.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(29)))), ((int)(((byte)(29)))), ((int)(((byte)(29)))));
            this.label8.Location = new System.Drawing.Point(33, 3);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(184, 24);
            this.label8.TabIndex = 16;
            this.label8.Text = "Alınacaklar Listesi  Bildirimleri";
            this.label8.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // pbx_Alinacaklar
            // 
            this.pbx_Alinacaklar.Image = ((System.Drawing.Image)(resources.GetObject("pbx_Alinacaklar.Image")));
            this.pbx_Alinacaklar.Location = new System.Drawing.Point(3, 3);
            this.pbx_Alinacaklar.Name = "pbx_Alinacaklar";
            this.pbx_Alinacaklar.Size = new System.Drawing.Size(26, 26);
            this.pbx_Alinacaklar.SizeMode = System.Windows.Forms.PictureBoxSizeMode.CenterImage;
            this.pbx_Alinacaklar.TabIndex = 15;
            this.pbx_Alinacaklar.TabStop = false;
            this.pbx_Alinacaklar.Click += new System.EventHandler(this.pbx_Alinacaklar_Click);
            // 
            // panel7
            // 
            this.panel7.BackColor = System.Drawing.Color.White;
            this.panel7.Controls.Add(this.label9);
            this.panel7.Controls.Add(this.pbx_Rezervasyon);
            this.panel7.Location = new System.Drawing.Point(478, 32);
            this.panel7.Name = "panel7";
            this.panel7.Size = new System.Drawing.Size(220, 32);
            this.panel7.TabIndex = 17;
            // 
            // label9
            // 
            this.label9.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.label9.Font = new System.Drawing.Font("Century Gothic", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label9.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(29)))), ((int)(((byte)(29)))), ((int)(((byte)(29)))));
            this.label9.Location = new System.Drawing.Point(33, 3);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(184, 24);
            this.label9.TabIndex = 16;
            this.label9.Text = "Rezervasyon Bildirimleri";
            this.label9.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // pbx_Rezervasyon
            // 
            this.pbx_Rezervasyon.Image = ((System.Drawing.Image)(resources.GetObject("pbx_Rezervasyon.Image")));
            this.pbx_Rezervasyon.Location = new System.Drawing.Point(3, 3);
            this.pbx_Rezervasyon.Name = "pbx_Rezervasyon";
            this.pbx_Rezervasyon.Size = new System.Drawing.Size(26, 26);
            this.pbx_Rezervasyon.SizeMode = System.Windows.Forms.PictureBoxSizeMode.CenterImage;
            this.pbx_Rezervasyon.TabIndex = 15;
            this.pbx_Rezervasyon.TabStop = false;
            this.pbx_Rezervasyon.Click += new System.EventHandler(this.pbx_Rezervasyon_Click);
            // 
            // panel8
            // 
            this.panel8.BackColor = System.Drawing.Color.White;
            this.panel8.Controls.Add(this.label10);
            this.panel8.Controls.Add(this.pbx_Calisan);
            this.panel8.Location = new System.Drawing.Point(478, 70);
            this.panel8.Name = "panel8";
            this.panel8.Size = new System.Drawing.Size(220, 32);
            this.panel8.TabIndex = 20;
            // 
            // label10
            // 
            this.label10.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.label10.Font = new System.Drawing.Font("Century Gothic", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label10.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(29)))), ((int)(((byte)(29)))), ((int)(((byte)(29)))));
            this.label10.Location = new System.Drawing.Point(33, 3);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(184, 24);
            this.label10.TabIndex = 16;
            this.label10.Text = "Çalışan Maaş Bildirimleri";
            this.label10.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // pbx_Calisan
            // 
            this.pbx_Calisan.Image = ((System.Drawing.Image)(resources.GetObject("pbx_Calisan.Image")));
            this.pbx_Calisan.Location = new System.Drawing.Point(3, 3);
            this.pbx_Calisan.Name = "pbx_Calisan";
            this.pbx_Calisan.Size = new System.Drawing.Size(26, 26);
            this.pbx_Calisan.SizeMode = System.Windows.Forms.PictureBoxSizeMode.CenterImage;
            this.pbx_Calisan.TabIndex = 15;
            this.pbx_Calisan.TabStop = false;
            this.pbx_Calisan.Click += new System.EventHandler(this.pbx_Calisan_Click);
            // 
            // panel9
            // 
            this.panel9.BackColor = System.Drawing.Color.White;
            this.panel9.Controls.Add(this.label11);
            this.panel9.Controls.Add(this.pbx_Yonetim);
            this.panel9.Location = new System.Drawing.Point(251, 70);
            this.panel9.Name = "panel9";
            this.panel9.Size = new System.Drawing.Size(220, 32);
            this.panel9.TabIndex = 19;
            // 
            // label11
            // 
            this.label11.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.label11.Font = new System.Drawing.Font("Century Gothic", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label11.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(29)))), ((int)(((byte)(29)))), ((int)(((byte)(29)))));
            this.label11.Location = new System.Drawing.Point(33, 3);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(184, 24);
            this.label11.TabIndex = 16;
            this.label11.Text = "Yönetim Ayar Bildirimleri";
            this.label11.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // pbx_Yonetim
            // 
            this.pbx_Yonetim.Image = ((System.Drawing.Image)(resources.GetObject("pbx_Yonetim.Image")));
            this.pbx_Yonetim.Location = new System.Drawing.Point(3, 3);
            this.pbx_Yonetim.Name = "pbx_Yonetim";
            this.pbx_Yonetim.Size = new System.Drawing.Size(26, 26);
            this.pbx_Yonetim.SizeMode = System.Windows.Forms.PictureBoxSizeMode.CenterImage;
            this.pbx_Yonetim.TabIndex = 15;
            this.pbx_Yonetim.TabStop = false;
            this.pbx_Yonetim.Click += new System.EventHandler(this.pbx_Yonetim_Click);
            // 
            // panel10
            // 
            this.panel10.BackColor = System.Drawing.Color.White;
            this.panel10.Controls.Add(this.label12);
            this.panel10.Controls.Add(this.pbx_GunlukRapor);
            this.panel10.Location = new System.Drawing.Point(24, 70);
            this.panel10.Name = "panel10";
            this.panel10.Size = new System.Drawing.Size(220, 32);
            this.panel10.TabIndex = 18;
            // 
            // label12
            // 
            this.label12.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.label12.Font = new System.Drawing.Font("Century Gothic", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label12.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(29)))), ((int)(((byte)(29)))), ((int)(((byte)(29)))));
            this.label12.Location = new System.Drawing.Point(33, 3);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(184, 24);
            this.label12.TabIndex = 16;
            this.label12.Text = "Günlük Rapor  Bildirimleri";
            this.label12.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // pbx_GunlukRapor
            // 
            this.pbx_GunlukRapor.Image = ((System.Drawing.Image)(resources.GetObject("pbx_GunlukRapor.Image")));
            this.pbx_GunlukRapor.Location = new System.Drawing.Point(3, 3);
            this.pbx_GunlukRapor.Name = "pbx_GunlukRapor";
            this.pbx_GunlukRapor.Size = new System.Drawing.Size(26, 26);
            this.pbx_GunlukRapor.SizeMode = System.Windows.Forms.PictureBoxSizeMode.CenterImage;
            this.pbx_GunlukRapor.TabIndex = 15;
            this.pbx_GunlukRapor.TabStop = false;
            this.pbx_GunlukRapor.Click += new System.EventHandler(this.pbx_GunlukRapor_Click);
            // 
            // imageList1
            // 
            this.imageList1.ImageStream = ((System.Windows.Forms.ImageListStreamer)(resources.GetObject("imageList1.ImageStream")));
            this.imageList1.TransparentColor = System.Drawing.Color.Transparent;
            this.imageList1.Images.SetKeyName(0, "active.png");
            this.imageList1.Images.SetKeyName(1, "deactive.png");
            // 
            // pnl_BildirimAyarlari
            // 
            this.pnl_BildirimAyarlari.Controls.Add(this.label6);
            this.pnl_BildirimAyarlari.Controls.Add(this.panel8);
            this.pnl_BildirimAyarlari.Controls.Add(this.panel5);
            this.pnl_BildirimAyarlari.Controls.Add(this.panel7);
            this.pnl_BildirimAyarlari.Controls.Add(this.panel6);
            this.pnl_BildirimAyarlari.Controls.Add(this.panel9);
            this.pnl_BildirimAyarlari.Controls.Add(this.panel10);
            this.pnl_BildirimAyarlari.Dock = System.Windows.Forms.DockStyle.Top;
            this.pnl_BildirimAyarlari.Location = new System.Drawing.Point(0, 165);
            this.pnl_BildirimAyarlari.Name = "pnl_BildirimAyarlari";
            this.pnl_BildirimAyarlari.Size = new System.Drawing.Size(732, 112);
            this.pnl_BildirimAyarlari.TabIndex = 21;
            // 
            // pnl_Kaydet
            // 
            this.pnl_Kaydet.Controls.Add(this.button2);
            this.pnl_Kaydet.Dock = System.Windows.Forms.DockStyle.Top;
            this.pnl_Kaydet.Location = new System.Drawing.Point(0, 277);
            this.pnl_Kaydet.Name = "pnl_Kaydet";
            this.pnl_Kaydet.Size = new System.Drawing.Size(732, 36);
            this.pnl_Kaydet.TabIndex = 22;
            // 
            // button2
            // 
            this.button2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(2)))), ((int)(((byte)(117)))), ((int)(((byte)(252)))));
            this.button2.FlatAppearance.BorderSize = 0;
            this.button2.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button2.Font = new System.Drawing.Font("Century Gothic", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.button2.ForeColor = System.Drawing.Color.White;
            this.button2.Location = new System.Drawing.Point(24, 4);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(675, 29);
            this.button2.TabIndex = 6;
            this.button2.Text = "Kaydet";
            this.button2.UseVisualStyleBackColor = false;
            this.button2.Click += new System.EventHandler(this.button2_Click);
            // 
            // YonetimTelegramBot
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(29)))), ((int)(((byte)(29)))), ((int)(((byte)(29)))));
            this.Controls.Add(this.pnl_Kaydet);
            this.Controls.Add(this.pnl_BildirimAyarlari);
            this.Controls.Add(this.pnlAktiflik);
            this.Controls.Add(this.pnl_ChatId);
            this.Controls.Add(this.pnl_BotKey);
            this.Controls.Add(this.pnl_Kullanici);
            this.Controls.Add(this.pnl_BotAdi);
            this.Name = "YonetimTelegramBot";
            this.Size = new System.Drawing.Size(732, 315);
            this.Load += new System.EventHandler(this.YonetimTelegramBot_Load);
            this.pnl_BotAdi.ResumeLayout(false);
            this.pnl_BotAdi.PerformLayout();
            this.pnl_Kullanici.ResumeLayout(false);
            this.pnl_Kullanici.PerformLayout();
            this.pnl_BotKey.ResumeLayout(false);
            this.pnl_BotKey.PerformLayout();
            this.pnl_ChatId.ResumeLayout(false);
            this.pnl_ChatId.PerformLayout();
            this.pnlAktiflik.ResumeLayout(false);
            this.pnlAktiflik.PerformLayout();
            this.panel5.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.pbx_Siparis)).EndInit();
            this.panel6.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.pbx_Alinacaklar)).EndInit();
            this.panel7.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.pbx_Rezervasyon)).EndInit();
            this.panel8.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.pbx_Calisan)).EndInit();
            this.panel9.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.pbx_Yonetim)).EndInit();
            this.panel10.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.pbx_GunlukRapor)).EndInit();
            this.pnl_BildirimAyarlari.ResumeLayout(false);
            this.pnl_BildirimAyarlari.PerformLayout();
            this.pnl_Kaydet.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel pnl_BotAdi;
        private System.Windows.Forms.TextBox txb_BotAdi;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Panel pnl_Kullanici;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Panel pnl_BotKey;
        private System.Windows.Forms.TextBox txb_BotKey;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.ComboBox cbx_Kullanici;
        private System.Windows.Forms.Panel pnl_ChatId;
        private System.Windows.Forms.TextBox txb_ChatId;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Panel pnlAktiflik;
        private System.Windows.Forms.ComboBox cbx_Aktiflik;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Panel panel5;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.PictureBox pbx_Siparis;
        private System.Windows.Forms.Panel panel6;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.PictureBox pbx_Alinacaklar;
        private System.Windows.Forms.Panel panel7;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.PictureBox pbx_Rezervasyon;
        private System.Windows.Forms.Panel panel8;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.PictureBox pbx_Calisan;
        private System.Windows.Forms.Panel panel9;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.PictureBox pbx_Yonetim;
        private System.Windows.Forms.Panel panel10;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.PictureBox pbx_GunlukRapor;
        public System.Windows.Forms.ImageList imageList1;
        private System.Windows.Forms.Panel pnl_BildirimAyarlari;
        private System.Windows.Forms.Panel pnl_Kaydet;
        private System.Windows.Forms.Button button2;
    }
}
