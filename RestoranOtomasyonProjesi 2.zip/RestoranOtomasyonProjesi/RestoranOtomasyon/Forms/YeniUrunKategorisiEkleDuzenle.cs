﻿using Mail.Forms;
using RestoranOtomasyon.Functions;
using RestoranOtomasyon.Objects;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Runtime.InteropServices;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace RestoranOtomasyon.Forms
{
	public partial class YeniUrunKategorisiEkleDuzenle : Form
	{
		// global variables
		int kategoriId;
		string kategoriAdi;
		bool aktiflik;
		YonetimUrunYonetimi yonetim;

		// constructor and load event
		public YeniUrunKategorisiEkleDuzenle([Optional, DefaultParameterValue(0)] int kategoriId, [Optional, DefaultParameterValue("")] string kategoriAdi, [Optional, DefaultParameterValue(false)] bool aktiflik, YonetimUrunYonetimi urunYonetimi)
		{
			InitializeComponent();
			this.kategoriId = kategoriId;
			this.kategoriAdi = kategoriAdi;
			this.aktiflik = aktiflik;
			this.yonetim = urunYonetimi;
		}
		// funcs
		public void Message(string message)
		{
			MyMessageBox myMessageBox = new MyMessageBox(message);
			myMessageBox.ShowDialog();
		}

		// events
		private void YeniUrunKategorisiEkleDuzenle_Load(object sender, EventArgs e)
		{
			if (kategoriId > 0)
			{
				lbl_Header.Text = "Ürün Kategorisi Düzenleme";
				txb_UrunAdi.Text = kategoriAdi;
				cbx_Kategori.SelectedItem = aktiflik ? "Aktif" : "Pasif";
				btn_Guncelle.Text = "Ürün Kategorisini Güncelle";
				btn_Sil.Text = "Ürünü Sil";
				

			}
			else
			{
				lbl_Header.Text = "Ürün Kategorisi Ekleme";
				cbx_Kategori.SelectedItem = "Aktif";
				btn_Guncelle.Width = (btn_Sil.Location.X + btn_Sil.Width) - btn_Guncelle.Location.X;
				btn_Sil.Visible = false;

			}
		}

		private void btn_Guncelle_Click(object sender, EventArgs e)
		{
			string message = "";
			bool flag = false;
			if (string.IsNullOrEmpty(txb_UrunAdi.Text))
			{
				message += "Lütfen ürün kategorisi adı giriniz.";
				flag = true;
			}
			if (string.IsNullOrEmpty(cbx_Kategori.Text))
			{
				message += "Lütfen aktiflik bilgisini seçiniz.";
				flag = true;
			}
			if (flag)
			{
				Message(message);
			}
			else
			{
				if (kategoriId > 0)
				{
					Database db = new Database();
					UrunKategoriObject urunKategoriObject = new UrunKategoriObject();
					urunKategoriObject.Id = kategoriId;
					urunKategoriObject.KategoriAdi = txb_UrunAdi.Text;
					urunKategoriObject.Aktiflik = cbx_Kategori.Text == "Aktif" ? true : false;
					string result = db.updateUrunKategori(urunKategoriObject);
					Message(result);
					if (result.ToLower().Contains("başarılı"))
					{
						yonetim.loadUrunKategorileri();
						this.Close();
					}
				}
				else
				{
					Database db = new Database();
					UrunKategoriObject urunKategoriObject = new UrunKategoriObject();
					urunKategoriObject.KategoriAdi = txb_UrunAdi.Text;
					urunKategoriObject.Aktiflik = cbx_Kategori.Text == "Aktif" ? true : false;
					string result = db.insertUrunKategori(urunKategoriObject);
					Message(result);
					if (result.ToLower().Contains("başarılı"))
					{
						this.Close();
					}

				}
			}
			
		}

		private void btn_Sil_Click(object sender, EventArgs e)
		{
			Database db = new Database();
			string result = db.deleteUrunKategori(this.kategoriId);
			Message(result);
			if (result.ToLower().Contains("başarılı"))
			{
				this.Close();
			}
		}

		private void btn_Exit_Click(object sender, EventArgs e)
		{
			this.Close();
		}
	}
}
