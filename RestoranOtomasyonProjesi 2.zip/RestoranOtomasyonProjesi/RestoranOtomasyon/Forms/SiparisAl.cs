﻿using Mail.Forms;
using RestoranOtomasyon.Components;
using RestoranOtomasyon.Functions;
using RestoranOtomasyon.Objects;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Security.Policy;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace RestoranOtomasyon.Forms
{
    public partial class SiparisAl : Form
    {
        int masaId;
        List<UrunKategoriObject> kategoriList = new List<UrunKategoriObject>();
        List<UrunObject> urunList = new List<UrunObject>();
        public SiparisAl(int masaId)
        {
            InitializeComponent();
            this.masaId = masaId;
        }

        private void SiparisAl_Load(object sender, EventArgs e)
        {
            Database kategoriModulDb = new Database();
            ModulObject kategoriModulu = kategoriModulDb.getModulFromName("Ürün Kategori");
            if (string.IsNullOrEmpty(kategoriModulu.ModulKey) || kategoriModulu.Aktiflik == false)
            {
				urunleriListele(0);
                pnl_Kategori.Visible = false;
			}
            else
            {
				urunleriListele(1);
				kategoriListele();
				getMasa();
			}
			
        }

        // FUNCS
        public void Message(string message)
        {
            MyMessageBox myMessageBox = new MyMessageBox(message);
            myMessageBox.ShowDialog();
        }
        public void kategoriListele()
        {
            Database database= new Database();
            kategoriList = database.listUrunKategori();
            int x = 10;
            int urunKategoriCounter = 0;
            foreach (var kategori in kategoriList)
            {
                UrunKategori ktg = new UrunKategori(kategori.Id,kategori.KategoriAdi,this);
				ktg.Click += (sender, args) =>
				{
					urunleriListele(kategori.Id);
				};
				ktg.Location = new Point(x, 3);
                urunKategoriCounter++;
                x += ktg.Width + 10;
                pnl_Kategori.Controls.Add(ktg);
			}
			if (kategoriList.Count > 4)
			{
				pnl_Kategori.Height += 20;
			}
		}
        public void urunleriListele(int id = 0)
        {
            pnl_Urun.Controls.Clear();
            Database database = new Database();
            urunList.Clear();
            if (id > 0)
            {
				urunList = database.listUrunWithCategory(id);
			}
            else
            {
                urunList = database.listUrun();
            }
			int x = 10;
            int y = 10;
            int urunCounter = 0;
            foreach (UrunObject urunobj in urunList)
            {
                Urun urun = new Urun(id:urunobj.Id,kategoriId:urunobj.KategoriId,urunAdi:urunobj.UrunAdi,urunFiyati:urunobj.SatisFiyati.ToString(),this);
				if (urunCounter % 5 == 0 && urunCounter != 0)
                {
                    y += urun.Height + 10;
                    x = 10;
                }
                urun.Location = new Point(x, y);
                x += urun.Width + 10;
                urunCounter += 1;
                urun.BorderStyle = BorderStyle.FixedSingle;
                pnl_Urun.Controls.Add(urun);
            }
        }
        public void sepeteEkle(int id, string urunAdi)
        {
			UrunObject urun = urunList.Find(x => x.UrunAdi == urunAdi);

			if (dataGridView1.Rows.Count > 0)
            {
                bool flag = false;
                foreach (DataGridViewRow row in dataGridView1.Rows)
                {
                    if (row.Cells["ad"].Value.ToString() == urun.UrunAdi)
                    {
                        flag = true;
						try
						{
							int adet = Convert.ToInt32(row.Cells["adet"].Value) + 1;
							int fiyat = Convert.ToInt32(row.Cells["adetFiyat"].Value);
							int toplamFiyat = Convert.ToInt32(row.Cells["toplamFiyat"].Value);
							row.Cells["adet"].Value = adet;
							row.Cells["toplamFiyat"].Value = fiyat * adet;
						}
						catch { }
						break;
					}
                    else
                    {
                        continue;
					}
                }
                if (!flag)
                {
					dataGridView1.Rows.Add(urun.UrunAdi, 1, urun.SatisFiyati, urun.SatisFiyati);

				}
			}
            else
            {
                dataGridView1.Rows.Add(urun.UrunAdi, 1, urun.SatisFiyati, urun.SatisFiyati);
            }
            int genelToplam = 0;
            foreach (DataGridViewRow row in dataGridView1.Rows) {
                genelToplam += Convert.ToInt32(row.Cells["toplamFiyat"].Value);
			}
            lbl_ToplamTutar.Text = genelToplam.ToString() + "₺";

		}

		public void getMasa()
        {
            Database database = new Database();
            MasaObject masa = database.getMasa(this.masaId);
            Database database2 = new Database();
            MasaKategoriObject masaKategori = database2.getMasaKategori(masa.KategoriId);
            lbl_MasaAdi.Text = masaKategori.KategoriAdi + " " + masa.MasaNo;
        }

        private void btn_Exit_Click(object sender, EventArgs e)
        {
            this.Close();
        }

		private void btn_Arttir_Click(object sender, EventArgs e)
		{
			foreach (DataGridViewCell cell in dataGridView1.SelectedCells)
			{
				int selectedrowindex = cell.RowIndex;
				DataGridViewRow row = dataGridView1.Rows[selectedrowindex];
				string adetStr = row.Cells[1].Value.ToString();
				string fiyatStr = row.Cells[2].Value.ToString();
				try
                {
                    int adet = Convert.ToInt32(adetStr) + 1;
                    int fiyat = Convert.ToInt32(fiyatStr);
                    row.Cells[1].Value = adet.ToString();
                    row.Cells[3].Value = adet*fiyat;
				}
				catch {}
                
			}
			int genelToplam = 0;
			foreach (DataGridViewRow row in dataGridView1.Rows)
			{
				genelToplam += Convert.ToInt32(row.Cells["toplamFiyat"].Value);
			}
			lbl_ToplamTutar.Text = genelToplam.ToString() + "₺";
		}

		private void btn_Azalt_Click(object sender, EventArgs e)
		{
			foreach (DataGridViewCell cell in dataGridView1.SelectedCells)
			{
				int selectedrowindex = cell.RowIndex;
				DataGridViewRow row = dataGridView1.Rows[selectedrowindex];

				string adetStr = row.Cells[1].Value.ToString();
				string fiyatStr = row.Cells[2].Value.ToString();
				try
				{
					int adet = Convert.ToInt32(adetStr) - 1 ;
					int fiyat = Convert.ToInt32(fiyatStr);
                    if (adet <= 0)
                    {
						dataGridView1.Rows.RemoveAt(row.Index);
					}
                    else
                    {
						row.Cells[1].Value = adet.ToString();
						row.Cells[3].Value = adet * fiyat;
					}
					
				}
				catch { }
			}
			int genelToplam = 0;
			foreach (DataGridViewRow row in dataGridView1.Rows)
			{
				genelToplam += Convert.ToInt32(row.Cells["toplamFiyat"].Value);
			}
			lbl_ToplamTutar.Text = genelToplam.ToString() + "₺";
		}

		private void btn_SiparisiKaydet_Click(object sender, EventArgs e)
		{
            Database adisyonDb = new Database();
            AdisyonObject adisyonObject = adisyonDb.getAdisyonFromMasaIdWhereIsActive(masaId);
            if ( !(adisyonObject.Id > 0))
            {
                Database insertAdisyonDb = new Database();
                AdisyonObject adisyon = new AdisyonObject();

                adisyon.OlusturmaTarihi = DateTime.Now;
                adisyon.OdenmeDurumu = false;
                adisyon.RezervasyonId = 0;
                adisyon.MasaId = this.masaId;
                insertAdisyonDb.insertAdisyon(adisyon);
            }
            Database adisyonDb2 = new Database();
			adisyonObject = adisyonDb2.getAdisyonFromMasaIdWhereIsActive(masaId);
            string result = "";
			foreach (DataGridViewRow row in dataGridView1.Rows)
			{
				UrunObject urun = urunList.Find(x => x.UrunAdi == row.Cells[0].Value.ToString());
                if (urun != null)
                {
                    Database insertSiparisDb = new Database();
                    SiparisObject siparis = new SiparisObject();
                    int adetFiyati = 0;
                    siparis.AdisyonId = adisyonObject.Id;
                    siparis.UrunId = urun.Id;
                    try{siparis.SiparisAdedi = Convert.ToInt32(row.Cells[1].Value);} catch{siparis.SiparisAdedi = 1;}
                    try{adetFiyati = Convert.ToInt32(row.Cells[2].Value);} catch{adetFiyati = 0;}

                    siparis.SiparisTutari = siparis.SiparisAdedi * adetFiyati;
                    siparis.SiparisTarihi = DateTime.Now;
                    siparis.SiparisTeslimDurumu = false;
                    siparis.SiparisOdenmeDurumu = false;
                    result = insertSiparisDb.insertSiparis(siparis);
				}
			}
            Message(result);
            this.Close();
		}
	}
}
