﻿using Mail.Forms;
using Newtonsoft.Json.Linq;
using RestoranOtomasyon.Forms;
using System;
using System.Collections.Specialized;
using System.Diagnostics;
using System.Drawing;
using System.Net;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace RestoranOtomasyon
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }
        // GLOBAL VARIABLES


        // FUNCS
        public async Task<bool> isValidMailAsync(string text)
        {
            Funcs funcs = new Funcs();
            return await funcs.isValidMail(text);
        }
        public async Task<string> girisYap()
        {
            Funcs funcs = new Funcs();
            string email = txb_Email.Text;
            string sifre = txb_Sifre.Text;
            bool isValidEmail = await funcs.isValidMail(email);
            string password = await funcs.isValidPassword(sifre);
            string result = "";
            bool flag = false;
            if (!isValidEmail)
            {
                result += "Lütfen geçerli bir mail adresi giriniz.";
                flag = true;
                
            }
			if (!(string.IsNullOrEmpty(password)))
			{
                result += password;
                flag = true;
			}

            if (flag)
            {
				MyMessageBox messageBox = new MyMessageBox(result);
				messageBox.ShowDialog();
			}
            else
            {
                using (var client = new WebClient())
                {
                    var values = new NameValueCollection();
                    string link = "https://x.x/x/login.php?";
                    string bilgiler = "Mail=" + email + "&Sifre=" + sifre;
                    try
                    {
                        var response = client.UploadValues(link + bilgiler, values);
                        var responseString = Encoding.Default.GetString(response);
                        var res = JObject.Parse(responseString);
                        if (responseString.IndexOf("E-Mail veya sifre yanlis.") != -1)
                        {
                            result = "E-Mail veya şifre yanlış.";
                            MyMessageBox messageBox = new MyMessageBox(result);
                            messageBox.ShowDialog();
                        }
                        else if (responseString.IndexOf("Lisans süresi dolmuş. Lütfen lisansınızı yenileyin.") != -1)
                        {
                            result = "Lisans sona ermiş.";
                            MyMessageBox messageBox = new MyMessageBox(result);
                            messageBox.ShowDialog();
                        }
                        else if (responseString.IndexOf("E-Mail veya şifre yanlış") != -1)
                        {
                            result = "E-Mail veya şifre yanlış";
                            MyMessageBox messageBox = new MyMessageBox(result);
                            messageBox.ShowDialog();
                        }
                        else if (responseString.IndexOf("Giris basarili.") != -1)
                        {
                            string yetki = res["yetki"].ToString();
                            result = "Giriş başarılı, yönlendiriliyorsunuz.";
                            lbl_Info.Text = result;
                            Thread.Sleep(1000);
                            if (yetki == "99")
                            { // YÖNETİCİ
                                GarsonEkrani form = new GarsonEkrani(this, yetki);
                                form.Show();
                                this.Hide();
                            }
                            else if (yetki == "98")
                            { // MUTFAK
                                MutfakEkrani form = new MutfakEkrani();
								form.Show();
								this.Hide();

							}
							else if (yetki == "97")
                            { // GARSON
                                GarsonEkrani form = new GarsonEkrani(this, yetki);
                                form.Show();
                                this.Hide();
                            }
                            Properties.Settings.Default.mail = email;
                            Properties.Settings.Default.password = sifre;
                            Properties.Settings.Default.Save();
                        }
                        else
                        {
                            result = "Beklenmedik bir hata oluştu.";
                            MyMessageBox messageBox = new MyMessageBox(result);
                            messageBox.ShowDialog();
                        }
                    }
                    catch
                    {
                        result = "Bağlantı hatası.";
                    }
                }
            }
            return result;
        }

        public async Task<string> kayitOl()
        {
            string lisansKey = txb_LisansKey.Text.ToString();
            string email = txb_Email.Text;
            string sifre = txb_Sifre.Text;
            bool isValidEmail = await isValidMailAsync(email);
            string result = "";
            if (!isValidEmail)
            {
                result = "Lütfen geçerli bir mail adresi giriniz.";
                MyMessageBox messageBox = new MyMessageBox(result);
                messageBox.ShowDialog();
                if (sifre.Length<8)
                {
                }
            }
            else if (sifre.Length < 8)
            {
                result = "Lütfen geçerli bir şifre giriniz.\nGirilen şifre 8 karakter veya daha uzun olmalıdır.";
                MyMessageBox messageBox = new MyMessageBox(result);
                messageBox.ShowDialog();
            }
            else if (lisansKey.Length < 19)
            {
                result = "Lütfen geçerli bir lisans key giriniz.";
                MyMessageBox messageBox = new MyMessageBox(result);
                messageBox.ShowDialog();
            }
            else
            {
                using (var client = new WebClient())
                {
                    var values = new NameValueCollection();
                    string link = "https://x.x/x/register.php?";
                    string bilgiler = "LisanceKey=" + lisansKey + "&Mail=" + email + "&Sifre=" + sifre;
                    var response = client.UploadValues(link + bilgiler, values);
                    var responseString = Encoding.Default.GetString(response);
                    MessageBox.Show(responseString);
                    if (responseString.IndexOf("Lisans Kullanilmis.") != -1)
                    {
                        result = "Lisans kullanılmış.";
                        MyMessageBox messageBox = new MyMessageBox(result);
                        messageBox.ShowDialog();
                    }
                    else if (responseString.IndexOf("Lisans sona ermis.") != -1)
                    {
                        result = "Lisans sona ermiş.";
                        MyMessageBox messageBox = new MyMessageBox(result);
                        messageBox.ShowDialog();
                    }
                    else if (responseString.IndexOf("Lisans bulunamadi") != -1)
                    {
                        result = "Lisans bulunamadı.";
                        MyMessageBox messageBox = new MyMessageBox(result);
                        messageBox.ShowDialog();
                    }
                    else if (responseString.IndexOf("Mail Kayitli") != -1)
                    {
						result = "Bu e-mail zaten kayıtlı. Lütfen farklı bir mail adresi giriniz.";
						MyMessageBox messageBox = new MyMessageBox(result);
						messageBox.ShowDialog();
					}
                    else if (responseString.IndexOf("Kayit basarili.") != -1)
                    {
                        result = "Kayıt işlemi başarılı. Lütfen giriş yapınız.";
                        lbl_Info.Text = result;
                        lbl_Islem.Text = "Giriş Yap";
                        btn_GirisKayit.Text = "Giriş Yap";
                        pnl_LisansKey.Visible = false;
                        lbl_GirisKayit.Text = "Kayıt Ol";
                        pnl_Islemler.Height = pnl_Islemler.Height + pnl_LisansKey.Height;
                        Properties.Settings.Default.mail = email;
                        Properties.Settings.Default.password = sifre;
                        Properties.Settings.Default.Save();




                        Thread.Sleep(1000);
                    }
                }
            }
            return result;

        }




        // EVENTS
        private void btn_Exit_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void panel5_Click(object sender, EventArgs e)
        {
            txb_Email.Focus();
            if (txb_Email.Text == "E-Mail")
            {
                txb_Email.Text = "";
                txb_Email.ForeColor = Color.DimGray;
            }
        }

        private void panel10_Click(object sender, EventArgs e)
        {
            txb_Sifre.Focus();
            if (txb_Sifre.Text == "Şifre")
            {
                txb_Sifre.Text = "";
                txb_Sifre.ForeColor = Color.DimGray;
                txb_Sifre.PasswordChar= '*';
            }
        }

        private void panel11_Click(object sender, EventArgs e)
        {
            txb_LisansKey.Focus();
            if (txb_LisansKey.Text == "Lisans Key")
            {
                txb_LisansKey.Text = "";
                txb_LisansKey.ForeColor = Color.DimGray;
                txb_LisansKey.PasswordChar = '*';
            }
        }

        private void txb_Email_Click(object sender, EventArgs e)
        {
            if (txb_Email.Text == "E-Mail")
            {
                txb_Email.Text = "";
                txb_Email.ForeColor = Color.DimGray;
            }
        }

        private void txb_Sifre_Click(object sender, EventArgs e)
        {
            if (txb_Sifre.Text == "Şifre")
            {
                txb_Sifre.Text = "";
                txb_Sifre.ForeColor = Color.DimGray;
                txb_Sifre.PasswordChar = '*';
            }
        }

        private void txb_LisansKey_Click(object sender, EventArgs e)
        {
            if (txb_LisansKey.Text == "Lisans Key")
            {
                txb_LisansKey.Text = "";
                txb_LisansKey.ForeColor = Color.DimGray;
            }
        }

        private void txb_Email_Leave(object sender, EventArgs e)
        {
            if (String.IsNullOrEmpty(txb_Email.Text))
            {
                txb_Email.Text = "E-Mail";
            }
        }

        private void txb_Sifre_Leave(object sender, EventArgs e)
        {
            if (String.IsNullOrEmpty(txb_Sifre.Text))
            {
                txb_Sifre.Text = "Şifre";
                txb_Sifre.PasswordChar = '\0';
            }
        }

        private void txb_LisansKey_Leave(object sender, EventArgs e)
        {
            if (String.IsNullOrEmpty(txb_LisansKey.Text))
            {
                txb_LisansKey.Text = "Lisans Key";
            }
        }

        private async void btn_GirisKayit_ClickAsync(object sender, EventArgs e)
        {
            Funcs funcs = new Funcs();
            bool isValidEmail = await funcs.isValidMail(txb_Email.Text);
            string isValidPassword = await funcs.isValidPassword(txb_Sifre.Text);
            bool isValidLisanceKey = await funcs.isValidLisanceKey(txb_LisansKey.Text);
            if (!isValidEmail)
            {
                MyMessageBox messageBox = new MyMessageBox("Lütfen geçerli bir mail adresi giriniz.");
                messageBox.ShowDialog();
            }
            else if (!(string.IsNullOrEmpty(isValidPassword)))
            {
                MyMessageBox messageBox = new MyMessageBox(isValidPassword);
                messageBox.ShowDialog();
            }
            else if(!(isValidLisanceKey) && btn_GirisKayit.Text == "Kayıt Ol")
            {
                MyMessageBox messageBox = new MyMessageBox("Lütfen geçerli bir Lisans Key giriniz.\nBeklenen format : XXXX-XXXX-XXXX-XXXX");
                messageBox.ShowDialog();
            }
            else
            {
                if (btn_GirisKayit.Text == "Giriş Yap")
                {
                    string result = await girisYap();
                }
                else
                {
                    string result = await kayitOl();
                }
            }

        }

        private void lbl_GirisKayit_Click(object sender, EventArgs e)
        {
            if (lbl_GirisKayit.Text == "Kayıt Ol")
            {
                lbl_Islem.Text = "Kayıt Ol";
                btn_GirisKayit.Text = "Kayıt Ol";
                lbl_SorunMuYasiyorsun.Text = "Kayıt olurken sorun mu yaşıyorsun?";
                pnl_LisansKey.Visible = true;
                lbl_GirisKayit.Text = "Giriş Yap";
                pnl_Islemler.Height = pnl_Islemler.Height + pnl_LisansKey.Height;
            }
            else
            {
                lbl_Islem.Text = "Giriş Yap";
                btn_GirisKayit.Text = "Giriş Yap";
				lbl_SorunMuYasiyorsun.Text = "Giriş yaparken sorun mu yaşıyorsun?";
				pnl_LisansKey.Visible = false;
                lbl_GirisKayit.Text = "Kayıt Ol";
                pnl_Islemler.Height = pnl_Islemler.Height - pnl_LisansKey.Height;
            }
        }

        private void btn_GirisKayit_Paint(object sender, PaintEventArgs e)
        {
            
        }

        private void txb_Sifre_TextChanged(object sender, EventArgs e)
        {
            txb_Sifre.PasswordChar = '*';
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            if (Properties.Settings.Default.mail != "" && Properties.Settings.Default.password != "")
            {
                txb_Email.Text = Properties.Settings.Default.mail;
                txb_Sifre.Text = Properties.Settings.Default.password;
            }
        }

		private void lbl_SorunMuYasiyorsun_Click(object sender, EventArgs e)
		{
            if (lbl_SorunMuYasiyorsun.Text == "Giriş yaparken sorun mu yaşıyorsun?")
            {
				try
				{
					Process.Start("chrome.exe", "https://x.x/x/loginRules.html");
				}
				catch
				{
					MessageBox.Show("Bilgisayarınızda chrome'un yüklü olmadığı tespit edildi. Lütfen aşağıdaki linke tıklayarak varsayılan tarayıcınızda açınız.\n https://x.x/x/registerRules.html");

				}
			}
            else
            {
				try
				{
					Process.Start("chrome.exe", "https://x.x/x/registerRules.html");
				}
				catch
				{
					MessageBox.Show("Bilgisayarınızda chrome'un yüklü olmadığı tespit edildi. Lütfen aşağıdaki linke tıklayarak varsayılan tarayıcınızda açınız.\n https://x.x/x/registerRules.html");

				}
			}
            
		}
	}
}
