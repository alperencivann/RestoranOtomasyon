﻿namespace RestoranOtomasyon.Forms
{
    partial class YonetimKullaniciAyarlari
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
			this.pnl_KullaniciDuzenleme = new System.Windows.Forms.Panel();
			this.pnl_Kullanicilar = new System.Windows.Forms.Panel();
			this.panel1 = new System.Windows.Forms.Panel();
			this.panel4 = new System.Windows.Forms.Panel();
			this.panel7 = new System.Windows.Forms.Panel();
			this.panel6 = new System.Windows.Forms.Panel();
			this.button2 = new System.Windows.Forms.Button();
			this.label2 = new System.Windows.Forms.Label();
			this.pnl_YetkiDuzenleme = new System.Windows.Forms.Panel();
			this.pnl_Yetkiler = new System.Windows.Forms.Panel();
			this.panel8 = new System.Windows.Forms.Panel();
			this.panel9 = new System.Windows.Forms.Panel();
			this.panel5 = new System.Windows.Forms.Panel();
			this.panel2 = new System.Windows.Forms.Panel();
			this.button1 = new System.Windows.Forms.Button();
			this.label1 = new System.Windows.Forms.Label();
			this.pnl_KullaniciDuzenleme.SuspendLayout();
			this.panel7.SuspendLayout();
			this.panel6.SuspendLayout();
			this.pnl_YetkiDuzenleme.SuspendLayout();
			this.panel5.SuspendLayout();
			this.panel2.SuspendLayout();
			this.SuspendLayout();
			// 
			// pnl_KullaniciDuzenleme
			// 
			this.pnl_KullaniciDuzenleme.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(39)))), ((int)(((byte)(39)))), ((int)(((byte)(39)))));
			this.pnl_KullaniciDuzenleme.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
			this.pnl_KullaniciDuzenleme.Controls.Add(this.pnl_Kullanicilar);
			this.pnl_KullaniciDuzenleme.Controls.Add(this.panel1);
			this.pnl_KullaniciDuzenleme.Controls.Add(this.panel4);
			this.pnl_KullaniciDuzenleme.Controls.Add(this.panel7);
			this.pnl_KullaniciDuzenleme.Dock = System.Windows.Forms.DockStyle.Top;
			this.pnl_KullaniciDuzenleme.Location = new System.Drawing.Point(0, 0);
			this.pnl_KullaniciDuzenleme.Name = "pnl_KullaniciDuzenleme";
			this.pnl_KullaniciDuzenleme.Size = new System.Drawing.Size(734, 319);
			this.pnl_KullaniciDuzenleme.TabIndex = 2;
			// 
			// pnl_Kullanicilar
			// 
			this.pnl_Kullanicilar.AutoScroll = true;
			this.pnl_Kullanicilar.Dock = System.Windows.Forms.DockStyle.Fill;
			this.pnl_Kullanicilar.Location = new System.Drawing.Point(25, 35);
			this.pnl_Kullanicilar.Name = "pnl_Kullanicilar";
			this.pnl_Kullanicilar.Size = new System.Drawing.Size(682, 282);
			this.pnl_Kullanicilar.TabIndex = 8;
			// 
			// panel1
			// 
			this.panel1.Dock = System.Windows.Forms.DockStyle.Right;
			this.panel1.Location = new System.Drawing.Point(707, 35);
			this.panel1.Name = "panel1";
			this.panel1.Size = new System.Drawing.Size(25, 282);
			this.panel1.TabIndex = 7;
			// 
			// panel4
			// 
			this.panel4.Dock = System.Windows.Forms.DockStyle.Left;
			this.panel4.Location = new System.Drawing.Point(0, 35);
			this.panel4.Name = "panel4";
			this.panel4.Size = new System.Drawing.Size(25, 282);
			this.panel4.TabIndex = 5;
			// 
			// panel7
			// 
			this.panel7.Controls.Add(this.panel6);
			this.panel7.Controls.Add(this.label2);
			this.panel7.Dock = System.Windows.Forms.DockStyle.Top;
			this.panel7.Location = new System.Drawing.Point(0, 0);
			this.panel7.Name = "panel7";
			this.panel7.Size = new System.Drawing.Size(732, 35);
			this.panel7.TabIndex = 1;
			// 
			// panel6
			// 
			this.panel6.Controls.Add(this.button2);
			this.panel6.Dock = System.Windows.Forms.DockStyle.Right;
			this.panel6.Location = new System.Drawing.Point(532, 0);
			this.panel6.Name = "panel6";
			this.panel6.Size = new System.Drawing.Size(200, 35);
			this.panel6.TabIndex = 1;
			// 
			// button2
			// 
			this.button2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(2)))), ((int)(((byte)(117)))), ((int)(((byte)(252)))));
			this.button2.FlatAppearance.BorderSize = 0;
			this.button2.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
			this.button2.Font = new System.Drawing.Font("Century Gothic", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
			this.button2.ForeColor = System.Drawing.Color.White;
			this.button2.Location = new System.Drawing.Point(13, 5);
			this.button2.Name = "button2";
			this.button2.Size = new System.Drawing.Size(162, 24);
			this.button2.TabIndex = 5;
			this.button2.Text = "Yeni Kullanıcı Ekle";
			this.button2.UseVisualStyleBackColor = false;
			this.button2.Click += new System.EventHandler(this.button2_Click);
			// 
			// label2
			// 
			this.label2.AutoSize = true;
			this.label2.Font = new System.Drawing.Font("Century Gothic", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
			this.label2.ForeColor = System.Drawing.Color.White;
			this.label2.Location = new System.Drawing.Point(21, 9);
			this.label2.Name = "label2";
			this.label2.Size = new System.Drawing.Size(137, 16);
			this.label2.TabIndex = 0;
			this.label2.Text = "Kullanıcı Düzenleme";
			// 
			// pnl_YetkiDuzenleme
			// 
			this.pnl_YetkiDuzenleme.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(39)))), ((int)(((byte)(39)))), ((int)(((byte)(39)))));
			this.pnl_YetkiDuzenleme.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
			this.pnl_YetkiDuzenleme.Controls.Add(this.pnl_Yetkiler);
			this.pnl_YetkiDuzenleme.Controls.Add(this.panel8);
			this.pnl_YetkiDuzenleme.Controls.Add(this.panel9);
			this.pnl_YetkiDuzenleme.Controls.Add(this.panel5);
			this.pnl_YetkiDuzenleme.Dock = System.Windows.Forms.DockStyle.Top;
			this.pnl_YetkiDuzenleme.Location = new System.Drawing.Point(0, 319);
			this.pnl_YetkiDuzenleme.Name = "pnl_YetkiDuzenleme";
			this.pnl_YetkiDuzenleme.Size = new System.Drawing.Size(734, 286);
			this.pnl_YetkiDuzenleme.TabIndex = 3;
			// 
			// pnl_Yetkiler
			// 
			this.pnl_Yetkiler.AutoScroll = true;
			this.pnl_Yetkiler.Dock = System.Windows.Forms.DockStyle.Fill;
			this.pnl_Yetkiler.Location = new System.Drawing.Point(25, 35);
			this.pnl_Yetkiler.Name = "pnl_Yetkiler";
			this.pnl_Yetkiler.Size = new System.Drawing.Size(682, 249);
			this.pnl_Yetkiler.TabIndex = 11;
			// 
			// panel8
			// 
			this.panel8.Dock = System.Windows.Forms.DockStyle.Right;
			this.panel8.Location = new System.Drawing.Point(707, 35);
			this.panel8.Name = "panel8";
			this.panel8.Size = new System.Drawing.Size(25, 249);
			this.panel8.TabIndex = 10;
			// 
			// panel9
			// 
			this.panel9.Dock = System.Windows.Forms.DockStyle.Left;
			this.panel9.Location = new System.Drawing.Point(0, 35);
			this.panel9.Name = "panel9";
			this.panel9.Size = new System.Drawing.Size(25, 249);
			this.panel9.TabIndex = 9;
			// 
			// panel5
			// 
			this.panel5.Controls.Add(this.panel2);
			this.panel5.Controls.Add(this.label1);
			this.panel5.Dock = System.Windows.Forms.DockStyle.Top;
			this.panel5.Location = new System.Drawing.Point(0, 0);
			this.panel5.Name = "panel5";
			this.panel5.Size = new System.Drawing.Size(732, 35);
			this.panel5.TabIndex = 1;
			// 
			// panel2
			// 
			this.panel2.Controls.Add(this.button1);
			this.panel2.Dock = System.Windows.Forms.DockStyle.Right;
			this.panel2.Location = new System.Drawing.Point(532, 0);
			this.panel2.Name = "panel2";
			this.panel2.Size = new System.Drawing.Size(200, 35);
			this.panel2.TabIndex = 2;
			// 
			// button1
			// 
			this.button1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(2)))), ((int)(((byte)(117)))), ((int)(((byte)(252)))));
			this.button1.FlatAppearance.BorderSize = 0;
			this.button1.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
			this.button1.Font = new System.Drawing.Font("Century Gothic", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
			this.button1.ForeColor = System.Drawing.Color.White;
			this.button1.Location = new System.Drawing.Point(13, 5);
			this.button1.Name = "button1";
			this.button1.Size = new System.Drawing.Size(162, 24);
			this.button1.TabIndex = 5;
			this.button1.Text = "Yeni Yetki Tipi Ekle";
			this.button1.UseVisualStyleBackColor = false;
			this.button1.Click += new System.EventHandler(this.button1_Click);
			// 
			// label1
			// 
			this.label1.AutoSize = true;
			this.label1.Font = new System.Drawing.Font("Century Gothic", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
			this.label1.ForeColor = System.Drawing.Color.White;
			this.label1.Location = new System.Drawing.Point(21, 9);
			this.label1.Name = "label1";
			this.label1.Size = new System.Drawing.Size(114, 16);
			this.label1.TabIndex = 0;
			this.label1.Text = "Yetki Düzenleme";
			// 
			// YonetimKullaniciAyarlari
			// 
			this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
			this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
			this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(49)))), ((int)(((byte)(49)))), ((int)(((byte)(49)))));
			this.ClientSize = new System.Drawing.Size(734, 611);
			this.Controls.Add(this.pnl_YetkiDuzenleme);
			this.Controls.Add(this.pnl_KullaniciDuzenleme);
			this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
			this.Name = "YonetimKullaniciAyarlari";
			this.Text = "YonetimKullaniciAyarlari";
			this.Load += new System.EventHandler(this.YonetimKullaniciAyarlari_Load);
			this.SizeChanged += new System.EventHandler(this.YonetimKullaniciAyarlari_SizeChanged);
			this.pnl_KullaniciDuzenleme.ResumeLayout(false);
			this.panel7.ResumeLayout(false);
			this.panel7.PerformLayout();
			this.panel6.ResumeLayout(false);
			this.pnl_YetkiDuzenleme.ResumeLayout(false);
			this.panel5.ResumeLayout(false);
			this.panel5.PerformLayout();
			this.panel2.ResumeLayout(false);
			this.ResumeLayout(false);

        }

        #endregion
        private System.Windows.Forms.Panel pnl_KullaniciDuzenleme;
        private System.Windows.Forms.Panel panel7;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Panel pnl_YetkiDuzenleme;
        private System.Windows.Forms.Panel panel5;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Panel panel6;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.Panel pnl_Kullanicilar;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Panel panel4;
        private System.Windows.Forms.Panel pnl_Yetkiler;
        private System.Windows.Forms.Panel panel8;
        private System.Windows.Forms.Panel panel9;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.Button button1;
    }
}