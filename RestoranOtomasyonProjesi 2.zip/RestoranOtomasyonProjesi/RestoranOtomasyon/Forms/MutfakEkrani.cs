﻿using RestoranOtomasyon.Components;
using RestoranOtomasyon.Functions;
using RestoranOtomasyon.Objects;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace RestoranOtomasyon.Forms
{
    public partial class MutfakEkrani : Form
    {
		// GLOBAL VARIABLES 
		List<SiparisObject> siparisObjects = new List<SiparisObject>();
		// CONSTRUCTOR AND LOAD EVENT
        public MutfakEkrani()
        {
            InitializeComponent();
        }
		private void MutfakEkrani_Load(object sender, EventArgs e)
		{
            loadSiparisler();
		}


		// FUNCTIONS
		public void loadSiparisler()
		{
			pnl_Siparisler.Controls.Clear();
			Database database = new Database();
			siparisObjects = database.listSiparisler();
			foreach (var siparis in siparisObjects)
			{
				Database urunDb = new Database();
				UrunObject urun = urunDb.getUrun(siparis.UrunId);
				string siparisSaati = siparis.SiparisTarihi.Value.Hour.ToString();
				if (siparis.SiparisTarihi.Value.Minute < 10)
					siparisSaati += ":0" + siparis.SiparisTarihi.Value.Minute.ToString();
				else
					siparisSaati += ":" + siparis.SiparisTarihi.Value.Minute.ToString();

				MutfakSiparisComponent sip = new MutfakSiparisComponent(siparis.Id,urun.ImagePath, urun.UrunAdi, siparis.SiparisAdedi, siparisSaati, "Normal", this)
				{
					Dock = DockStyle.Top
				};
				pnl_Siparisler.Controls.Add(sip);
				Panel marginPanel = new Panel()
				{
					Dock = DockStyle.Top,
					Height = 8,
				};
				pnl_Siparisler.Controls.Add(marginPanel);
			}
			
		}

		// EVENTS

		private void MutfakEkrani_FormClosed(object sender, FormClosedEventArgs e)
		{
			Application.Exit();
		}

		private void btn_Exit_Click(object sender, EventArgs e)
		{
			Application.Exit();
		}
	}
}
