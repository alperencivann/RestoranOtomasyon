﻿using Mail.Forms;
using RestoranOtomasyon.Functions;
using RestoranOtomasyon.Objects;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Runtime.InteropServices;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace RestoranOtomasyon.Forms
{
    public partial class YonetimYetkileriDuzenlemeForm : Form
    {
        // GLOBAL VARIABLES
        int yetkiId;
        string yetkiAdi;



        
        public bool ayarErisim = false;
        public bool eklemeGuncelleme = false;
        public bool yapilacaklarListesineEkleme = false;
        public bool yapilacaklarListesindenSilme = false;
        public bool siparisIptalEtme = false;
        public bool bayiGoruntuleme = false;
        public bool raporGoruntuleme = false;
        public bool telegram = false;
        public bool modulDuzenleme = false;
        public bool urunYonetimi = false;

        // CONSTRUCTOR AND LOAD EVENT
        bool saved = false;
        //public YonetimYetkileriDuzenlemeForm([Optional]int yetkiId, [Optional]string yetkiAdi, [Optional]bool ayarErisim, [Optional]bool eklemeGuncelleme,[Optional]bool yapilacaklarListesineEkleme, [Optional]bool yapilacaklarListesindenSilme, [Optional]bool siparisIptalEtme,[Optional]bool bayiGoruntuleme, [Optional]bool raporGoruntuleme, [Optional] bool telegram, [Optional] bool modulDuzenleme, [Optional] bool urunYonetimi)
        public YonetimYetkileriDuzenlemeForm([Optional]int yetkiId)
        {
            InitializeComponent();
            if (yetkiId > 0)
            {
                saved = true;
                this.yetkiId = yetkiId;
                Database db = new Database();
                YetkiObject yetki = db.getYetki(yetkiId);
                this.yetkiAdi = yetki.YetkiAdi;
                this.ayarErisim = yetki.AyarErisim;
                this.eklemeGuncelleme = yetki.EklemeGuncelleme;
                this.yapilacaklarListesineEkleme = yetki.YapilacaklarListesineEkleme;
                this.yapilacaklarListesindenSilme = yetki.YapilacaklarListesindenSilme;
                this.siparisIptalEtme = yetki.SiparisIptalEtme;
                this.bayiGoruntuleme = yetki.BayiGoruntuleme;
                this.raporGoruntuleme = yetki.RaporGoruntuleme;
                this.telegram = yetki.Telegram;
                this.modulDuzenleme = yetki.ModulDuzenleme;
                this.urunYonetimi = yetki.UrunYonetimi;
                txb_RestoranAdi.Text = "Güncelle";
            }
            else
            {
                txb_RestoranAdi.Text = "Kaydet";
            }
            
        }
        private void YonetimYetkileriDuzenlemeForm_Load(object sender, EventArgs e)
        {
            if (saved)
            {
                txb_RestoranAdi.Text = yetkiAdi;
            }
            setAyarlarEkrani(ayarErisim);
            setYonetimEklemeGuncelleme(eklemeGuncelleme);
            setYapilacaklarListesineEkleme(eklemeGuncelleme);
            setYapilacaklarListesindenSilme(yapilacaklarListesindenSilme);
            setSiparisIptalEtme(siparisIptalEtme);
            setBayiGoruntuleme(bayiGoruntuleme);
            setRaporGoruntuleme(raporGoruntuleme);
            setTelegram(telegram);
            setModul(modulDuzenleme);
            setUrun(urunYonetimi);
        }

        // FUNCTIONS

        public void Message(string message)
        {
            MyMessageBox myMessageBox = new MyMessageBox(message);
            myMessageBox.Show();

        }
        public void setAyarlarEkrani(bool active)
        {
            if (active)
                pcb_ayarlarEkrani.Image = imageList.Images[1];
            else
                pcb_ayarlarEkrani.Image = imageList.Images[0];
           
        }
        public void setYonetimEklemeGuncelleme(bool active)
        {
            if (active)
                pcb_YonetimEklemeGuncelleme.Image = imageList.Images[1];
            else
                pcb_YonetimEklemeGuncelleme.Image = imageList.Images[0];
        }
        public void setYapilacaklarListesineEkleme(bool active)
        {
            if (active)
                pcb_YapilacaklarListesineEkleme.Image = imageList.Images[1];
            else
                pcb_YapilacaklarListesineEkleme.Image = imageList.Images[0];
        }
        public void setYapilacaklarListesindenSilme(bool active)
        {
            if (active)
                pcb_YapilacaklarListesindenSilme.Image = imageList.Images[1];
            else
                pcb_YapilacaklarListesindenSilme.Image = imageList.Images[0];
        }
        public void setSiparisIptalEtme(bool active)
        {
            if (active)
                pcb_SiparisIptalEtme.Image = imageList.Images[1];
            else
                pcb_SiparisIptalEtme.Image = imageList.Images[0];
        }
        public void setBayiGoruntuleme(bool active)
        {
            if (active)
                pcb_BayiGoruntuleme.Image = imageList.Images[1];
            else
                pcb_BayiGoruntuleme.Image = imageList.Images[0];
        }
        public void setRaporGoruntuleme(bool active)
        {
            if (active)
                pcb_RaporGoruntuleme.Image = imageList.Images[1];
            else
                pcb_RaporGoruntuleme.Image = imageList.Images[0];
        }
        public void setTelegram(bool active)
        {
            if (active)
                pcb_Telegram.Image = imageList.Images[1];
            else
                pcb_Telegram.Image = imageList.Images[0];
        }
        public void setModul(bool active)
        {
            if (active)
                pcb_Modul.Image = imageList.Images[1];
            else
                pcb_Modul.Image = imageList.Images[0];
        }
        public void setUrun(bool active)
        {
            if (active)
                pcb_Urun.Image = imageList.Images[1];
            else
                pcb_Urun.Image = imageList.Images[0];
        }
        // EVENTS
        private void btn_Exit_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void pcb_ayarlarEkrani_Click(object sender, EventArgs e)
        {
            ayarErisim = !ayarErisim;
            setAyarlarEkrani(ayarErisim);
        }

        private void pcb_YonetimEklemeGuncelleme_Click(object sender, EventArgs e)
        {
            eklemeGuncelleme = !eklemeGuncelleme;
            setYonetimEklemeGuncelleme(eklemeGuncelleme);
        }

        private void pcb_YapilacaklarListesineEkleme_Click(object sender, EventArgs e)
        {
            yapilacaklarListesineEkleme = !yapilacaklarListesineEkleme;
            setYapilacaklarListesineEkleme(yapilacaklarListesineEkleme);
        }

        private void pcb_YapilacaklarListesindenSilme_Click(object sender, EventArgs e)
        {
            yapilacaklarListesindenSilme = !yapilacaklarListesindenSilme;
            setYapilacaklarListesindenSilme(yapilacaklarListesindenSilme);
        }

        private void pcb_SiparisIptalEtme_Click(object sender, EventArgs e)
        {
            siparisIptalEtme = !siparisIptalEtme;
            setSiparisIptalEtme(siparisIptalEtme);
        }

        private void pcb_BayiGoruntuleme_Click(object sender, EventArgs e)
        {
            bayiGoruntuleme = !bayiGoruntuleme;
            setBayiGoruntuleme(bayiGoruntuleme);
        }

        private void pcb_RaporGoruntuleme_Click(object sender, EventArgs e)
        {
            raporGoruntuleme = !raporGoruntuleme;
            setRaporGoruntuleme(raporGoruntuleme);
        }

        private void pcb_Telegram_Click(object sender, EventArgs e)
        {
            telegram = !telegram;
            setTelegram(telegram);
        }

        private void pcb_Modul_Click(object sender, EventArgs e)
        {
            modulDuzenleme = !modulDuzenleme;
            setModul(modulDuzenleme);
        }

        private void pcb_Urun_Click(object sender, EventArgs e)
        {
            urunYonetimi = !urunYonetimi;
            setUrun(urunYonetimi);
        }

        private void btn_Guncelle_Click(object sender, EventArgs e)
        {
            if ((string.IsNullOrEmpty(txb_RestoranAdi.Text)))
            {
                Message("Lütfen yetki adı giriniz.");
            }
            else
            {
                Database dbIsSaved = new Database();
                YetkiObject yetki = dbIsSaved.getYetkiFromName(txb_RestoranAdi.Text);
                if (!(string.IsNullOrEmpty(yetki.YetkiAdi)) && this.yetkiId != yetki.Id)
                {
                    Message("Bu yetki adı önceden kaydedilmiş.\nLütfen başka bir yetki adı giriniz.");
                }
                else if (this.yetkiId == yetki.Id && saved)
                {
                    // GÜNCELLEME YAPILACAK
                    Database database = new Database();
                    YetkiObject yetkiObj = new YetkiObject()
                    {
                        Id = this.yetkiId,
                        YetkiAdi = txb_RestoranAdi.Text,
                        AyarErisim = this.ayarErisim,
                        EklemeGuncelleme = this.eklemeGuncelleme,
                        YapilacaklarListesineEkleme = this.yapilacaklarListesineEkleme,
                        YapilacaklarListesindenSilme = this.yapilacaklarListesindenSilme,
                        SiparisIptalEtme = this.siparisIptalEtme,
                        BayiGoruntuleme = this.bayiGoruntuleme,
                        RaporGoruntuleme = this.raporGoruntuleme,
                        Telegram = this.telegram,
                        ModulDuzenleme = this.modulDuzenleme,
                        UrunYonetimi = this.urunYonetimi
                    };
                    string result = database.updateYetki(yetkiObj);
                    Message(result);
                }
                else
                {
                    // INSERT YAPILACAK
                    Database database = new Database();
                    YetkiObject yetkiObj = new YetkiObject()
                    {
                        YetkiAdi = txb_RestoranAdi.Text,
                        AyarErisim = this.ayarErisim,
                        EklemeGuncelleme = this.eklemeGuncelleme,
                        YapilacaklarListesineEkleme = this.yapilacaklarListesineEkleme,
                        YapilacaklarListesindenSilme = this.yapilacaklarListesindenSilme,
                        SiparisIptalEtme = this.siparisIptalEtme,
                        BayiGoruntuleme = this.bayiGoruntuleme,
                        RaporGoruntuleme = this.raporGoruntuleme,
                        Telegram = this.telegram,
                        ModulDuzenleme = this.modulDuzenleme,
                        UrunYonetimi = this.urunYonetimi
                    };
                    string result = database.insertYetki(yetkiObj);
                    Message(result);
                    
                }
            }
        }
    }
}
