﻿namespace RestoranOtomasyon.Forms
{
	partial class HesapAl
	{
		/// <summary>
		/// Required designer variable.
		/// </summary>
		private System.ComponentModel.IContainer components = null;

		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		/// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
		protected override void Dispose(bool disposing)
		{
			if (disposing && (components != null))
			{
				components.Dispose();
			}
			base.Dispose(disposing);
		}

		#region Windows Form Designer generated code

		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			this.panel1 = new System.Windows.Forms.Panel();
			this.lbl_Header = new System.Windows.Forms.Label();
			this.panel2 = new System.Windows.Forms.Panel();
			this.panel10 = new System.Windows.Forms.Panel();
			this.btn_Exit = new System.Windows.Forms.Button();
			this.panel5 = new System.Windows.Forms.Panel();
			this.panel4 = new System.Windows.Forms.Panel();
			this.panel3 = new System.Windows.Forms.Panel();
			this.pnl_Urunler = new System.Windows.Forms.Panel();
			this.pnl_Urun = new System.Windows.Forms.Panel();
			this.pnl_Adisyon = new System.Windows.Forms.Panel();
			this.panel6 = new System.Windows.Forms.Panel();
			this.panel7 = new System.Windows.Forms.Panel();
			this.lbl_ToplamTutar = new System.Windows.Forms.Label();
			this.label1 = new System.Windows.Forms.Label();
			this.btn_FisYazdir = new System.Windows.Forms.Button();
			this.panel11 = new System.Windows.Forms.Panel();
			this.txb_MasaNo = new System.Windows.Forms.TextBox();
			this.label5 = new System.Windows.Forms.Label();
			this.panel8 = new System.Windows.Forms.Panel();
			this.txb_KalanTutar = new System.Windows.Forms.TextBox();
			this.label2 = new System.Windows.Forms.Label();
			this.panel9 = new System.Windows.Forms.Panel();
			this.label3 = new System.Windows.Forms.Label();
			this.panel12 = new System.Windows.Forms.Panel();
			this.txb_AlinacakOdeme = new System.Windows.Forms.TextBox();
			this.label4 = new System.Windows.Forms.Label();
			this.btn_HesaptanDus = new System.Windows.Forms.Button();
			this.panel13 = new System.Windows.Forms.Panel();
			this.panel14 = new System.Windows.Forms.Panel();
			this.label7 = new System.Windows.Forms.Label();
			this.panel15 = new System.Windows.Forms.Panel();
			this.panel17 = new System.Windows.Forms.Panel();
			this.panel16 = new System.Windows.Forms.Panel();
			this.dgw_GecmisOdemeler = new System.Windows.Forms.DataGridView();
			this.dataGridViewTextBoxColumn1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
			this.dataGridViewTextBoxColumn2 = new System.Windows.Forms.DataGridViewTextBoxColumn();
			this.dataGridViewTextBoxColumn3 = new System.Windows.Forms.DataGridViewTextBoxColumn();
			this.dataGridViewTextBoxColumn4 = new System.Windows.Forms.DataGridViewTextBoxColumn();
			this.btn_HesabiKapat = new System.Windows.Forms.Button();
			this.dgw_Siparisler = new System.Windows.Forms.DataGridView();
			this.id = new System.Windows.Forms.DataGridViewTextBoxColumn();
			this.ad = new System.Windows.Forms.DataGridViewTextBoxColumn();
			this.adet = new System.Windows.Forms.DataGridViewTextBoxColumn();
			this.adetFiyat = new System.Windows.Forms.DataGridViewTextBoxColumn();
			this.toplamFiyat = new System.Windows.Forms.DataGridViewTextBoxColumn();
			this.panel1.SuspendLayout();
			this.panel10.SuspendLayout();
			this.panel5.SuspendLayout();
			this.panel4.SuspendLayout();
			this.panel3.SuspendLayout();
			this.pnl_Urunler.SuspendLayout();
			this.pnl_Urun.SuspendLayout();
			this.pnl_Adisyon.SuspendLayout();
			this.panel6.SuspendLayout();
			this.panel7.SuspendLayout();
			this.panel11.SuspendLayout();
			this.panel8.SuspendLayout();
			this.panel9.SuspendLayout();
			this.panel12.SuspendLayout();
			this.panel13.SuspendLayout();
			this.panel14.SuspendLayout();
			this.panel15.SuspendLayout();
			this.panel17.SuspendLayout();
			this.panel16.SuspendLayout();
			((System.ComponentModel.ISupportInitialize)(this.dgw_GecmisOdemeler)).BeginInit();
			((System.ComponentModel.ISupportInitialize)(this.dgw_Siparisler)).BeginInit();
			this.SuspendLayout();
			// 
			// panel1
			// 
			this.panel1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(24)))), ((int)(((byte)(24)))), ((int)(((byte)(24)))));
			this.panel1.Controls.Add(this.lbl_Header);
			this.panel1.Controls.Add(this.panel2);
			this.panel1.Controls.Add(this.panel10);
			this.panel1.Dock = System.Windows.Forms.DockStyle.Top;
			this.panel1.Location = new System.Drawing.Point(0, 0);
			this.panel1.Name = "panel1";
			this.panel1.Size = new System.Drawing.Size(1163, 50);
			this.panel1.TabIndex = 2;
			// 
			// lbl_Header
			// 
			this.lbl_Header.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(29)))), ((int)(((byte)(29)))), ((int)(((byte)(29)))));
			this.lbl_Header.Dock = System.Windows.Forms.DockStyle.Fill;
			this.lbl_Header.Font = new System.Drawing.Font("Century Gothic", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
			this.lbl_Header.ForeColor = System.Drawing.Color.White;
			this.lbl_Header.Location = new System.Drawing.Point(36, 0);
			this.lbl_Header.Name = "lbl_Header";
			this.lbl_Header.Size = new System.Drawing.Size(1091, 50);
			this.lbl_Header.TabIndex = 5;
			this.lbl_Header.Text = "Hesap Al";
			this.lbl_Header.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
			// 
			// panel2
			// 
			this.panel2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(29)))), ((int)(((byte)(29)))), ((int)(((byte)(29)))));
			this.panel2.Dock = System.Windows.Forms.DockStyle.Left;
			this.panel2.Location = new System.Drawing.Point(0, 0);
			this.panel2.Name = "panel2";
			this.panel2.Size = new System.Drawing.Size(36, 50);
			this.panel2.TabIndex = 4;
			// 
			// panel10
			// 
			this.panel10.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(29)))), ((int)(((byte)(29)))), ((int)(((byte)(29)))));
			this.panel10.Controls.Add(this.btn_Exit);
			this.panel10.Dock = System.Windows.Forms.DockStyle.Right;
			this.panel10.Location = new System.Drawing.Point(1127, 0);
			this.panel10.Name = "panel10";
			this.panel10.Size = new System.Drawing.Size(36, 50);
			this.panel10.TabIndex = 3;
			// 
			// btn_Exit
			// 
			this.btn_Exit.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(24)))), ((int)(((byte)(24)))), ((int)(((byte)(24)))));
			this.btn_Exit.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
			this.btn_Exit.Font = new System.Drawing.Font("Century Gothic", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
			this.btn_Exit.ForeColor = System.Drawing.Color.Red;
			this.btn_Exit.Location = new System.Drawing.Point(4, 9);
			this.btn_Exit.Name = "btn_Exit";
			this.btn_Exit.Size = new System.Drawing.Size(29, 31);
			this.btn_Exit.TabIndex = 1;
			this.btn_Exit.Text = "x";
			this.btn_Exit.UseVisualStyleBackColor = false;
			this.btn_Exit.Click += new System.EventHandler(this.btn_Exit_Click);
			// 
			// panel5
			// 
			this.panel5.AutoScroll = true;
			this.panel5.Controls.Add(this.panel9);
			this.panel5.Controls.Add(this.panel8);
			this.panel5.Controls.Add(this.panel11);
			this.panel5.Dock = System.Windows.Forms.DockStyle.Top;
			this.panel5.Location = new System.Drawing.Point(0, 0);
			this.panel5.Name = "panel5";
			this.panel5.Size = new System.Drawing.Size(580, 202);
			this.panel5.TabIndex = 0;
			// 
			// panel4
			// 
			this.panel4.AutoScroll = true;
			this.panel4.Controls.Add(this.panel13);
			this.panel4.Dock = System.Windows.Forms.DockStyle.Fill;
			this.panel4.Location = new System.Drawing.Point(0, 202);
			this.panel4.Name = "panel4";
			this.panel4.Size = new System.Drawing.Size(580, 219);
			this.panel4.TabIndex = 1;
			// 
			// panel3
			// 
			this.panel3.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(39)))), ((int)(((byte)(39)))), ((int)(((byte)(39)))));
			this.panel3.Controls.Add(this.panel4);
			this.panel3.Controls.Add(this.panel5);
			this.panel3.Dock = System.Windows.Forms.DockStyle.Left;
			this.panel3.Location = new System.Drawing.Point(0, 50);
			this.panel3.Name = "panel3";
			this.panel3.Size = new System.Drawing.Size(580, 421);
			this.panel3.TabIndex = 4;
			// 
			// pnl_Urunler
			// 
			this.pnl_Urunler.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(39)))), ((int)(((byte)(39)))), ((int)(((byte)(39)))));
			this.pnl_Urunler.Controls.Add(this.pnl_Urun);
			this.pnl_Urunler.Dock = System.Windows.Forms.DockStyle.Fill;
			this.pnl_Urunler.Location = new System.Drawing.Point(580, 50);
			this.pnl_Urunler.Name = "pnl_Urunler";
			this.pnl_Urunler.Size = new System.Drawing.Size(583, 421);
			this.pnl_Urunler.TabIndex = 5;
			// 
			// pnl_Urun
			// 
			this.pnl_Urun.AutoScroll = true;
			this.pnl_Urun.Controls.Add(this.pnl_Adisyon);
			this.pnl_Urun.Dock = System.Windows.Forms.DockStyle.Fill;
			this.pnl_Urun.Location = new System.Drawing.Point(0, 0);
			this.pnl_Urun.Name = "pnl_Urun";
			this.pnl_Urun.Size = new System.Drawing.Size(583, 421);
			this.pnl_Urun.TabIndex = 1;
			// 
			// pnl_Adisyon
			// 
			this.pnl_Adisyon.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(29)))), ((int)(((byte)(29)))), ((int)(((byte)(29)))));
			this.pnl_Adisyon.Controls.Add(this.dgw_Siparisler);
			this.pnl_Adisyon.Controls.Add(this.panel6);
			this.pnl_Adisyon.Dock = System.Windows.Forms.DockStyle.Fill;
			this.pnl_Adisyon.Location = new System.Drawing.Point(0, 0);
			this.pnl_Adisyon.Name = "pnl_Adisyon";
			this.pnl_Adisyon.Size = new System.Drawing.Size(583, 421);
			this.pnl_Adisyon.TabIndex = 4;
			// 
			// panel6
			// 
			this.panel6.Controls.Add(this.panel7);
			this.panel6.Controls.Add(this.btn_FisYazdir);
			this.panel6.Dock = System.Windows.Forms.DockStyle.Bottom;
			this.panel6.Location = new System.Drawing.Point(0, 336);
			this.panel6.Margin = new System.Windows.Forms.Padding(2);
			this.panel6.Name = "panel6";
			this.panel6.Size = new System.Drawing.Size(583, 85);
			this.panel6.TabIndex = 2;
			// 
			// panel7
			// 
			this.panel7.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(29)))), ((int)(((byte)(29)))), ((int)(((byte)(29)))));
			this.panel7.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
			this.panel7.Controls.Add(this.lbl_ToplamTutar);
			this.panel7.Controls.Add(this.label1);
			this.panel7.Location = new System.Drawing.Point(8, 6);
			this.panel7.Margin = new System.Windows.Forms.Padding(2);
			this.panel7.Name = "panel7";
			this.panel7.Size = new System.Drawing.Size(566, 39);
			this.panel7.TabIndex = 1;
			// 
			// lbl_ToplamTutar
			// 
			this.lbl_ToplamTutar.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
			this.lbl_ToplamTutar.Font = new System.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
			this.lbl_ToplamTutar.ForeColor = System.Drawing.Color.Lime;
			this.lbl_ToplamTutar.Location = new System.Drawing.Point(458, 0);
			this.lbl_ToplamTutar.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
			this.lbl_ToplamTutar.Name = "lbl_ToplamTutar";
			this.lbl_ToplamTutar.Size = new System.Drawing.Size(104, 37);
			this.lbl_ToplamTutar.TabIndex = 1;
			this.lbl_ToplamTutar.Text = "300₺";
			this.lbl_ToplamTutar.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
			// 
			// label1
			// 
			this.label1.Font = new System.Drawing.Font("Century Gothic", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
			this.label1.ForeColor = System.Drawing.Color.White;
			this.label1.Location = new System.Drawing.Point(6, 0);
			this.label1.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
			this.label1.Name = "label1";
			this.label1.Size = new System.Drawing.Size(150, 37);
			this.label1.TabIndex = 0;
			this.label1.Text = "Toplam Tutar";
			this.label1.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
			// 
			// btn_FisYazdir
			// 
			this.btn_FisYazdir.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
			this.btn_FisYazdir.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(252)))), ((int)(((byte)(92)))), ((int)(((byte)(2)))));
			this.btn_FisYazdir.FlatAppearance.BorderSize = 0;
			this.btn_FisYazdir.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
			this.btn_FisYazdir.Font = new System.Drawing.Font("Century Gothic", 10.125F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
			this.btn_FisYazdir.ForeColor = System.Drawing.Color.White;
			this.btn_FisYazdir.Location = new System.Drawing.Point(8, 49);
			this.btn_FisYazdir.Margin = new System.Windows.Forms.Padding(2);
			this.btn_FisYazdir.Name = "btn_FisYazdir";
			this.btn_FisYazdir.Size = new System.Drawing.Size(566, 31);
			this.btn_FisYazdir.TabIndex = 0;
			this.btn_FisYazdir.Text = "Siparişi Kaydet";
			this.btn_FisYazdir.UseVisualStyleBackColor = false;
			// 
			// panel11
			// 
			this.panel11.Controls.Add(this.txb_MasaNo);
			this.panel11.Controls.Add(this.label5);
			this.panel11.Dock = System.Windows.Forms.DockStyle.Top;
			this.panel11.Location = new System.Drawing.Point(0, 0);
			this.panel11.Name = "panel11";
			this.panel11.Size = new System.Drawing.Size(580, 43);
			this.panel11.TabIndex = 7;
			// 
			// txb_MasaNo
			// 
			this.txb_MasaNo.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
			this.txb_MasaNo.Cursor = System.Windows.Forms.Cursors.Default;
			this.txb_MasaNo.Enabled = false;
			this.txb_MasaNo.Font = new System.Drawing.Font("Century Gothic", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
			this.txb_MasaNo.Location = new System.Drawing.Point(153, 6);
			this.txb_MasaNo.Name = "txb_MasaNo";
			this.txb_MasaNo.Size = new System.Drawing.Size(403, 31);
			this.txb_MasaNo.TabIndex = 2;
			this.txb_MasaNo.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
			// 
			// label5
			// 
			this.label5.AutoSize = true;
			this.label5.Font = new System.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
			this.label5.ForeColor = System.Drawing.Color.White;
			this.label5.Location = new System.Drawing.Point(12, 12);
			this.label5.Name = "label5";
			this.label5.Size = new System.Drawing.Size(77, 19);
			this.label5.TabIndex = 1;
			this.label5.Text = "Masa No";
			// 
			// panel8
			// 
			this.panel8.Controls.Add(this.txb_KalanTutar);
			this.panel8.Controls.Add(this.label2);
			this.panel8.Dock = System.Windows.Forms.DockStyle.Top;
			this.panel8.Location = new System.Drawing.Point(0, 43);
			this.panel8.Name = "panel8";
			this.panel8.Size = new System.Drawing.Size(580, 43);
			this.panel8.TabIndex = 8;
			// 
			// txb_KalanTutar
			// 
			this.txb_KalanTutar.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
			this.txb_KalanTutar.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(29)))), ((int)(((byte)(29)))), ((int)(((byte)(29)))));
			this.txb_KalanTutar.Cursor = System.Windows.Forms.Cursors.Default;
			this.txb_KalanTutar.Enabled = false;
			this.txb_KalanTutar.Font = new System.Drawing.Font("Century Gothic", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
			this.txb_KalanTutar.ForeColor = System.Drawing.Color.Lime;
			this.txb_KalanTutar.Location = new System.Drawing.Point(153, 6);
			this.txb_KalanTutar.Name = "txb_KalanTutar";
			this.txb_KalanTutar.Size = new System.Drawing.Size(403, 31);
			this.txb_KalanTutar.TabIndex = 2;
			this.txb_KalanTutar.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
			// 
			// label2
			// 
			this.label2.AutoSize = true;
			this.label2.Font = new System.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
			this.label2.ForeColor = System.Drawing.Color.White;
			this.label2.Location = new System.Drawing.Point(12, 12);
			this.label2.Name = "label2";
			this.label2.Size = new System.Drawing.Size(96, 19);
			this.label2.TabIndex = 1;
			this.label2.Text = "Kalan Tutar";
			// 
			// panel9
			// 
			this.panel9.Controls.Add(this.panel12);
			this.panel9.Controls.Add(this.label3);
			this.panel9.Dock = System.Windows.Forms.DockStyle.Fill;
			this.panel9.Location = new System.Drawing.Point(0, 86);
			this.panel9.Name = "panel9";
			this.panel9.Size = new System.Drawing.Size(580, 116);
			this.panel9.TabIndex = 9;
			// 
			// label3
			// 
			this.label3.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(29)))), ((int)(((byte)(29)))), ((int)(((byte)(29)))));
			this.label3.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
			this.label3.Dock = System.Windows.Forms.DockStyle.Top;
			this.label3.Font = new System.Drawing.Font("Century Gothic", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
			this.label3.ForeColor = System.Drawing.Color.White;
			this.label3.Location = new System.Drawing.Point(0, 0);
			this.label3.Name = "label3";
			this.label3.Size = new System.Drawing.Size(580, 33);
			this.label3.TabIndex = 6;
			this.label3.Text = "Ödeme Al";
			this.label3.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
			// 
			// panel12
			// 
			this.panel12.Controls.Add(this.btn_HesaptanDus);
			this.panel12.Controls.Add(this.txb_AlinacakOdeme);
			this.panel12.Controls.Add(this.label4);
			this.panel12.Dock = System.Windows.Forms.DockStyle.Top;
			this.panel12.Location = new System.Drawing.Point(0, 33);
			this.panel12.Name = "panel12";
			this.panel12.Size = new System.Drawing.Size(580, 80);
			this.panel12.TabIndex = 9;
			// 
			// txb_AlinacakOdeme
			// 
			this.txb_AlinacakOdeme.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
			this.txb_AlinacakOdeme.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(29)))), ((int)(((byte)(29)))), ((int)(((byte)(29)))));
			this.txb_AlinacakOdeme.Enabled = false;
			this.txb_AlinacakOdeme.Font = new System.Drawing.Font("Century Gothic", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
			this.txb_AlinacakOdeme.ForeColor = System.Drawing.Color.Lime;
			this.txb_AlinacakOdeme.Location = new System.Drawing.Point(153, 6);
			this.txb_AlinacakOdeme.Name = "txb_AlinacakOdeme";
			this.txb_AlinacakOdeme.Size = new System.Drawing.Size(403, 31);
			this.txb_AlinacakOdeme.TabIndex = 2;
			this.txb_AlinacakOdeme.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
			// 
			// label4
			// 
			this.label4.AutoSize = true;
			this.label4.Font = new System.Drawing.Font("Century Gothic", 11F, System.Drawing.FontStyle.Bold);
			this.label4.ForeColor = System.Drawing.Color.White;
			this.label4.Location = new System.Drawing.Point(12, 12);
			this.label4.Name = "label4";
			this.label4.Size = new System.Drawing.Size(136, 18);
			this.label4.TabIndex = 1;
			this.label4.Text = "Alınacak Ödeme";
			// 
			// btn_HesaptanDus
			// 
			this.btn_HesaptanDus.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
			this.btn_HesaptanDus.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(2)))), ((int)(((byte)(117)))), ((int)(((byte)(252)))));
			this.btn_HesaptanDus.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(89)))), ((int)(((byte)(89)))), ((int)(((byte)(89)))));
			this.btn_HesaptanDus.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
			this.btn_HesaptanDus.Font = new System.Drawing.Font("Century Gothic", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
			this.btn_HesaptanDus.ForeColor = System.Drawing.Color.White;
			this.btn_HesaptanDus.Location = new System.Drawing.Point(153, 42);
			this.btn_HesaptanDus.Name = "btn_HesaptanDus";
			this.btn_HesaptanDus.Size = new System.Drawing.Size(403, 30);
			this.btn_HesaptanDus.TabIndex = 14;
			this.btn_HesaptanDus.Text = "Hesaptan Düş";
			this.btn_HesaptanDus.UseVisualStyleBackColor = false;
			this.btn_HesaptanDus.Click += new System.EventHandler(this.btn_HesaptanDus_Click);
			// 
			// panel13
			// 
			this.panel13.Controls.Add(this.panel14);
			this.panel13.Dock = System.Windows.Forms.DockStyle.Fill;
			this.panel13.Location = new System.Drawing.Point(0, 0);
			this.panel13.Name = "panel13";
			this.panel13.Size = new System.Drawing.Size(580, 219);
			this.panel13.TabIndex = 10;
			// 
			// panel14
			// 
			this.panel14.Controls.Add(this.panel16);
			this.panel14.Controls.Add(this.panel17);
			this.panel14.Controls.Add(this.panel15);
			this.panel14.Dock = System.Windows.Forms.DockStyle.Fill;
			this.panel14.Location = new System.Drawing.Point(0, 0);
			this.panel14.Name = "panel14";
			this.panel14.Size = new System.Drawing.Size(580, 219);
			this.panel14.TabIndex = 9;
			// 
			// label7
			// 
			this.label7.AutoSize = true;
			this.label7.Font = new System.Drawing.Font("Century Gothic", 9F, System.Drawing.FontStyle.Bold);
			this.label7.ForeColor = System.Drawing.Color.White;
			this.label7.Location = new System.Drawing.Point(13, 15);
			this.label7.Name = "label7";
			this.label7.Size = new System.Drawing.Size(103, 16);
			this.label7.TabIndex = 3;
			this.label7.Text = "Ödeme Geçmişi";
			// 
			// panel15
			// 
			this.panel15.Controls.Add(this.label7);
			this.panel15.Dock = System.Windows.Forms.DockStyle.Top;
			this.panel15.Location = new System.Drawing.Point(0, 0);
			this.panel15.Name = "panel15";
			this.panel15.Size = new System.Drawing.Size(580, 35);
			this.panel15.TabIndex = 4;
			// 
			// panel17
			// 
			this.panel17.Controls.Add(this.btn_HesabiKapat);
			this.panel17.Dock = System.Windows.Forms.DockStyle.Bottom;
			this.panel17.Location = new System.Drawing.Point(0, 181);
			this.panel17.Name = "panel17";
			this.panel17.Size = new System.Drawing.Size(580, 38);
			this.panel17.TabIndex = 6;
			// 
			// panel16
			// 
			this.panel16.Controls.Add(this.dgw_GecmisOdemeler);
			this.panel16.Dock = System.Windows.Forms.DockStyle.Fill;
			this.panel16.Location = new System.Drawing.Point(0, 35);
			this.panel16.Name = "panel16";
			this.panel16.Size = new System.Drawing.Size(580, 146);
			this.panel16.TabIndex = 7;
			// 
			// dgw_GecmisOdemeler
			// 
			this.dgw_GecmisOdemeler.AllowUserToAddRows = false;
			this.dgw_GecmisOdemeler.AllowUserToDeleteRows = false;
			this.dgw_GecmisOdemeler.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
			this.dgw_GecmisOdemeler.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
			this.dgw_GecmisOdemeler.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
			this.dgw_GecmisOdemeler.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.dataGridViewTextBoxColumn1,
            this.dataGridViewTextBoxColumn2,
            this.dataGridViewTextBoxColumn3,
            this.dataGridViewTextBoxColumn4});
			this.dgw_GecmisOdemeler.Location = new System.Drawing.Point(16, 5);
			this.dgw_GecmisOdemeler.Margin = new System.Windows.Forms.Padding(2);
			this.dgw_GecmisOdemeler.Name = "dgw_GecmisOdemeler";
			this.dgw_GecmisOdemeler.ReadOnly = true;
			this.dgw_GecmisOdemeler.RowHeadersVisible = false;
			this.dgw_GecmisOdemeler.RowHeadersWidth = 82;
			this.dgw_GecmisOdemeler.RowTemplate.Height = 33;
			this.dgw_GecmisOdemeler.Size = new System.Drawing.Size(540, 133);
			this.dgw_GecmisOdemeler.TabIndex = 2;
			// 
			// dataGridViewTextBoxColumn1
			// 
			this.dataGridViewTextBoxColumn1.HeaderText = "Ürün Adı";
			this.dataGridViewTextBoxColumn1.Name = "dataGridViewTextBoxColumn1";
			this.dataGridViewTextBoxColumn1.ReadOnly = true;
			// 
			// dataGridViewTextBoxColumn2
			// 
			this.dataGridViewTextBoxColumn2.HeaderText = "Ürün Adedi";
			this.dataGridViewTextBoxColumn2.Name = "dataGridViewTextBoxColumn2";
			this.dataGridViewTextBoxColumn2.ReadOnly = true;
			// 
			// dataGridViewTextBoxColumn3
			// 
			this.dataGridViewTextBoxColumn3.HeaderText = "Adet Fiyatı";
			this.dataGridViewTextBoxColumn3.Name = "dataGridViewTextBoxColumn3";
			this.dataGridViewTextBoxColumn3.ReadOnly = true;
			// 
			// dataGridViewTextBoxColumn4
			// 
			this.dataGridViewTextBoxColumn4.HeaderText = "Toplam Fiyat";
			this.dataGridViewTextBoxColumn4.Name = "dataGridViewTextBoxColumn4";
			this.dataGridViewTextBoxColumn4.ReadOnly = true;
			// 
			// btn_HesabiKapat
			// 
			this.btn_HesabiKapat.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
			this.btn_HesabiKapat.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(196)))), ((int)(((byte)(78)))));
			this.btn_HesabiKapat.FlatAppearance.BorderSize = 0;
			this.btn_HesabiKapat.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
			this.btn_HesabiKapat.Font = new System.Drawing.Font("Century Gothic", 10.125F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
			this.btn_HesabiKapat.ForeColor = System.Drawing.Color.White;
			this.btn_HesabiKapat.Location = new System.Drawing.Point(9, 2);
			this.btn_HesabiKapat.Margin = new System.Windows.Forms.Padding(2);
			this.btn_HesabiKapat.Name = "btn_HesabiKapat";
			this.btn_HesabiKapat.Size = new System.Drawing.Size(566, 31);
			this.btn_HesabiKapat.TabIndex = 1;
			this.btn_HesabiKapat.Text = "Hesabı Kapat";
			this.btn_HesabiKapat.UseVisualStyleBackColor = false;
			this.btn_HesabiKapat.Click += new System.EventHandler(this.btn_HesabiKapat_Click);
			// 
			// dgw_Siparisler
			// 
			this.dgw_Siparisler.AllowUserToAddRows = false;
			this.dgw_Siparisler.AllowUserToDeleteRows = false;
			this.dgw_Siparisler.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
			this.dgw_Siparisler.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
			this.dgw_Siparisler.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.id,
            this.ad,
            this.adet,
            this.adetFiyat,
            this.toplamFiyat});
			this.dgw_Siparisler.Dock = System.Windows.Forms.DockStyle.Fill;
			this.dgw_Siparisler.Location = new System.Drawing.Point(0, 0);
			this.dgw_Siparisler.Margin = new System.Windows.Forms.Padding(2);
			this.dgw_Siparisler.Name = "dgw_Siparisler";
			this.dgw_Siparisler.ReadOnly = true;
			this.dgw_Siparisler.RowHeadersVisible = false;
			this.dgw_Siparisler.RowHeadersWidth = 82;
			this.dgw_Siparisler.RowTemplate.Height = 33;
			this.dgw_Siparisler.Size = new System.Drawing.Size(583, 336);
			this.dgw_Siparisler.TabIndex = 3;
			this.dgw_Siparisler.CellClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dgw_Siparisler_CellClick_1);
			this.dgw_Siparisler.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dgw_Siparisler_CellContentClick);
			// 
			// id
			// 
			this.id.FillWeight = 30F;
			this.id.HeaderText = "Sipariş ID";
			this.id.Name = "id";
			this.id.ReadOnly = true;
			// 
			// ad
			// 
			this.ad.FillWeight = 83.9467F;
			this.ad.HeaderText = "Ürün Adı";
			this.ad.Name = "ad";
			this.ad.ReadOnly = true;
			// 
			// adet
			// 
			this.adet.FillWeight = 83.9467F;
			this.adet.HeaderText = "Ürün Adedi";
			this.adet.Name = "adet";
			this.adet.ReadOnly = true;
			// 
			// adetFiyat
			// 
			this.adetFiyat.FillWeight = 83.9467F;
			this.adetFiyat.HeaderText = "Adet Fiyatı";
			this.adetFiyat.Name = "adetFiyat";
			this.adetFiyat.ReadOnly = true;
			// 
			// toplamFiyat
			// 
			this.toplamFiyat.FillWeight = 83.9467F;
			this.toplamFiyat.HeaderText = "Toplam Fiyat";
			this.toplamFiyat.Name = "toplamFiyat";
			this.toplamFiyat.ReadOnly = true;
			// 
			// HesapAl
			// 
			this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
			this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
			this.ClientSize = new System.Drawing.Size(1163, 471);
			this.Controls.Add(this.pnl_Urunler);
			this.Controls.Add(this.panel3);
			this.Controls.Add(this.panel1);
			this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
			this.Name = "HesapAl";
			this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
			this.Text = "HesapAl";
			this.Load += new System.EventHandler(this.HesapAl_Load);
			this.panel1.ResumeLayout(false);
			this.panel10.ResumeLayout(false);
			this.panel5.ResumeLayout(false);
			this.panel4.ResumeLayout(false);
			this.panel3.ResumeLayout(false);
			this.pnl_Urunler.ResumeLayout(false);
			this.pnl_Urun.ResumeLayout(false);
			this.pnl_Adisyon.ResumeLayout(false);
			this.panel6.ResumeLayout(false);
			this.panel7.ResumeLayout(false);
			this.panel11.ResumeLayout(false);
			this.panel11.PerformLayout();
			this.panel8.ResumeLayout(false);
			this.panel8.PerformLayout();
			this.panel9.ResumeLayout(false);
			this.panel12.ResumeLayout(false);
			this.panel12.PerformLayout();
			this.panel13.ResumeLayout(false);
			this.panel14.ResumeLayout(false);
			this.panel15.ResumeLayout(false);
			this.panel15.PerformLayout();
			this.panel17.ResumeLayout(false);
			this.panel16.ResumeLayout(false);
			((System.ComponentModel.ISupportInitialize)(this.dgw_GecmisOdemeler)).EndInit();
			((System.ComponentModel.ISupportInitialize)(this.dgw_Siparisler)).EndInit();
			this.ResumeLayout(false);

		}

		#endregion

		private System.Windows.Forms.Panel panel1;
		private System.Windows.Forms.Label lbl_Header;
		private System.Windows.Forms.Panel panel2;
		private System.Windows.Forms.Panel panel10;
		private System.Windows.Forms.Button btn_Exit;
		private System.Windows.Forms.Panel panel5;
		private System.Windows.Forms.Panel panel4;
		private System.Windows.Forms.Panel panel3;
		private System.Windows.Forms.Panel pnl_Urunler;
		private System.Windows.Forms.Panel pnl_Urun;
		private System.Windows.Forms.Panel pnl_Adisyon;
		private System.Windows.Forms.Panel panel6;
		private System.Windows.Forms.Panel panel7;
		private System.Windows.Forms.Label lbl_ToplamTutar;
		private System.Windows.Forms.Label label1;
		private System.Windows.Forms.Button btn_FisYazdir;
		private System.Windows.Forms.Panel panel9;
		private System.Windows.Forms.Panel panel12;
		private System.Windows.Forms.TextBox txb_AlinacakOdeme;
		private System.Windows.Forms.Label label4;
		private System.Windows.Forms.Label label3;
		private System.Windows.Forms.Panel panel8;
		private System.Windows.Forms.TextBox txb_KalanTutar;
		private System.Windows.Forms.Label label2;
		private System.Windows.Forms.Panel panel11;
		private System.Windows.Forms.TextBox txb_MasaNo;
		private System.Windows.Forms.Label label5;
		private System.Windows.Forms.Button btn_HesaptanDus;
		private System.Windows.Forms.Panel panel13;
		private System.Windows.Forms.Panel panel14;
		private System.Windows.Forms.Panel panel16;
		private System.Windows.Forms.DataGridView dgw_GecmisOdemeler;
		private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn1;
		private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn2;
		private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn3;
		private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn4;
		private System.Windows.Forms.Panel panel17;
		private System.Windows.Forms.Button btn_HesabiKapat;
		private System.Windows.Forms.Panel panel15;
		private System.Windows.Forms.Label label7;
		private System.Windows.Forms.DataGridView dgw_Siparisler;
		private System.Windows.Forms.DataGridViewTextBoxColumn id;
		private System.Windows.Forms.DataGridViewTextBoxColumn ad;
		private System.Windows.Forms.DataGridViewTextBoxColumn adet;
		private System.Windows.Forms.DataGridViewTextBoxColumn adetFiyat;
		private System.Windows.Forms.DataGridViewTextBoxColumn toplamFiyat;
	}
}