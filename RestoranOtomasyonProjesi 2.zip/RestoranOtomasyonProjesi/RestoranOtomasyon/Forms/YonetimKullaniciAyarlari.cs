﻿using RestoranOtomasyon.Components;
using RestoranOtomasyon.Functions;
using RestoranOtomasyon.Objects;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations.Schema;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace RestoranOtomasyon.Forms
{
    public partial class YonetimKullaniciAyarlari : Form
    {
        // GLOBAL VARIABLES
        List<YonetimKullanici> yonetimKullaniciEkranlari = new List<YonetimKullanici>();

        // CONSTRUCTOR AND LOAD EVENT
        public YonetimKullaniciAyarlari()
        {
            InitializeComponent();
        }

        private void YonetimKullaniciAyarlari_Load(object sender, EventArgs e)
        {
            loadKullanicilar();
            loadYetkiler();
        }


		// FUNCS
		public void locate()
		{
			int totalHeight = this.Height;
			pnl_KullaniciDuzenleme.Height = totalHeight / 2;
			pnl_YetkiDuzenleme.Height = totalHeight / 2;
		}
		public void loadKullanicilar() {
            pnl_Kullanicilar.Controls.Clear();
            Database database = new Database();
            List<KullaniciObject> kullanicilar = database.listKullanicilar();
            foreach (var kullanici in kullanicilar)
            {
                YonetimKullanici yonetimKullanici = new YonetimKullanici(kullanici.Id,kullanici.KullaniciAdi,kullanici.KullaniciTelefonNumarasi,kullanici.KullaniciAdresi,kullanici.KullaniciIban,kullanici.KullaniciMaasi,kullanici.YetkiId,this)
                {
                    Dock = DockStyle.Top,
                    BorderStyle = BorderStyle.FixedSingle,
                };
                pnl_Kullanicilar.Controls.Add(yonetimKullanici);
                yonetimKullaniciEkranlari.Add(yonetimKullanici);
                Panel marginPanel = new Panel()
                {
                    Height = 5,
                    Dock = DockStyle.Top,
                    BackColor = Color.FromArgb(39, 39, 39),
                };
                pnl_Kullanicilar.Controls.Add(marginPanel);

            }
        
        }

        public void loadYetkiler()
        {
            pnl_Yetkiler.Controls.Clear();
            Database database = new Database();
            List<YetkiObject> yetkiler = database.listYetkiler();
            foreach (var yetki in yetkiler)
            {
                YonetimYetki yonetimYetki = new YonetimYetki(yetki.Id,yetki.YetkiAdi,this)
                {
                    Dock = DockStyle.Top,
                    BorderStyle = BorderStyle.FixedSingle,
                };
                pnl_Yetkiler.Controls.Add(yonetimYetki);
                Panel marginPanel = new Panel()
                {
                    Height = 5,
                    Dock = DockStyle.Top,
                    BackColor = Color.FromArgb(39, 39, 39),
                };
                pnl_Yetkiler.Controls.Add(marginPanel);

            }
        }
        public void focusKullaniciId(int id)
        {
            foreach (var kullaniciEkrani in yonetimKullaniciEkranlari)
            {
                if (kullaniciEkrani.id != id)
                {
                    kullaniciEkrani.hideDetails();
                }
                else
                {
                    kullaniciEkrani.showDetails();
                }
            }
        }
        
        private void button2_Click(object sender2, EventArgs e)
        {
            YeniKullaniciEkleForm yeniKullaniciEkleForm = new YeniKullaniciEkleForm();
            yeniKullaniciEkleForm.FormClosing += (sender, args) =>
            {
                loadKullanicilar();
            };
            yeniKullaniciEkleForm.ShowDialog();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            YonetimYetkileriDuzenlemeForm yetkileriDuzenlemeForm = new YonetimYetkileriDuzenlemeForm();
            yetkileriDuzenlemeForm.Show();
        }

		private void YonetimKullaniciAyarlari_SizeChanged(object sender, EventArgs e)
		{
            locate();
		}
	}
}
