﻿namespace RestoranOtomasyon.Forms
{
    partial class YeniKullaniciEkleForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
			this.panel1 = new System.Windows.Forms.Panel();
			this.lbl_Header = new System.Windows.Forms.Label();
			this.panel2 = new System.Windows.Forms.Panel();
			this.panel10 = new System.Windows.Forms.Panel();
			this.btn_Exit = new System.Windows.Forms.Button();
			this.panel3 = new System.Windows.Forms.Panel();
			this.panel9 = new System.Windows.Forms.Panel();
			this.btn_Ekle = new System.Windows.Forms.Button();
			this.btn_Iptal = new System.Windows.Forms.Button();
			this.panel8 = new System.Windows.Forms.Panel();
			this.cbx_Yetkisi = new System.Windows.Forms.ComboBox();
			this.label6 = new System.Windows.Forms.Label();
			this.panel7 = new System.Windows.Forms.Panel();
			this.txb_Maas = new System.Windows.Forms.TextBox();
			this.label4 = new System.Windows.Forms.Label();
			this.panel6 = new System.Windows.Forms.Panel();
			this.txb_Iban = new System.Windows.Forms.TextBox();
			this.label3 = new System.Windows.Forms.Label();
			this.panel5 = new System.Windows.Forms.Panel();
			this.txb_KullaniciAdresi = new System.Windows.Forms.TextBox();
			this.label2 = new System.Windows.Forms.Label();
			this.panel4 = new System.Windows.Forms.Panel();
			this.txb_TelefonNumarası = new System.Windows.Forms.TextBox();
			this.label1 = new System.Windows.Forms.Label();
			this.panel11 = new System.Windows.Forms.Panel();
			this.txb_AdSoyad = new System.Windows.Forms.TextBox();
			this.label5 = new System.Windows.Forms.Label();
			this.panel1.SuspendLayout();
			this.panel10.SuspendLayout();
			this.panel3.SuspendLayout();
			this.panel9.SuspendLayout();
			this.panel8.SuspendLayout();
			this.panel7.SuspendLayout();
			this.panel6.SuspendLayout();
			this.panel5.SuspendLayout();
			this.panel4.SuspendLayout();
			this.panel11.SuspendLayout();
			this.SuspendLayout();
			// 
			// panel1
			// 
			this.panel1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(24)))), ((int)(((byte)(24)))), ((int)(((byte)(24)))));
			this.panel1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
			this.panel1.Controls.Add(this.lbl_Header);
			this.panel1.Controls.Add(this.panel2);
			this.panel1.Controls.Add(this.panel10);
			this.panel1.Dock = System.Windows.Forms.DockStyle.Top;
			this.panel1.Location = new System.Drawing.Point(0, 0);
			this.panel1.Name = "panel1";
			this.panel1.Size = new System.Drawing.Size(539, 50);
			this.panel1.TabIndex = 2;
			// 
			// lbl_Header
			// 
			this.lbl_Header.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(29)))), ((int)(((byte)(29)))), ((int)(((byte)(29)))));
			this.lbl_Header.Dock = System.Windows.Forms.DockStyle.Fill;
			this.lbl_Header.Font = new System.Drawing.Font("Century Gothic", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
			this.lbl_Header.ForeColor = System.Drawing.Color.White;
			this.lbl_Header.Location = new System.Drawing.Point(36, 0);
			this.lbl_Header.Name = "lbl_Header";
			this.lbl_Header.Size = new System.Drawing.Size(465, 48);
			this.lbl_Header.TabIndex = 5;
			this.lbl_Header.Text = "Yeni Kullanıcı Ekle";
			this.lbl_Header.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
			// 
			// panel2
			// 
			this.panel2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(29)))), ((int)(((byte)(29)))), ((int)(((byte)(29)))));
			this.panel2.Dock = System.Windows.Forms.DockStyle.Left;
			this.panel2.Location = new System.Drawing.Point(0, 0);
			this.panel2.Name = "panel2";
			this.panel2.Size = new System.Drawing.Size(36, 48);
			this.panel2.TabIndex = 4;
			// 
			// panel10
			// 
			this.panel10.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(29)))), ((int)(((byte)(29)))), ((int)(((byte)(29)))));
			this.panel10.Controls.Add(this.btn_Exit);
			this.panel10.Dock = System.Windows.Forms.DockStyle.Right;
			this.panel10.Location = new System.Drawing.Point(501, 0);
			this.panel10.Name = "panel10";
			this.panel10.Size = new System.Drawing.Size(36, 48);
			this.panel10.TabIndex = 3;
			// 
			// btn_Exit
			// 
			this.btn_Exit.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(24)))), ((int)(((byte)(24)))), ((int)(((byte)(24)))));
			this.btn_Exit.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
			this.btn_Exit.Font = new System.Drawing.Font("Century Gothic", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
			this.btn_Exit.ForeColor = System.Drawing.Color.Red;
			this.btn_Exit.Location = new System.Drawing.Point(4, 9);
			this.btn_Exit.Name = "btn_Exit";
			this.btn_Exit.Size = new System.Drawing.Size(29, 31);
			this.btn_Exit.TabIndex = 1;
			this.btn_Exit.Text = "x";
			this.btn_Exit.UseVisualStyleBackColor = false;
			this.btn_Exit.Click += new System.EventHandler(this.btn_Exit_Click);
			// 
			// panel3
			// 
			this.panel3.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(29)))), ((int)(((byte)(29)))), ((int)(((byte)(29)))));
			this.panel3.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
			this.panel3.Controls.Add(this.panel9);
			this.panel3.Controls.Add(this.panel8);
			this.panel3.Controls.Add(this.panel7);
			this.panel3.Controls.Add(this.panel6);
			this.panel3.Controls.Add(this.panel5);
			this.panel3.Controls.Add(this.panel4);
			this.panel3.Controls.Add(this.panel11);
			this.panel3.Location = new System.Drawing.Point(12, 56);
			this.panel3.Name = "panel3";
			this.panel3.Size = new System.Drawing.Size(515, 242);
			this.panel3.TabIndex = 3;
			// 
			// panel9
			// 
			this.panel9.Controls.Add(this.btn_Ekle);
			this.panel9.Controls.Add(this.btn_Iptal);
			this.panel9.Dock = System.Windows.Forms.DockStyle.Top;
			this.panel9.Location = new System.Drawing.Point(0, 198);
			this.panel9.Name = "panel9";
			this.panel9.Size = new System.Drawing.Size(513, 39);
			this.panel9.TabIndex = 13;
			// 
			// btn_Ekle
			// 
			this.btn_Ekle.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
			this.btn_Ekle.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(2)))), ((int)(((byte)(117)))), ((int)(((byte)(252)))));
			this.btn_Ekle.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(89)))), ((int)(((byte)(89)))), ((int)(((byte)(89)))));
			this.btn_Ekle.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
			this.btn_Ekle.Font = new System.Drawing.Font("Century Gothic", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
			this.btn_Ekle.ForeColor = System.Drawing.Color.White;
			this.btn_Ekle.Location = new System.Drawing.Point(153, 4);
			this.btn_Ekle.Name = "btn_Ekle";
			this.btn_Ekle.Size = new System.Drawing.Size(164, 30);
			this.btn_Ekle.TabIndex = 13;
			this.btn_Ekle.Text = "Ekle";
			this.btn_Ekle.UseVisualStyleBackColor = false;
			this.btn_Ekle.Click += new System.EventHandler(this.btn_Ekle_ClickAsync);
			// 
			// btn_Iptal
			// 
			this.btn_Iptal.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
			this.btn_Iptal.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(2)))), ((int)(((byte)(2)))));
			this.btn_Iptal.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(89)))), ((int)(((byte)(89)))), ((int)(((byte)(89)))));
			this.btn_Iptal.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
			this.btn_Iptal.Font = new System.Drawing.Font("Century Gothic", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
			this.btn_Iptal.ForeColor = System.Drawing.Color.White;
			this.btn_Iptal.Location = new System.Drawing.Point(325, 4);
			this.btn_Iptal.Name = "btn_Iptal";
			this.btn_Iptal.Size = new System.Drawing.Size(164, 30);
			this.btn_Iptal.TabIndex = 12;
			this.btn_Iptal.Text = "İptal";
			this.btn_Iptal.UseVisualStyleBackColor = false;
			this.btn_Iptal.Click += new System.EventHandler(this.btn_Iptal_Click);
			// 
			// panel8
			// 
			this.panel8.Controls.Add(this.cbx_Yetkisi);
			this.panel8.Controls.Add(this.label6);
			this.panel8.Dock = System.Windows.Forms.DockStyle.Top;
			this.panel8.Location = new System.Drawing.Point(0, 165);
			this.panel8.Name = "panel8";
			this.panel8.Size = new System.Drawing.Size(513, 33);
			this.panel8.TabIndex = 11;
			// 
			// cbx_Yetkisi
			// 
			this.cbx_Yetkisi.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
			this.cbx_Yetkisi.Font = new System.Drawing.Font("Century Gothic", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
			this.cbx_Yetkisi.FormattingEnabled = true;
			this.cbx_Yetkisi.Location = new System.Drawing.Point(153, 4);
			this.cbx_Yetkisi.Name = "cbx_Yetkisi";
			this.cbx_Yetkisi.Size = new System.Drawing.Size(336, 25);
			this.cbx_Yetkisi.TabIndex = 2;
			// 
			// label6
			// 
			this.label6.AutoSize = true;
			this.label6.Font = new System.Drawing.Font("Century Gothic", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
			this.label6.ForeColor = System.Drawing.Color.White;
			this.label6.Location = new System.Drawing.Point(22, 9);
			this.label6.Name = "label6";
			this.label6.Size = new System.Drawing.Size(43, 16);
			this.label6.TabIndex = 1;
			this.label6.Text = "Yetkisi";
			// 
			// panel7
			// 
			this.panel7.Controls.Add(this.txb_Maas);
			this.panel7.Controls.Add(this.label4);
			this.panel7.Dock = System.Windows.Forms.DockStyle.Top;
			this.panel7.Location = new System.Drawing.Point(0, 132);
			this.panel7.Name = "panel7";
			this.panel7.Size = new System.Drawing.Size(513, 33);
			this.panel7.TabIndex = 10;
			// 
			// txb_Maas
			// 
			this.txb_Maas.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
			this.txb_Maas.Font = new System.Drawing.Font("Century Gothic", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
			this.txb_Maas.Location = new System.Drawing.Point(153, 6);
			this.txb_Maas.Name = "txb_Maas";
			this.txb_Maas.Size = new System.Drawing.Size(336, 22);
			this.txb_Maas.TabIndex = 2;
			this.txb_Maas.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txb_Maas_KeyPress);
			// 
			// label4
			// 
			this.label4.AutoSize = true;
			this.label4.Font = new System.Drawing.Font("Century Gothic", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
			this.label4.ForeColor = System.Drawing.Color.White;
			this.label4.Location = new System.Drawing.Point(22, 9);
			this.label4.Name = "label4";
			this.label4.Size = new System.Drawing.Size(39, 16);
			this.label4.TabIndex = 1;
			this.label4.Text = "Maaş";
			// 
			// panel6
			// 
			this.panel6.Controls.Add(this.txb_Iban);
			this.panel6.Controls.Add(this.label3);
			this.panel6.Dock = System.Windows.Forms.DockStyle.Top;
			this.panel6.Location = new System.Drawing.Point(0, 99);
			this.panel6.Name = "panel6";
			this.panel6.Size = new System.Drawing.Size(513, 33);
			this.panel6.TabIndex = 9;
			// 
			// txb_Iban
			// 
			this.txb_Iban.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
			this.txb_Iban.Font = new System.Drawing.Font("Century Gothic", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
			this.txb_Iban.Location = new System.Drawing.Point(153, 6);
			this.txb_Iban.Name = "txb_Iban";
			this.txb_Iban.Size = new System.Drawing.Size(336, 22);
			this.txb_Iban.TabIndex = 2;
			// 
			// label3
			// 
			this.label3.AutoSize = true;
			this.label3.Font = new System.Drawing.Font("Century Gothic", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
			this.label3.ForeColor = System.Drawing.Color.White;
			this.label3.Location = new System.Drawing.Point(22, 9);
			this.label3.Name = "label3";
			this.label3.Size = new System.Drawing.Size(36, 16);
			this.label3.TabIndex = 1;
			this.label3.Text = "IBAN";
			// 
			// panel5
			// 
			this.panel5.Controls.Add(this.txb_KullaniciAdresi);
			this.panel5.Controls.Add(this.label2);
			this.panel5.Dock = System.Windows.Forms.DockStyle.Top;
			this.panel5.Location = new System.Drawing.Point(0, 66);
			this.panel5.Name = "panel5";
			this.panel5.Size = new System.Drawing.Size(513, 33);
			this.panel5.TabIndex = 8;
			// 
			// txb_KullaniciAdresi
			// 
			this.txb_KullaniciAdresi.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
			this.txb_KullaniciAdresi.Font = new System.Drawing.Font("Century Gothic", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
			this.txb_KullaniciAdresi.Location = new System.Drawing.Point(153, 6);
			this.txb_KullaniciAdresi.Name = "txb_KullaniciAdresi";
			this.txb_KullaniciAdresi.Size = new System.Drawing.Size(336, 22);
			this.txb_KullaniciAdresi.TabIndex = 2;
			// 
			// label2
			// 
			this.label2.AutoSize = true;
			this.label2.Font = new System.Drawing.Font("Century Gothic", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
			this.label2.ForeColor = System.Drawing.Color.White;
			this.label2.Location = new System.Drawing.Point(22, 9);
			this.label2.Name = "label2";
			this.label2.Size = new System.Drawing.Size(96, 16);
			this.label2.TabIndex = 1;
			this.label2.Text = "Kullanıcı Adresi";
			// 
			// panel4
			// 
			this.panel4.Controls.Add(this.txb_TelefonNumarası);
			this.panel4.Controls.Add(this.label1);
			this.panel4.Dock = System.Windows.Forms.DockStyle.Top;
			this.panel4.Location = new System.Drawing.Point(0, 33);
			this.panel4.Name = "panel4";
			this.panel4.Size = new System.Drawing.Size(513, 33);
			this.panel4.TabIndex = 7;
			// 
			// txb_TelefonNumarası
			// 
			this.txb_TelefonNumarası.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
			this.txb_TelefonNumarası.Font = new System.Drawing.Font("Century Gothic", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
			this.txb_TelefonNumarası.Location = new System.Drawing.Point(153, 6);
			this.txb_TelefonNumarası.Name = "txb_TelefonNumarası";
			this.txb_TelefonNumarası.Size = new System.Drawing.Size(336, 22);
			this.txb_TelefonNumarası.TabIndex = 2;
			this.txb_TelefonNumarası.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txb_TelefonNumarası_KeyPress);
			// 
			// label1
			// 
			this.label1.AutoSize = true;
			this.label1.Font = new System.Drawing.Font("Century Gothic", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
			this.label1.ForeColor = System.Drawing.Color.White;
			this.label1.Location = new System.Drawing.Point(22, 9);
			this.label1.Name = "label1";
			this.label1.Size = new System.Drawing.Size(108, 16);
			this.label1.TabIndex = 1;
			this.label1.Text = "Telefon Numarası";
			// 
			// panel11
			// 
			this.panel11.Controls.Add(this.txb_AdSoyad);
			this.panel11.Controls.Add(this.label5);
			this.panel11.Dock = System.Windows.Forms.DockStyle.Top;
			this.panel11.Location = new System.Drawing.Point(0, 0);
			this.panel11.Name = "panel11";
			this.panel11.Size = new System.Drawing.Size(513, 33);
			this.panel11.TabIndex = 6;
			// 
			// txb_AdSoyad
			// 
			this.txb_AdSoyad.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
			this.txb_AdSoyad.Font = new System.Drawing.Font("Century Gothic", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
			this.txb_AdSoyad.Location = new System.Drawing.Point(153, 6);
			this.txb_AdSoyad.Name = "txb_AdSoyad";
			this.txb_AdSoyad.Size = new System.Drawing.Size(336, 22);
			this.txb_AdSoyad.TabIndex = 2;
			// 
			// label5
			// 
			this.label5.AutoSize = true;
			this.label5.Font = new System.Drawing.Font("Century Gothic", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
			this.label5.ForeColor = System.Drawing.Color.White;
			this.label5.Location = new System.Drawing.Point(22, 9);
			this.label5.Name = "label5";
			this.label5.Size = new System.Drawing.Size(76, 16);
			this.label5.TabIndex = 1;
			this.label5.Text = "İsim Soyisim";
			// 
			// YeniKullaniciEkleForm
			// 
			this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
			this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
			this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(39)))), ((int)(((byte)(39)))), ((int)(((byte)(39)))));
			this.ClientSize = new System.Drawing.Size(539, 310);
			this.Controls.Add(this.panel3);
			this.Controls.Add(this.panel1);
			this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
			this.Name = "YeniKullaniciEkleForm";
			this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
			this.Text = "YeniKullaniciEkleForm";
			this.Load += new System.EventHandler(this.YeniKullaniciEkleForm_Load);
			this.panel1.ResumeLayout(false);
			this.panel10.ResumeLayout(false);
			this.panel3.ResumeLayout(false);
			this.panel9.ResumeLayout(false);
			this.panel8.ResumeLayout(false);
			this.panel8.PerformLayout();
			this.panel7.ResumeLayout(false);
			this.panel7.PerformLayout();
			this.panel6.ResumeLayout(false);
			this.panel6.PerformLayout();
			this.panel5.ResumeLayout(false);
			this.panel5.PerformLayout();
			this.panel4.ResumeLayout(false);
			this.panel4.PerformLayout();
			this.panel11.ResumeLayout(false);
			this.panel11.PerformLayout();
			this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Label lbl_Header;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.Panel panel10;
        private System.Windows.Forms.Button btn_Exit;
        private System.Windows.Forms.Panel panel3;
        private System.Windows.Forms.Panel panel8;
        private System.Windows.Forms.ComboBox cbx_Yetkisi;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Panel panel7;
        private System.Windows.Forms.TextBox txb_Maas;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Panel panel6;
        private System.Windows.Forms.TextBox txb_Iban;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Panel panel5;
        private System.Windows.Forms.TextBox txb_KullaniciAdresi;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Panel panel4;
        private System.Windows.Forms.TextBox txb_TelefonNumarası;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Panel panel11;
        private System.Windows.Forms.TextBox txb_AdSoyad;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Panel panel9;
        private System.Windows.Forms.Button btn_Ekle;
        private System.Windows.Forms.Button btn_Iptal;
    }
}