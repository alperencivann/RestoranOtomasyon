﻿namespace RestoranOtomasyon.Forms
{
	partial class YeniUrunEklemeDuzenlemeForm
	{
		/// <summary>
		/// Required designer variable.
		/// </summary>
		private System.ComponentModel.IContainer components = null;

		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		/// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
		protected override void Dispose(bool disposing)
		{
			if (disposing && (components != null))
			{
				components.Dispose();
			}
			base.Dispose(disposing);
		}

		#region Windows Form Designer generated code

		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			this.panel1 = new System.Windows.Forms.Panel();
			this.lbl_Header = new System.Windows.Forms.Label();
			this.panel2 = new System.Windows.Forms.Panel();
			this.panel10 = new System.Windows.Forms.Panel();
			this.btn_Exit = new System.Windows.Forms.Button();
			this.btn_Sil = new System.Windows.Forms.Button();
			this.btn_Guncelle = new System.Windows.Forms.Button();
			this.pnl_Buttons = new System.Windows.Forms.Panel();
			this.panel6 = new System.Windows.Forms.Panel();
			this.panel3 = new System.Windows.Forms.Panel();
			this.pnl_YetkiTipi = new System.Windows.Forms.Panel();
			this.panel7 = new System.Windows.Forms.Panel();
			this.btn_YeniKategoriEkle = new System.Windows.Forms.Button();
			this.cbx_Kategori = new System.Windows.Forms.ComboBox();
			this.label6 = new System.Windows.Forms.Label();
			this.pnl_TelefonNumarasi = new System.Windows.Forms.Panel();
			this.txb_SatisFiyati = new System.Windows.Forms.TextBox();
			this.label1 = new System.Windows.Forms.Label();
			this.pnl_KullaniciAdi = new System.Windows.Forms.Panel();
			this.txb_UrunAdi = new System.Windows.Forms.TextBox();
			this.label5 = new System.Windows.Forms.Label();
			this.panel4 = new System.Windows.Forms.Panel();
			this.pcb_Image = new System.Windows.Forms.PictureBox();
			this.btn_UrunResmiSec = new System.Windows.Forms.Button();
			this.openFileDialog1 = new System.Windows.Forms.OpenFileDialog();
			this.panel1.SuspendLayout();
			this.panel10.SuspendLayout();
			this.pnl_Buttons.SuspendLayout();
			this.panel6.SuspendLayout();
			this.panel3.SuspendLayout();
			this.pnl_YetkiTipi.SuspendLayout();
			this.panel7.SuspendLayout();
			this.pnl_TelefonNumarasi.SuspendLayout();
			this.pnl_KullaniciAdi.SuspendLayout();
			this.panel4.SuspendLayout();
			((System.ComponentModel.ISupportInitialize)(this.pcb_Image)).BeginInit();
			this.SuspendLayout();
			// 
			// panel1
			// 
			this.panel1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(24)))), ((int)(((byte)(24)))), ((int)(((byte)(24)))));
			this.panel1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
			this.panel1.Controls.Add(this.lbl_Header);
			this.panel1.Controls.Add(this.panel2);
			this.panel1.Controls.Add(this.panel10);
			this.panel1.Dock = System.Windows.Forms.DockStyle.Top;
			this.panel1.Location = new System.Drawing.Point(0, 0);
			this.panel1.Name = "panel1";
			this.panel1.Size = new System.Drawing.Size(807, 50);
			this.panel1.TabIndex = 4;
			// 
			// lbl_Header
			// 
			this.lbl_Header.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(29)))), ((int)(((byte)(29)))), ((int)(((byte)(29)))));
			this.lbl_Header.Dock = System.Windows.Forms.DockStyle.Fill;
			this.lbl_Header.Font = new System.Drawing.Font("Century Gothic", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
			this.lbl_Header.ForeColor = System.Drawing.Color.White;
			this.lbl_Header.Location = new System.Drawing.Point(36, 0);
			this.lbl_Header.Name = "lbl_Header";
			this.lbl_Header.Size = new System.Drawing.Size(733, 48);
			this.lbl_Header.TabIndex = 5;
			this.lbl_Header.Text = "Ürün Düzenleme / Ekleme Ekranı";
			this.lbl_Header.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
			// 
			// panel2
			// 
			this.panel2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(29)))), ((int)(((byte)(29)))), ((int)(((byte)(29)))));
			this.panel2.Dock = System.Windows.Forms.DockStyle.Left;
			this.panel2.Location = new System.Drawing.Point(0, 0);
			this.panel2.Name = "panel2";
			this.panel2.Size = new System.Drawing.Size(36, 48);
			this.panel2.TabIndex = 4;
			// 
			// panel10
			// 
			this.panel10.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(29)))), ((int)(((byte)(29)))), ((int)(((byte)(29)))));
			this.panel10.Controls.Add(this.btn_Exit);
			this.panel10.Dock = System.Windows.Forms.DockStyle.Right;
			this.panel10.Location = new System.Drawing.Point(769, 0);
			this.panel10.Name = "panel10";
			this.panel10.Size = new System.Drawing.Size(36, 48);
			this.panel10.TabIndex = 3;
			// 
			// btn_Exit
			// 
			this.btn_Exit.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(24)))), ((int)(((byte)(24)))), ((int)(((byte)(24)))));
			this.btn_Exit.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
			this.btn_Exit.Font = new System.Drawing.Font("Century Gothic", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
			this.btn_Exit.ForeColor = System.Drawing.Color.Red;
			this.btn_Exit.Location = new System.Drawing.Point(4, 9);
			this.btn_Exit.Name = "btn_Exit";
			this.btn_Exit.Size = new System.Drawing.Size(29, 31);
			this.btn_Exit.TabIndex = 1;
			this.btn_Exit.Text = "x";
			this.btn_Exit.UseVisualStyleBackColor = false;
			this.btn_Exit.Click += new System.EventHandler(this.btn_Exit_Click);
			// 
			// btn_Sil
			// 
			this.btn_Sil.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(252)))), ((int)(((byte)(2)))), ((int)(((byte)(2)))));
			this.btn_Sil.FlatAppearance.BorderSize = 0;
			this.btn_Sil.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
			this.btn_Sil.Font = new System.Drawing.Font("Century Gothic", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
			this.btn_Sil.ForeColor = System.Drawing.Color.White;
			this.btn_Sil.Location = new System.Drawing.Point(409, 7);
			this.btn_Sil.Name = "btn_Sil";
			this.btn_Sil.Size = new System.Drawing.Size(363, 25);
			this.btn_Sil.TabIndex = 13;
			this.btn_Sil.Text = "Ürünü Sil";
			this.btn_Sil.UseVisualStyleBackColor = false;
			this.btn_Sil.Click += new System.EventHandler(this.btn_Sil_Click);
			// 
			// btn_Guncelle
			// 
			this.btn_Guncelle.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(2)))), ((int)(((byte)(117)))), ((int)(((byte)(252)))));
			this.btn_Guncelle.FlatAppearance.BorderSize = 0;
			this.btn_Guncelle.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
			this.btn_Guncelle.Font = new System.Drawing.Font("Century Gothic", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
			this.btn_Guncelle.ForeColor = System.Drawing.Color.White;
			this.btn_Guncelle.Location = new System.Drawing.Point(24, 7);
			this.btn_Guncelle.Name = "btn_Guncelle";
			this.btn_Guncelle.Size = new System.Drawing.Size(363, 25);
			this.btn_Guncelle.TabIndex = 12;
			this.btn_Guncelle.Text = "Ürünü Güncelle";
			this.btn_Guncelle.UseVisualStyleBackColor = false;
			this.btn_Guncelle.Click += new System.EventHandler(this.btn_Guncelle_Click);
			// 
			// pnl_Buttons
			// 
			this.pnl_Buttons.Controls.Add(this.btn_Sil);
			this.pnl_Buttons.Controls.Add(this.btn_Guncelle);
			this.pnl_Buttons.Dock = System.Windows.Forms.DockStyle.Bottom;
			this.pnl_Buttons.Location = new System.Drawing.Point(0, 148);
			this.pnl_Buttons.Name = "pnl_Buttons";
			this.pnl_Buttons.Size = new System.Drawing.Size(805, 39);
			this.pnl_Buttons.TabIndex = 17;
			// 
			// panel6
			// 
			this.panel6.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(29)))), ((int)(((byte)(29)))), ((int)(((byte)(29)))));
			this.panel6.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
			this.panel6.Controls.Add(this.panel3);
			this.panel6.Controls.Add(this.panel4);
			this.panel6.Controls.Add(this.pnl_Buttons);
			this.panel6.Dock = System.Windows.Forms.DockStyle.Fill;
			this.panel6.Location = new System.Drawing.Point(0, 50);
			this.panel6.Name = "panel6";
			this.panel6.Size = new System.Drawing.Size(807, 189);
			this.panel6.TabIndex = 5;
			// 
			// panel3
			// 
			this.panel3.Controls.Add(this.pnl_YetkiTipi);
			this.panel3.Controls.Add(this.pnl_TelefonNumarasi);
			this.panel3.Controls.Add(this.pnl_KullaniciAdi);
			this.panel3.Dock = System.Windows.Forms.DockStyle.Fill;
			this.panel3.Location = new System.Drawing.Point(211, 0);
			this.panel3.Name = "panel3";
			this.panel3.Size = new System.Drawing.Size(594, 148);
			this.panel3.TabIndex = 20;
			// 
			// pnl_YetkiTipi
			// 
			this.pnl_YetkiTipi.Controls.Add(this.panel7);
			this.pnl_YetkiTipi.Controls.Add(this.cbx_Kategori);
			this.pnl_YetkiTipi.Controls.Add(this.label6);
			this.pnl_YetkiTipi.Dock = System.Windows.Forms.DockStyle.Top;
			this.pnl_YetkiTipi.Location = new System.Drawing.Point(0, 66);
			this.pnl_YetkiTipi.Name = "pnl_YetkiTipi";
			this.pnl_YetkiTipi.Size = new System.Drawing.Size(594, 33);
			this.pnl_YetkiTipi.TabIndex = 14;
			// 
			// panel7
			// 
			this.panel7.Controls.Add(this.btn_YeniKategoriEkle);
			this.panel7.Dock = System.Windows.Forms.DockStyle.Right;
			this.panel7.Location = new System.Drawing.Point(386, 0);
			this.panel7.Name = "panel7";
			this.panel7.Size = new System.Drawing.Size(208, 33);
			this.panel7.TabIndex = 4;
			// 
			// btn_YeniKategoriEkle
			// 
			this.btn_YeniKategoriEkle.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(2)))), ((int)(((byte)(117)))), ((int)(((byte)(252)))));
			this.btn_YeniKategoriEkle.FlatAppearance.BorderSize = 0;
			this.btn_YeniKategoriEkle.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
			this.btn_YeniKategoriEkle.Font = new System.Drawing.Font("Century Gothic", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
			this.btn_YeniKategoriEkle.ForeColor = System.Drawing.Color.White;
			this.btn_YeniKategoriEkle.Location = new System.Drawing.Point(11, 4);
			this.btn_YeniKategoriEkle.Name = "btn_YeniKategoriEkle";
			this.btn_YeniKategoriEkle.Size = new System.Drawing.Size(164, 24);
			this.btn_YeniKategoriEkle.TabIndex = 5;
			this.btn_YeniKategoriEkle.Text = "Yeni Kategori Ekle";
			this.btn_YeniKategoriEkle.UseVisualStyleBackColor = false;
			this.btn_YeniKategoriEkle.Click += new System.EventHandler(this.btn_YeniKategoriEkle_Click);
			// 
			// cbx_Kategori
			// 
			this.cbx_Kategori.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
			this.cbx_Kategori.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
			this.cbx_Kategori.Font = new System.Drawing.Font("Century Gothic", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
			this.cbx_Kategori.FormattingEnabled = true;
			this.cbx_Kategori.Location = new System.Drawing.Point(153, 4);
			this.cbx_Kategori.Name = "cbx_Kategori";
			this.cbx_Kategori.Size = new System.Drawing.Size(227, 25);
			this.cbx_Kategori.TabIndex = 3;
			// 
			// label6
			// 
			this.label6.AutoSize = true;
			this.label6.Font = new System.Drawing.Font("Century Gothic", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
			this.label6.ForeColor = System.Drawing.Color.White;
			this.label6.Location = new System.Drawing.Point(21, 9);
			this.label6.Name = "label6";
			this.label6.Size = new System.Drawing.Size(59, 17);
			this.label6.TabIndex = 1;
			this.label6.Text = "Kategori";
			// 
			// pnl_TelefonNumarasi
			// 
			this.pnl_TelefonNumarasi.Controls.Add(this.txb_SatisFiyati);
			this.pnl_TelefonNumarasi.Controls.Add(this.label1);
			this.pnl_TelefonNumarasi.Dock = System.Windows.Forms.DockStyle.Top;
			this.pnl_TelefonNumarasi.Location = new System.Drawing.Point(0, 33);
			this.pnl_TelefonNumarasi.Name = "pnl_TelefonNumarasi";
			this.pnl_TelefonNumarasi.Size = new System.Drawing.Size(594, 33);
			this.pnl_TelefonNumarasi.TabIndex = 13;
			// 
			// txb_SatisFiyati
			// 
			this.txb_SatisFiyati.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
			this.txb_SatisFiyati.Font = new System.Drawing.Font("Century Gothic", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
			this.txb_SatisFiyati.Location = new System.Drawing.Point(153, 6);
			this.txb_SatisFiyati.Name = "txb_SatisFiyati";
			this.txb_SatisFiyati.Size = new System.Drawing.Size(408, 22);
			this.txb_SatisFiyati.TabIndex = 2;
			this.txb_SatisFiyati.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txb_SatisFiyati_KeyPress);
			// 
			// label1
			// 
			this.label1.AutoSize = true;
			this.label1.Font = new System.Drawing.Font("Century Gothic", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
			this.label1.ForeColor = System.Drawing.Color.White;
			this.label1.Location = new System.Drawing.Point(21, 9);
			this.label1.Name = "label1";
			this.label1.Size = new System.Drawing.Size(70, 17);
			this.label1.TabIndex = 1;
			this.label1.Text = "Satış Fiyatı";
			// 
			// pnl_KullaniciAdi
			// 
			this.pnl_KullaniciAdi.Controls.Add(this.txb_UrunAdi);
			this.pnl_KullaniciAdi.Controls.Add(this.label5);
			this.pnl_KullaniciAdi.Dock = System.Windows.Forms.DockStyle.Top;
			this.pnl_KullaniciAdi.Location = new System.Drawing.Point(0, 0);
			this.pnl_KullaniciAdi.Name = "pnl_KullaniciAdi";
			this.pnl_KullaniciAdi.Size = new System.Drawing.Size(594, 33);
			this.pnl_KullaniciAdi.TabIndex = 12;
			// 
			// txb_UrunAdi
			// 
			this.txb_UrunAdi.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
			this.txb_UrunAdi.Font = new System.Drawing.Font("Century Gothic", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
			this.txb_UrunAdi.Location = new System.Drawing.Point(153, 7);
			this.txb_UrunAdi.Name = "txb_UrunAdi";
			this.txb_UrunAdi.Size = new System.Drawing.Size(408, 22);
			this.txb_UrunAdi.TabIndex = 2;
			// 
			// label5
			// 
			this.label5.AutoSize = true;
			this.label5.Font = new System.Drawing.Font("Century Gothic", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
			this.label5.ForeColor = System.Drawing.Color.White;
			this.label5.Location = new System.Drawing.Point(21, 10);
			this.label5.Name = "label5";
			this.label5.Size = new System.Drawing.Size(57, 17);
			this.label5.TabIndex = 1;
			this.label5.Text = "Ürün Adı";
			// 
			// panel4
			// 
			this.panel4.Controls.Add(this.pcb_Image);
			this.panel4.Controls.Add(this.btn_UrunResmiSec);
			this.panel4.Dock = System.Windows.Forms.DockStyle.Left;
			this.panel4.Location = new System.Drawing.Point(0, 0);
			this.panel4.Name = "panel4";
			this.panel4.Size = new System.Drawing.Size(211, 148);
			this.panel4.TabIndex = 19;
			// 
			// pcb_Image
			// 
			this.pcb_Image.Location = new System.Drawing.Point(24, 9);
			this.pcb_Image.Name = "pcb_Image";
			this.pcb_Image.Size = new System.Drawing.Size(164, 103);
			this.pcb_Image.SizeMode = System.Windows.Forms.PictureBoxSizeMode.CenterImage;
			this.pcb_Image.TabIndex = 7;
			this.pcb_Image.TabStop = false;
			// 
			// btn_UrunResmiSec
			// 
			this.btn_UrunResmiSec.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(2)))), ((int)(((byte)(117)))), ((int)(((byte)(252)))));
			this.btn_UrunResmiSec.FlatAppearance.BorderSize = 0;
			this.btn_UrunResmiSec.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
			this.btn_UrunResmiSec.Font = new System.Drawing.Font("Century Gothic", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
			this.btn_UrunResmiSec.ForeColor = System.Drawing.Color.White;
			this.btn_UrunResmiSec.Location = new System.Drawing.Point(24, 118);
			this.btn_UrunResmiSec.Name = "btn_UrunResmiSec";
			this.btn_UrunResmiSec.Size = new System.Drawing.Size(164, 24);
			this.btn_UrunResmiSec.TabIndex = 6;
			this.btn_UrunResmiSec.Text = "Ürün Resmi Seç";
			this.btn_UrunResmiSec.UseVisualStyleBackColor = false;
			this.btn_UrunResmiSec.Click += new System.EventHandler(this.btn_UrunResmiSec_Click);
			// 
			// openFileDialog1
			// 
			this.openFileDialog1.FileName = "openFileDialog1";
			// 
			// YeniUrunEklemeDuzenlemeForm
			// 
			this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
			this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
			this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(39)))), ((int)(((byte)(39)))), ((int)(((byte)(39)))));
			this.ClientSize = new System.Drawing.Size(807, 239);
			this.Controls.Add(this.panel6);
			this.Controls.Add(this.panel1);
			this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
			this.Name = "YeniUrunEklemeDuzenlemeForm";
			this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
			this.Text = "YeniUrunEklemeDuzenlemeForm";
			this.Load += new System.EventHandler(this.YeniUrunEklemeDuzenlemeForm_Load);
			this.panel1.ResumeLayout(false);
			this.panel10.ResumeLayout(false);
			this.pnl_Buttons.ResumeLayout(false);
			this.panel6.ResumeLayout(false);
			this.panel3.ResumeLayout(false);
			this.pnl_YetkiTipi.ResumeLayout(false);
			this.pnl_YetkiTipi.PerformLayout();
			this.panel7.ResumeLayout(false);
			this.pnl_TelefonNumarasi.ResumeLayout(false);
			this.pnl_TelefonNumarasi.PerformLayout();
			this.pnl_KullaniciAdi.ResumeLayout(false);
			this.pnl_KullaniciAdi.PerformLayout();
			this.panel4.ResumeLayout(false);
			((System.ComponentModel.ISupportInitialize)(this.pcb_Image)).EndInit();
			this.ResumeLayout(false);

		}

		#endregion

		private System.Windows.Forms.Panel panel1;
		private System.Windows.Forms.Label lbl_Header;
		private System.Windows.Forms.Panel panel2;
		private System.Windows.Forms.Panel panel10;
		private System.Windows.Forms.Button btn_Exit;
		private System.Windows.Forms.Button btn_Sil;
		private System.Windows.Forms.Button btn_Guncelle;
		private System.Windows.Forms.Panel pnl_Buttons;
		private System.Windows.Forms.Panel panel6;
		private System.Windows.Forms.Panel panel3;
		private System.Windows.Forms.Panel pnl_YetkiTipi;
		private System.Windows.Forms.Panel panel7;
		private System.Windows.Forms.Button btn_YeniKategoriEkle;
		private System.Windows.Forms.ComboBox cbx_Kategori;
		private System.Windows.Forms.Label label6;
		private System.Windows.Forms.Panel pnl_TelefonNumarasi;
		private System.Windows.Forms.TextBox txb_SatisFiyati;
		private System.Windows.Forms.Label label1;
		private System.Windows.Forms.Panel pnl_KullaniciAdi;
		private System.Windows.Forms.TextBox txb_UrunAdi;
		private System.Windows.Forms.Label label5;
		private System.Windows.Forms.Panel panel4;
		private System.Windows.Forms.PictureBox pcb_Image;
		private System.Windows.Forms.Button btn_UrunResmiSec;
		private System.Windows.Forms.OpenFileDialog openFileDialog1;
	}
}