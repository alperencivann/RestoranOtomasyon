﻿namespace RestoranOtomasyon
{
    partial class Form1
    {
        /// <summary>
        ///Gerekli tasarımcı değişkeni.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///Kullanılan tüm kaynakları temizleyin.
        /// </summary>
        ///<param name="disposing">yönetilen kaynaklar dispose edilmeliyse doğru; aksi halde yanlış.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer üretilen kod

        /// <summary>
        /// Tasarımcı desteği için gerekli metot - bu metodun 
        ///içeriğini kod düzenleyici ile değiştirmeyin.
        /// </summary>
        private void InitializeComponent()
        {
			System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form1));
			this.panel2 = new System.Windows.Forms.Panel();
			this.lbl_Info = new System.Windows.Forms.Label();
			this.pnl_Islemler = new System.Windows.Forms.Panel();
			this.panel13 = new System.Windows.Forms.Panel();
			this.lbl_SorunMuYasiyorsun = new System.Windows.Forms.Label();
			this.lbl_GirisKayit = new System.Windows.Forms.Label();
			this.panel12 = new System.Windows.Forms.Panel();
			this.btn_GirisKayit = new System.Windows.Forms.Button();
			this.pnl_LisansKey = new System.Windows.Forms.Panel();
			this.panel11 = new System.Windows.Forms.Panel();
			this.txb_LisansKey = new System.Windows.Forms.TextBox();
			this.pnl_Sifre = new System.Windows.Forms.Panel();
			this.panel10 = new System.Windows.Forms.Panel();
			this.txb_Sifre = new System.Windows.Forms.TextBox();
			this.pnl_Email = new System.Windows.Forms.Panel();
			this.panel5 = new System.Windows.Forms.Panel();
			this.txb_Email = new System.Windows.Forms.TextBox();
			this.panel6 = new System.Windows.Forms.Panel();
			this.lbl_Islem = new System.Windows.Forms.Label();
			this.panel4 = new System.Windows.Forms.Panel();
			this.btn_Exit = new System.Windows.Forms.Button();
			this.panel1 = new System.Windows.Forms.Panel();
			this.pictureBox1 = new System.Windows.Forms.PictureBox();
			this.panel2.SuspendLayout();
			this.pnl_Islemler.SuspendLayout();
			this.panel13.SuspendLayout();
			this.panel12.SuspendLayout();
			this.pnl_LisansKey.SuspendLayout();
			this.panel11.SuspendLayout();
			this.pnl_Sifre.SuspendLayout();
			this.panel10.SuspendLayout();
			this.pnl_Email.SuspendLayout();
			this.panel5.SuspendLayout();
			this.panel6.SuspendLayout();
			this.panel4.SuspendLayout();
			this.panel1.SuspendLayout();
			((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
			this.SuspendLayout();
			// 
			// panel2
			// 
			this.panel2.Controls.Add(this.lbl_Info);
			this.panel2.Controls.Add(this.pnl_Islemler);
			this.panel2.Controls.Add(this.panel4);
			this.panel2.Dock = System.Windows.Forms.DockStyle.Right;
			this.panel2.Location = new System.Drawing.Point(399, 0);
			this.panel2.Name = "panel2";
			this.panel2.Size = new System.Drawing.Size(619, 603);
			this.panel2.TabIndex = 1;
			// 
			// lbl_Info
			// 
			this.lbl_Info.Cursor = System.Windows.Forms.Cursors.Hand;
			this.lbl_Info.Dock = System.Windows.Forms.DockStyle.Bottom;
			this.lbl_Info.Font = new System.Drawing.Font("Bahnschrift Light", 9.25F);
			this.lbl_Info.ForeColor = System.Drawing.Color.White;
			this.lbl_Info.Location = new System.Drawing.Point(0, 539);
			this.lbl_Info.Name = "lbl_Info";
			this.lbl_Info.Size = new System.Drawing.Size(619, 64);
			this.lbl_Info.TabIndex = 10;
			this.lbl_Info.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
			// 
			// pnl_Islemler
			// 
			this.pnl_Islemler.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
			this.pnl_Islemler.Controls.Add(this.panel13);
			this.pnl_Islemler.Controls.Add(this.panel12);
			this.pnl_Islemler.Controls.Add(this.pnl_LisansKey);
			this.pnl_Islemler.Controls.Add(this.pnl_Sifre);
			this.pnl_Islemler.Controls.Add(this.pnl_Email);
			this.pnl_Islemler.Controls.Add(this.panel6);
			this.pnl_Islemler.Location = new System.Drawing.Point(67, 164);
			this.pnl_Islemler.Name = "pnl_Islemler";
			this.pnl_Islemler.Size = new System.Drawing.Size(495, 294);
			this.pnl_Islemler.TabIndex = 8;
			// 
			// panel13
			// 
			this.panel13.Controls.Add(this.lbl_SorunMuYasiyorsun);
			this.panel13.Controls.Add(this.lbl_GirisKayit);
			this.panel13.Dock = System.Windows.Forms.DockStyle.Top;
			this.panel13.Location = new System.Drawing.Point(0, 230);
			this.panel13.Name = "panel13";
			this.panel13.Size = new System.Drawing.Size(495, 59);
			this.panel13.TabIndex = 15;
			// 
			// lbl_SorunMuYasiyorsun
			// 
			this.lbl_SorunMuYasiyorsun.Cursor = System.Windows.Forms.Cursors.Hand;
			this.lbl_SorunMuYasiyorsun.Font = new System.Drawing.Font("Bahnschrift Light", 9.25F);
			this.lbl_SorunMuYasiyorsun.ForeColor = System.Drawing.Color.White;
			this.lbl_SorunMuYasiyorsun.Location = new System.Drawing.Point(20, 3);
			this.lbl_SorunMuYasiyorsun.Name = "lbl_SorunMuYasiyorsun";
			this.lbl_SorunMuYasiyorsun.Size = new System.Drawing.Size(461, 25);
			this.lbl_SorunMuYasiyorsun.TabIndex = 9;
			this.lbl_SorunMuYasiyorsun.Text = "Giriş yaparken sorun mu yaşıyorsun?";
			this.lbl_SorunMuYasiyorsun.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
			this.lbl_SorunMuYasiyorsun.Click += new System.EventHandler(this.lbl_SorunMuYasiyorsun_Click);
			// 
			// lbl_GirisKayit
			// 
			this.lbl_GirisKayit.Cursor = System.Windows.Forms.Cursors.Hand;
			this.lbl_GirisKayit.Font = new System.Drawing.Font("Bahnschrift Light", 9.25F);
			this.lbl_GirisKayit.ForeColor = System.Drawing.Color.White;
			this.lbl_GirisKayit.Location = new System.Drawing.Point(20, 28);
			this.lbl_GirisKayit.Name = "lbl_GirisKayit";
			this.lbl_GirisKayit.Size = new System.Drawing.Size(461, 25);
			this.lbl_GirisKayit.TabIndex = 9;
			this.lbl_GirisKayit.Text = "Kayıt Ol";
			this.lbl_GirisKayit.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
			this.lbl_GirisKayit.Click += new System.EventHandler(this.lbl_GirisKayit_Click);
			// 
			// panel12
			// 
			this.panel12.Controls.Add(this.btn_GirisKayit);
			this.panel12.Dock = System.Windows.Forms.DockStyle.Top;
			this.panel12.Location = new System.Drawing.Point(0, 180);
			this.panel12.Name = "panel12";
			this.panel12.Size = new System.Drawing.Size(495, 50);
			this.panel12.TabIndex = 14;
			// 
			// btn_GirisKayit
			// 
			this.btn_GirisKayit.BackColor = System.Drawing.Color.LimeGreen;
			this.btn_GirisKayit.FlatAppearance.BorderSize = 0;
			this.btn_GirisKayit.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
			this.btn_GirisKayit.Font = new System.Drawing.Font("Bahnschrift", 14F);
			this.btn_GirisKayit.ForeColor = System.Drawing.Color.White;
			this.btn_GirisKayit.Location = new System.Drawing.Point(20, 4);
			this.btn_GirisKayit.Name = "btn_GirisKayit";
			this.btn_GirisKayit.Size = new System.Drawing.Size(461, 42);
			this.btn_GirisKayit.TabIndex = 6;
			this.btn_GirisKayit.Text = "Giriş Yap";
			this.btn_GirisKayit.UseVisualStyleBackColor = false;
			this.btn_GirisKayit.Click += new System.EventHandler(this.btn_GirisKayit_ClickAsync);
			this.btn_GirisKayit.Paint += new System.Windows.Forms.PaintEventHandler(this.btn_GirisKayit_Paint);
			// 
			// pnl_LisansKey
			// 
			this.pnl_LisansKey.Controls.Add(this.panel11);
			this.pnl_LisansKey.Dock = System.Windows.Forms.DockStyle.Top;
			this.pnl_LisansKey.Location = new System.Drawing.Point(0, 136);
			this.pnl_LisansKey.Name = "pnl_LisansKey";
			this.pnl_LisansKey.Size = new System.Drawing.Size(495, 44);
			this.pnl_LisansKey.TabIndex = 13;
			this.pnl_LisansKey.Visible = false;
			// 
			// panel11
			// 
			this.panel11.BackColor = System.Drawing.Color.White;
			this.panel11.Controls.Add(this.txb_LisansKey);
			this.panel11.Cursor = System.Windows.Forms.Cursors.IBeam;
			this.panel11.Location = new System.Drawing.Point(20, 4);
			this.panel11.Name = "panel11";
			this.panel11.Size = new System.Drawing.Size(461, 36);
			this.panel11.TabIndex = 6;
			this.panel11.Click += new System.EventHandler(this.panel11_Click);
			// 
			// txb_LisansKey
			// 
			this.txb_LisansKey.BorderStyle = System.Windows.Forms.BorderStyle.None;
			this.txb_LisansKey.Font = new System.Drawing.Font("Bahnschrift Light SemiCondensed", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
			this.txb_LisansKey.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(99)))), ((int)(((byte)(99)))), ((int)(((byte)(99)))));
			this.txb_LisansKey.Location = new System.Drawing.Point(14, 8);
			this.txb_LisansKey.Name = "txb_LisansKey";
			this.txb_LisansKey.Size = new System.Drawing.Size(432, 20);
			this.txb_LisansKey.TabIndex = 3;
			this.txb_LisansKey.Text = "Lisans Key";
			this.txb_LisansKey.Click += new System.EventHandler(this.txb_LisansKey_Click);
			this.txb_LisansKey.Leave += new System.EventHandler(this.txb_LisansKey_Leave);
			// 
			// pnl_Sifre
			// 
			this.pnl_Sifre.Controls.Add(this.panel10);
			this.pnl_Sifre.Dock = System.Windows.Forms.DockStyle.Top;
			this.pnl_Sifre.Location = new System.Drawing.Point(0, 92);
			this.pnl_Sifre.Name = "pnl_Sifre";
			this.pnl_Sifre.Size = new System.Drawing.Size(495, 44);
			this.pnl_Sifre.TabIndex = 12;
			// 
			// panel10
			// 
			this.panel10.BackColor = System.Drawing.Color.White;
			this.panel10.Controls.Add(this.txb_Sifre);
			this.panel10.Cursor = System.Windows.Forms.Cursors.IBeam;
			this.panel10.Location = new System.Drawing.Point(20, 4);
			this.panel10.Name = "panel10";
			this.panel10.Size = new System.Drawing.Size(461, 36);
			this.panel10.TabIndex = 6;
			this.panel10.Click += new System.EventHandler(this.panel10_Click);
			// 
			// txb_Sifre
			// 
			this.txb_Sifre.BorderStyle = System.Windows.Forms.BorderStyle.None;
			this.txb_Sifre.Font = new System.Drawing.Font("Bahnschrift Light SemiCondensed", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
			this.txb_Sifre.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(99)))), ((int)(((byte)(99)))), ((int)(((byte)(99)))));
			this.txb_Sifre.Location = new System.Drawing.Point(14, 8);
			this.txb_Sifre.Name = "txb_Sifre";
			this.txb_Sifre.Size = new System.Drawing.Size(432, 20);
			this.txb_Sifre.TabIndex = 3;
			this.txb_Sifre.Text = "Şifre";
			this.txb_Sifre.Click += new System.EventHandler(this.txb_Sifre_Click);
			this.txb_Sifre.TextChanged += new System.EventHandler(this.txb_Sifre_TextChanged);
			this.txb_Sifre.Leave += new System.EventHandler(this.txb_Sifre_Leave);
			// 
			// pnl_Email
			// 
			this.pnl_Email.Controls.Add(this.panel5);
			this.pnl_Email.Dock = System.Windows.Forms.DockStyle.Top;
			this.pnl_Email.Location = new System.Drawing.Point(0, 48);
			this.pnl_Email.Name = "pnl_Email";
			this.pnl_Email.Size = new System.Drawing.Size(495, 44);
			this.pnl_Email.TabIndex = 11;
			// 
			// panel5
			// 
			this.panel5.BackColor = System.Drawing.Color.White;
			this.panel5.Controls.Add(this.txb_Email);
			this.panel5.Cursor = System.Windows.Forms.Cursors.IBeam;
			this.panel5.Location = new System.Drawing.Point(20, 4);
			this.panel5.Name = "panel5";
			this.panel5.Size = new System.Drawing.Size(461, 36);
			this.panel5.TabIndex = 6;
			this.panel5.Click += new System.EventHandler(this.panel5_Click);
			// 
			// txb_Email
			// 
			this.txb_Email.BorderStyle = System.Windows.Forms.BorderStyle.None;
			this.txb_Email.Font = new System.Drawing.Font("Bahnschrift Light SemiCondensed", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
			this.txb_Email.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(99)))), ((int)(((byte)(99)))), ((int)(((byte)(99)))));
			this.txb_Email.Location = new System.Drawing.Point(14, 8);
			this.txb_Email.Name = "txb_Email";
			this.txb_Email.Size = new System.Drawing.Size(432, 20);
			this.txb_Email.TabIndex = 3;
			this.txb_Email.Text = "E-Mail";
			this.txb_Email.Click += new System.EventHandler(this.txb_Email_Click);
			this.txb_Email.Leave += new System.EventHandler(this.txb_Email_Leave);
			// 
			// panel6
			// 
			this.panel6.Controls.Add(this.lbl_Islem);
			this.panel6.Dock = System.Windows.Forms.DockStyle.Top;
			this.panel6.Location = new System.Drawing.Point(0, 0);
			this.panel6.Name = "panel6";
			this.panel6.Size = new System.Drawing.Size(495, 48);
			this.panel6.TabIndex = 10;
			// 
			// lbl_Islem
			// 
			this.lbl_Islem.Font = new System.Drawing.Font("Bahnschrift Light", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
			this.lbl_Islem.ForeColor = System.Drawing.Color.White;
			this.lbl_Islem.Location = new System.Drawing.Point(15, 15);
			this.lbl_Islem.Name = "lbl_Islem";
			this.lbl_Islem.Size = new System.Drawing.Size(461, 32);
			this.lbl_Islem.TabIndex = 1;
			this.lbl_Islem.Text = "Giriş Yap";
			// 
			// panel4
			// 
			this.panel4.Controls.Add(this.btn_Exit);
			this.panel4.Dock = System.Windows.Forms.DockStyle.Top;
			this.panel4.Location = new System.Drawing.Point(0, 0);
			this.panel4.Name = "panel4";
			this.panel4.Size = new System.Drawing.Size(619, 36);
			this.panel4.TabIndex = 2;
			// 
			// btn_Exit
			// 
			this.btn_Exit.Dock = System.Windows.Forms.DockStyle.Right;
			this.btn_Exit.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
			this.btn_Exit.ForeColor = System.Drawing.Color.Red;
			this.btn_Exit.Location = new System.Drawing.Point(583, 0);
			this.btn_Exit.Name = "btn_Exit";
			this.btn_Exit.Size = new System.Drawing.Size(36, 36);
			this.btn_Exit.TabIndex = 0;
			this.btn_Exit.Text = "X";
			this.btn_Exit.UseVisualStyleBackColor = true;
			this.btn_Exit.Click += new System.EventHandler(this.btn_Exit_Click);
			// 
			// panel1
			// 
			this.panel1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(24)))), ((int)(((byte)(24)))), ((int)(((byte)(24)))));
			this.panel1.Controls.Add(this.pictureBox1);
			this.panel1.Dock = System.Windows.Forms.DockStyle.Fill;
			this.panel1.Location = new System.Drawing.Point(0, 0);
			this.panel1.MaximumSize = new System.Drawing.Size(563, 9999);
			this.panel1.Name = "panel1";
			this.panel1.Size = new System.Drawing.Size(399, 603);
			this.panel1.TabIndex = 2;
			// 
			// pictureBox1
			// 
			this.pictureBox1.Anchor = System.Windows.Forms.AnchorStyles.None;
			this.pictureBox1.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox1.Image")));
			this.pictureBox1.Location = new System.Drawing.Point(38, 3);
			this.pictureBox1.Name = "pictureBox1";
			this.pictureBox1.Size = new System.Drawing.Size(319, 597);
			this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
			this.pictureBox1.TabIndex = 1;
			this.pictureBox1.TabStop = false;
			// 
			// Form1
			// 
			this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
			this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
			this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(19)))), ((int)(((byte)(19)))), ((int)(((byte)(19)))));
			this.ClientSize = new System.Drawing.Size(1018, 603);
			this.Controls.Add(this.panel1);
			this.Controls.Add(this.panel2);
			this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
			this.Name = "Form1";
			this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
			this.Text = "Form1";
			this.Load += new System.EventHandler(this.Form1_Load);
			this.panel2.ResumeLayout(false);
			this.pnl_Islemler.ResumeLayout(false);
			this.panel13.ResumeLayout(false);
			this.panel12.ResumeLayout(false);
			this.pnl_LisansKey.ResumeLayout(false);
			this.panel11.ResumeLayout(false);
			this.panel11.PerformLayout();
			this.pnl_Sifre.ResumeLayout(false);
			this.panel10.ResumeLayout(false);
			this.panel10.PerformLayout();
			this.pnl_Email.ResumeLayout(false);
			this.panel5.ResumeLayout(false);
			this.panel5.PerformLayout();
			this.panel6.ResumeLayout(false);
			this.panel4.ResumeLayout(false);
			this.panel1.ResumeLayout(false);
			((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
			this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.Panel panel4;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.Panel panel5;
        private System.Windows.Forms.Panel pnl_Islemler;
        private System.Windows.Forms.Button btn_Exit;
        private System.Windows.Forms.Label lbl_GirisKayit;
        private System.Windows.Forms.Panel panel13;
        private System.Windows.Forms.Label lbl_SorunMuYasiyorsun;
        private System.Windows.Forms.Panel panel12;
        private System.Windows.Forms.Button btn_GirisKayit;
        private System.Windows.Forms.Panel pnl_LisansKey;
        private System.Windows.Forms.Panel panel11;
        private System.Windows.Forms.TextBox txb_LisansKey;
        private System.Windows.Forms.Panel pnl_Sifre;
        private System.Windows.Forms.Panel panel10;
        private System.Windows.Forms.Panel pnl_Email;
        private System.Windows.Forms.Panel panel6;
        private System.Windows.Forms.Label lbl_Islem;
        public System.Windows.Forms.TextBox txb_Email;
        public System.Windows.Forms.TextBox txb_Sifre;
        public System.Windows.Forms.Label lbl_Info;
    }
}

