﻿using Mail.Forms;
using Newtonsoft.Json;
using RestoranOtomasyon.Functions;
using RestoranOtomasyon.Objects;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace RestoranOtomasyon.Forms
{
	public partial class HesapAl : Form
	{
		// GLOBAL VARIABLES
		int masaId;
		int kategoriId;
		string kategoriAdi;
		string masaNo;
		AdisyonObject adisyon = new AdisyonObject();
		List<SiparisObject> siparisler = new List<SiparisObject>();
		int odenmisTutar = 0;
		int odenmemisTutar = 0;
		// CONSTRUCTOR AND LOAD EVENT
		public HesapAl(int masaId, int kategoriId, string kategoriAdi, string masaNo)
		{
			InitializeComponent();
			this.masaId = masaId;
			this.kategoriId = kategoriId;	
			this.kategoriAdi = kategoriAdi;
			this.masaNo = masaNo;
		}

		private void HesapAl_Load(object sender, EventArgs e)
		{
			txb_MasaNo.Text = kategoriAdi + " - " + masaNo;
			getAdisyon();
			loadSiparisler();
		}

		// FUNCTIONS
		public void Message(string message)
		{
			MyMessageBox myMessageBox = new MyMessageBox(message);
			myMessageBox.ShowDialog();
		}
		public void getAdisyon()
		{
			Database adisyonDb = new Database();
			adisyon = adisyonDb.getAdisyonFromMasaIdWhereIsActive(masaId);
			if (adisyon.OdenmeDurumu == true)
			{
				adisyon = null;
			}
		}
		public void loadSiparisler()
		{
			if (adisyon != null)
			{
				dgw_Siparisler.Rows.Clear();
				odenmisTutar = 0;
				odenmemisTutar = 0;
				Database siparisDb = new Database();
				siparisler = siparisDb.getSiparisListFromAdisyonId(adisyon.Id);
				foreach (var siparis in siparisler)
				{
					Database urunDb = new Database();
					UrunObject urun = urunDb.getUrun(siparis.UrunId);
					if (siparis.SiparisOdenmeDurumu == true)
					{
						DataGridViewRow row = new DataGridViewRow();
						row.CreateCells(dgw_Siparisler);
						row.Cells[0].Value = siparis.Id;
						row.Cells[1].Value = urun.UrunAdi;
						row.Cells[2].Value = siparis.SiparisAdedi.ToString();
						row.Cells[3].Value = urun.SatisFiyati.ToString();
						row.Cells[4].Value = (siparis.SiparisAdedi * urun.SatisFiyati).ToString();
						row.DefaultCellStyle.BackColor = Color.Red;
						row.DefaultCellStyle.ForeColor = Color.White;
						dgw_Siparisler.Rows.Add(row);
						try
						{
							odenmisTutar += Convert.ToInt32(siparis.SiparisAdedi * urun.SatisFiyati);

						}
						catch
						{

						}
					}
					else
					{
						DataGridViewRow row = new DataGridViewRow();
						row.CreateCells(dgw_Siparisler);
						row.Cells[0].Value = siparis.Id;
						row.Cells[1].Value = urun.UrunAdi;
						row.Cells[2].Value = siparis.SiparisAdedi.ToString();
						row.Cells[3].Value = urun.SatisFiyati.ToString();
						row.Cells[4].Value = (siparis.SiparisAdedi * urun.SatisFiyati).ToString();
						row.DefaultCellStyle.BackColor = Color.Lime;

						dgw_Siparisler.Rows.Add(row);
						try
						{
							odenmemisTutar += Convert.ToInt32(siparis.SiparisAdedi * urun.SatisFiyati);

						}
						catch
						{

						}
					}
				}

				txb_KalanTutar.Text = (odenmemisTutar).ToString() + "₺";
				lbl_ToplamTutar.Text = (odenmemisTutar + odenmisTutar).ToString() + "₺";
			}
			else
			{
				Message("Bu masanın hesabı bulunmamaktadır.");
				this.Close();
			}
			
		}


		// EVENTS
		private void btn_Exit_Click(object sender, EventArgs e)
		{
			this.Close();
		}

		private void btn_HesaptanDus_Click(object sender, EventArgs e)
		{
			if (!(siparisler.Count > 0))
			{
				Message("Bu masaya ait bir sipariş bulunamadı.");
			}
			else
			{
				//bool greenFlag = false;
				string result = "";
				foreach (DataGridViewCell cell in dgw_Siparisler.SelectedCells)
				{
					int selectedrowindex = cell.RowIndex;
					DataGridViewRow row = dgw_Siparisler.Rows[selectedrowindex];
					//if (row.DefaultCellStyle.BackColor != Color.Red)
					//{
					//	greenFlag = true;
					//}
					SiparisObject siparis;
					try
					{
						siparis = siparisler.Find(x => x.Id == Convert.ToInt32(row.Cells[0].Value));
					}
					catch
					{
						siparis = new SiparisObject();
					}
					Database hesapDb = new Database();
					siparis.SiparisOdenmeDurumu = true;
					hesapDb.updateSiparis(siparis);
				}

				loadSiparisler();
				bool flag = false;

				foreach (var sip in siparisler)
				{
					if (sip.SiparisOdenmeDurumu == false)
					{
						flag = true;
						break;
					}
				}

				if (!flag && siparisler.Count > 0)
				{
					Database updateAdisyon = new Database();
					adisyon.OdenmeDurumu = true;
					adisyon.OdenmeTarihi = DateTime.Now;
					updateAdisyon.updateAdisyon(adisyon);
					result += "\nTüm ürünler ödendiği için adisyon kapatılmıştır.";
					Message(result);
					this.Close();
				}
			}
			

		}

		private void dgw_Siparisler_CellClick(object sender, DataGridViewCellEventArgs e)
		{
			
			
		}

		private void btn_HesabiKapat_Click(object sender, EventArgs e)
		{
			if (!(siparisler.Count > 0))
			{
				Message("Bu masaya ait bir sipariş bulunamamıştır.");
			}
			else
			{
				DialogResult result = MessageBox.Show("Adisyonun tamamı ödendi olarak işaretlenecektir. Onaylıyor musunuz?", "Lütfen yapmak istediğiniz işlemi doğrulayın.", MessageBoxButtons.YesNo);
				if (result == DialogResult.Yes)
				{
					foreach (var siparis in siparisler)
					{
						Database updateDb = new Database();
						siparis.SiparisOdenmeDurumu = true;
						updateDb.updateSiparis(siparis);
					}
					Database updateAdisyonDb = new Database();
					adisyon.OdenmeDurumu = true;
					adisyon.OdenmeTarihi = DateTime.Now;
					string resultMsg = updateAdisyonDb.updateAdisyon(adisyon);
					Message(resultMsg);
					this.Close();

				}
				else if (result == DialogResult.No)
				{
					Message("Hesap kapatma işlemi iptal edilmiştir.");
				}
			}
		}

		private void dgw_Siparisler_CellContentClick(object sender, DataGridViewCellEventArgs e)
		{

		}

		private void dgw_Siparisler_CellClick_1(object sender, DataGridViewCellEventArgs e)
		{
			int odenecekTutar = 0;
			List<int> indexs = new List<int>();
			foreach (DataGridViewCell cell in dgw_Siparisler.SelectedCells)
			{
				int selectedrowindex = cell.RowIndex;
				DataGridViewRow row = dgw_Siparisler.Rows[selectedrowindex];
				try
				{
					if (!(indexs.Contains(selectedrowindex)) && row.DefaultCellStyle.BackColor != Color.Red)
					{
						odenecekTutar += Convert.ToInt32(row.Cells[4].Value);
						indexs.Add(selectedrowindex);
					}
				}
				catch { }
			}
			txb_AlinacakOdeme.Text = odenecekTutar.ToString();
		}
	}
}
