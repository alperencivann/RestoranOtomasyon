﻿namespace RestoranOtomasyon.Forms
{
    partial class YonetimBayiAyarlari
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.pnl_KullaniciDuzenleme = new System.Windows.Forms.Panel();
            this.pnl_Bayiler = new System.Windows.Forms.Panel();
            this.panel1 = new System.Windows.Forms.Panel();
            this.panel4 = new System.Windows.Forms.Panel();
            this.panel7 = new System.Windows.Forms.Panel();
            this.panel6 = new System.Windows.Forms.Panel();
            this.button2 = new System.Windows.Forms.Button();
            this.label2 = new System.Windows.Forms.Label();
            this.pnl_KullaniciDuzenleme.SuspendLayout();
            this.panel7.SuspendLayout();
            this.panel6.SuspendLayout();
            this.SuspendLayout();
            // 
            // pnl_KullaniciDuzenleme
            // 
            this.pnl_KullaniciDuzenleme.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(39)))), ((int)(((byte)(39)))), ((int)(((byte)(39)))));
            this.pnl_KullaniciDuzenleme.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.pnl_KullaniciDuzenleme.Controls.Add(this.pnl_Bayiler);
            this.pnl_KullaniciDuzenleme.Controls.Add(this.panel1);
            this.pnl_KullaniciDuzenleme.Controls.Add(this.panel4);
            this.pnl_KullaniciDuzenleme.Controls.Add(this.panel7);
            this.pnl_KullaniciDuzenleme.Dock = System.Windows.Forms.DockStyle.Fill;
            this.pnl_KullaniciDuzenleme.Location = new System.Drawing.Point(0, 0);
            this.pnl_KullaniciDuzenleme.Name = "pnl_KullaniciDuzenleme";
            this.pnl_KullaniciDuzenleme.Size = new System.Drawing.Size(734, 611);
            this.pnl_KullaniciDuzenleme.TabIndex = 3;
            // 
            // pnl_Bayiler
            // 
            this.pnl_Bayiler.AutoScroll = true;
            this.pnl_Bayiler.Dock = System.Windows.Forms.DockStyle.Fill;
            this.pnl_Bayiler.Location = new System.Drawing.Point(25, 35);
            this.pnl_Bayiler.Name = "pnl_Bayiler";
            this.pnl_Bayiler.Size = new System.Drawing.Size(682, 574);
            this.pnl_Bayiler.TabIndex = 8;
            // 
            // panel1
            // 
            this.panel1.Dock = System.Windows.Forms.DockStyle.Right;
            this.panel1.Location = new System.Drawing.Point(707, 35);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(25, 574);
            this.panel1.TabIndex = 7;
            // 
            // panel4
            // 
            this.panel4.Dock = System.Windows.Forms.DockStyle.Left;
            this.panel4.Location = new System.Drawing.Point(0, 35);
            this.panel4.Name = "panel4";
            this.panel4.Size = new System.Drawing.Size(25, 574);
            this.panel4.TabIndex = 5;
            // 
            // panel7
            // 
            this.panel7.Controls.Add(this.panel6);
            this.panel7.Controls.Add(this.label2);
            this.panel7.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel7.Location = new System.Drawing.Point(0, 0);
            this.panel7.Name = "panel7";
            this.panel7.Size = new System.Drawing.Size(732, 35);
            this.panel7.TabIndex = 1;
            // 
            // panel6
            // 
            this.panel6.Controls.Add(this.button2);
            this.panel6.Dock = System.Windows.Forms.DockStyle.Right;
            this.panel6.Location = new System.Drawing.Point(532, 0);
            this.panel6.Name = "panel6";
            this.panel6.Size = new System.Drawing.Size(200, 35);
            this.panel6.TabIndex = 1;
            // 
            // button2
            // 
            this.button2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(2)))), ((int)(((byte)(117)))), ((int)(((byte)(252)))));
            this.button2.FlatAppearance.BorderSize = 0;
            this.button2.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button2.Font = new System.Drawing.Font("Century Gothic", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.button2.ForeColor = System.Drawing.Color.White;
            this.button2.Location = new System.Drawing.Point(13, 5);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(162, 24);
            this.button2.TabIndex = 5;
            this.button2.Text = "Yeni Bayi Ekle";
            this.button2.UseVisualStyleBackColor = false;
            this.button2.Click += new System.EventHandler(this.button2_Click);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Century Gothic", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label2.ForeColor = System.Drawing.Color.White;
            this.label2.Location = new System.Drawing.Point(21, 9);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(111, 16);
            this.label2.TabIndex = 0;
            this.label2.Text = "Bayi Düzenleme";
            // 
            // YonetimBayiAyarlari
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(49)))), ((int)(((byte)(49)))), ((int)(((byte)(49)))));
            this.ClientSize = new System.Drawing.Size(734, 611);
            this.Controls.Add(this.pnl_KullaniciDuzenleme);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "YonetimBayiAyarlari";
            this.Text = "YonetimBayiAyarlari";
            this.Load += new System.EventHandler(this.YonetimBayiAyarlari_Load);
            this.pnl_KullaniciDuzenleme.ResumeLayout(false);
            this.panel7.ResumeLayout(false);
            this.panel7.PerformLayout();
            this.panel6.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel pnl_KullaniciDuzenleme;
        private System.Windows.Forms.Panel pnl_Bayiler;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Panel panel4;
        private System.Windows.Forms.Panel panel7;
        private System.Windows.Forms.Panel panel6;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.Label label2;
    }
}