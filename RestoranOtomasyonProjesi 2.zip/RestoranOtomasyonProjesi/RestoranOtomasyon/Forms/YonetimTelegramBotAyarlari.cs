﻿using Mail.Forms;
using RestoranOtomasyon.Components;
using RestoranOtomasyon.Functions;
using RestoranOtomasyon.Objects;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace RestoranOtomasyon.Forms
{
    public partial class YonetimTelegramBotAyarlari : Form
    {
        // GLOBAL VARIABLES

        // CONSTRUCTOR AND LOAD EVENTS
        public YonetimTelegramBotAyarlari()
        {
            InitializeComponent();
        }

        private void YonetimTelegramBotAyarlari_Load(object sender, EventArgs e)
        {
            loadTelegram();
        }

        // FUNCS
        public void Message(string message)
        {
            MyMessageBox myMessageBox = new MyMessageBox(message);
            myMessageBox.ShowDialog();
        }
        public void loadTelegram()
        {
            pnl_TelegramBotlari.Controls.Clear();
            Database database = new Database();
            List<TelegramBotObject> telegramBotlar = database.listTelegram();
            foreach (var telegram in telegramBotlar)
            {
                YonetimTelegramBot yonetimTelegram = new YonetimTelegramBot(telegram.Id,telegram.KullaniciId,telegram.BotKey,telegram.ChatId,telegram.SiparisBildirim,telegram.AlinacaklarListesiBildirim,telegram.RezervasyonBildirim,telegram.GunlukRaporBildirim,telegram.YonetimAyariBildirim,telegram.CalisanMaasBildirim,telegram.BotAdi,telegram.Aktiflik, this)
                {
                    Dock = DockStyle.Top,
                    BorderStyle = BorderStyle.FixedSingle,
                };
                pnl_TelegramBotlari.Controls.Add(yonetimTelegram);
                Panel marginPanel = new Panel()
                {
                    Height = 5,
                    Dock = DockStyle.Top,
                    BackColor = Color.FromArgb(39, 39, 39),
                };
                pnl_TelegramBotlari.Controls.Add(marginPanel);
            }
        }

        private void button2_Click(object sender2, EventArgs e)
        {
            YeniTelegramBotuEkleForm yeniTelegram = new YeniTelegramBotuEkleForm();
            yeniTelegram.FormClosing += (sender, args) =>
            {
                loadTelegram();
            };
            yeniTelegram.ShowDialog();
        }

		private void label3_Click(object sender, EventArgs e)
		{
			Clipboard.SetText("https://api.telegram.org/bot{Bot_Key}/getUpdates");
            Message("Link kopyalandı.");
		}

		// EVENTS
	}
}
