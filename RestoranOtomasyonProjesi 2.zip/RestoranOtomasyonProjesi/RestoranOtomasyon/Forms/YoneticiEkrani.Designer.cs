﻿namespace RestoranOtomasyon.Forms
{
    partial class YoneticiEkrani
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
			this.panel1 = new System.Windows.Forms.Panel();
			this.lbl_Header = new System.Windows.Forms.Label();
			this.panel2 = new System.Windows.Forms.Panel();
			this.panel10 = new System.Windows.Forms.Panel();
			this.panel3 = new System.Windows.Forms.Panel();
			this.pnl_Telegram = new System.Windows.Forms.Panel();
			this.btn_TelegramBotAyarlari = new System.Windows.Forms.Button();
			this.pnl_Urun = new System.Windows.Forms.Panel();
			this.btn_UrunYonetimi = new System.Windows.Forms.Button();
			this.panel9 = new System.Windows.Forms.Panel();
			this.btn_ModulYonetimi = new System.Windows.Forms.Button();
			this.panel8 = new System.Windows.Forms.Panel();
			this.btn_Raporlar = new System.Windows.Forms.Button();
			this.pnl_Bayi = new System.Windows.Forms.Panel();
			this.btn_BayiAyarlari = new System.Windows.Forms.Button();
			this.pnl_Kullanici = new System.Windows.Forms.Panel();
			this.btn_KullaniciAyarlari = new System.Windows.Forms.Button();
			this.panel5 = new System.Windows.Forms.Panel();
			this.btn_RestoranAyarlari = new System.Windows.Forms.Button();
			this.pnl_Icerik = new System.Windows.Forms.Panel();
			this.panel1.SuspendLayout();
			this.panel3.SuspendLayout();
			this.pnl_Telegram.SuspendLayout();
			this.pnl_Urun.SuspendLayout();
			this.panel9.SuspendLayout();
			this.panel8.SuspendLayout();
			this.pnl_Bayi.SuspendLayout();
			this.pnl_Kullanici.SuspendLayout();
			this.panel5.SuspendLayout();
			this.SuspendLayout();
			// 
			// panel1
			// 
			this.panel1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(24)))), ((int)(((byte)(24)))), ((int)(((byte)(24)))));
			this.panel1.Controls.Add(this.lbl_Header);
			this.panel1.Controls.Add(this.panel2);
			this.panel1.Controls.Add(this.panel10);
			this.panel1.Dock = System.Windows.Forms.DockStyle.Top;
			this.panel1.Location = new System.Drawing.Point(0, 0);
			this.panel1.Name = "panel1";
			this.panel1.Size = new System.Drawing.Size(1000, 50);
			this.panel1.TabIndex = 2;
			// 
			// lbl_Header
			// 
			this.lbl_Header.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(29)))), ((int)(((byte)(29)))), ((int)(((byte)(29)))));
			this.lbl_Header.Dock = System.Windows.Forms.DockStyle.Fill;
			this.lbl_Header.Font = new System.Drawing.Font("Century Gothic", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
			this.lbl_Header.ForeColor = System.Drawing.Color.White;
			this.lbl_Header.Location = new System.Drawing.Point(10, 0);
			this.lbl_Header.Name = "lbl_Header";
			this.lbl_Header.Size = new System.Drawing.Size(459, 50);
			this.lbl_Header.TabIndex = 5;
			this.lbl_Header.Text = "Yönetici Ekranı";
			this.lbl_Header.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
			this.lbl_Header.Click += new System.EventHandler(this.lbl_Header_Click);
			// 
			// panel2
			// 
			this.panel2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(29)))), ((int)(((byte)(29)))), ((int)(((byte)(29)))));
			this.panel2.Dock = System.Windows.Forms.DockStyle.Left;
			this.panel2.Location = new System.Drawing.Point(0, 0);
			this.panel2.Name = "panel2";
			this.panel2.Size = new System.Drawing.Size(10, 50);
			this.panel2.TabIndex = 4;
			// 
			// panel10
			// 
			this.panel10.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(29)))), ((int)(((byte)(29)))), ((int)(((byte)(29)))));
			this.panel10.Dock = System.Windows.Forms.DockStyle.Right;
			this.panel10.Location = new System.Drawing.Point(469, 0);
			this.panel10.Name = "panel10";
			this.panel10.Size = new System.Drawing.Size(531, 50);
			this.panel10.TabIndex = 3;
			// 
			// panel3
			// 
			this.panel3.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(29)))), ((int)(((byte)(29)))), ((int)(((byte)(29)))));
			this.panel3.Controls.Add(this.pnl_Telegram);
			this.panel3.Controls.Add(this.pnl_Urun);
			this.panel3.Controls.Add(this.panel9);
			this.panel3.Controls.Add(this.panel8);
			this.panel3.Controls.Add(this.pnl_Bayi);
			this.panel3.Controls.Add(this.pnl_Kullanici);
			this.panel3.Controls.Add(this.panel5);
			this.panel3.Dock = System.Windows.Forms.DockStyle.Left;
			this.panel3.Location = new System.Drawing.Point(0, 50);
			this.panel3.Name = "panel3";
			this.panel3.Size = new System.Drawing.Size(250, 550);
			this.panel3.TabIndex = 3;
			// 
			// pnl_Telegram
			// 
			this.pnl_Telegram.Controls.Add(this.btn_TelegramBotAyarlari);
			this.pnl_Telegram.Dock = System.Windows.Forms.DockStyle.Top;
			this.pnl_Telegram.Location = new System.Drawing.Point(0, 318);
			this.pnl_Telegram.Name = "pnl_Telegram";
			this.pnl_Telegram.Size = new System.Drawing.Size(250, 53);
			this.pnl_Telegram.TabIndex = 6;
			// 
			// btn_TelegramBotAyarlari
			// 
			this.btn_TelegramBotAyarlari.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(19)))), ((int)(((byte)(19)))), ((int)(((byte)(19)))));
			this.btn_TelegramBotAyarlari.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(49)))), ((int)(((byte)(49)))), ((int)(((byte)(49)))));
			this.btn_TelegramBotAyarlari.FlatAppearance.BorderSize = 2;
			this.btn_TelegramBotAyarlari.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
			this.btn_TelegramBotAyarlari.Font = new System.Drawing.Font("Century Gothic", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
			this.btn_TelegramBotAyarlari.ForeColor = System.Drawing.Color.White;
			this.btn_TelegramBotAyarlari.Location = new System.Drawing.Point(9, 6);
			this.btn_TelegramBotAyarlari.Name = "btn_TelegramBotAyarlari";
			this.btn_TelegramBotAyarlari.Size = new System.Drawing.Size(232, 44);
			this.btn_TelegramBotAyarlari.TabIndex = 0;
			this.btn_TelegramBotAyarlari.Text = "Telegram Bot Ayarları";
			this.btn_TelegramBotAyarlari.UseVisualStyleBackColor = false;
			this.btn_TelegramBotAyarlari.Click += new System.EventHandler(this.btn_TelegramBotAyarlari_Click);
			// 
			// pnl_Urun
			// 
			this.pnl_Urun.Controls.Add(this.btn_UrunYonetimi);
			this.pnl_Urun.Dock = System.Windows.Forms.DockStyle.Top;
			this.pnl_Urun.Location = new System.Drawing.Point(0, 265);
			this.pnl_Urun.Name = "pnl_Urun";
			this.pnl_Urun.Size = new System.Drawing.Size(250, 53);
			this.pnl_Urun.TabIndex = 5;
			// 
			// btn_UrunYonetimi
			// 
			this.btn_UrunYonetimi.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(19)))), ((int)(((byte)(19)))), ((int)(((byte)(19)))));
			this.btn_UrunYonetimi.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(49)))), ((int)(((byte)(49)))), ((int)(((byte)(49)))));
			this.btn_UrunYonetimi.FlatAppearance.BorderSize = 2;
			this.btn_UrunYonetimi.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
			this.btn_UrunYonetimi.Font = new System.Drawing.Font("Century Gothic", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
			this.btn_UrunYonetimi.ForeColor = System.Drawing.Color.White;
			this.btn_UrunYonetimi.Location = new System.Drawing.Point(9, 6);
			this.btn_UrunYonetimi.Name = "btn_UrunYonetimi";
			this.btn_UrunYonetimi.Size = new System.Drawing.Size(232, 44);
			this.btn_UrunYonetimi.TabIndex = 0;
			this.btn_UrunYonetimi.Text = "Ürün Yönetimi";
			this.btn_UrunYonetimi.UseVisualStyleBackColor = false;
			this.btn_UrunYonetimi.Click += new System.EventHandler(this.btn_UrunYonetimi_Click);
			// 
			// panel9
			// 
			this.panel9.Controls.Add(this.btn_ModulYonetimi);
			this.panel9.Dock = System.Windows.Forms.DockStyle.Top;
			this.panel9.Location = new System.Drawing.Point(0, 212);
			this.panel9.Name = "panel9";
			this.panel9.Size = new System.Drawing.Size(250, 53);
			this.panel9.TabIndex = 4;
			// 
			// btn_ModulYonetimi
			// 
			this.btn_ModulYonetimi.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(19)))), ((int)(((byte)(19)))), ((int)(((byte)(19)))));
			this.btn_ModulYonetimi.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(49)))), ((int)(((byte)(49)))), ((int)(((byte)(49)))));
			this.btn_ModulYonetimi.FlatAppearance.BorderSize = 2;
			this.btn_ModulYonetimi.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
			this.btn_ModulYonetimi.Font = new System.Drawing.Font("Century Gothic", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
			this.btn_ModulYonetimi.ForeColor = System.Drawing.Color.White;
			this.btn_ModulYonetimi.Location = new System.Drawing.Point(9, 6);
			this.btn_ModulYonetimi.Name = "btn_ModulYonetimi";
			this.btn_ModulYonetimi.Size = new System.Drawing.Size(232, 44);
			this.btn_ModulYonetimi.TabIndex = 0;
			this.btn_ModulYonetimi.Text = "Modül Yönetimi";
			this.btn_ModulYonetimi.UseVisualStyleBackColor = false;
			this.btn_ModulYonetimi.Click += new System.EventHandler(this.btn_ModulYonetimi_Click);
			// 
			// panel8
			// 
			this.panel8.Controls.Add(this.btn_Raporlar);
			this.panel8.Dock = System.Windows.Forms.DockStyle.Top;
			this.panel8.Location = new System.Drawing.Point(0, 159);
			this.panel8.Name = "panel8";
			this.panel8.Size = new System.Drawing.Size(250, 53);
			this.panel8.TabIndex = 3;
			this.panel8.Visible = false;
			// 
			// btn_Raporlar
			// 
			this.btn_Raporlar.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(19)))), ((int)(((byte)(19)))), ((int)(((byte)(19)))));
			this.btn_Raporlar.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(49)))), ((int)(((byte)(49)))), ((int)(((byte)(49)))));
			this.btn_Raporlar.FlatAppearance.BorderSize = 2;
			this.btn_Raporlar.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
			this.btn_Raporlar.Font = new System.Drawing.Font("Century Gothic", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
			this.btn_Raporlar.ForeColor = System.Drawing.Color.White;
			this.btn_Raporlar.Location = new System.Drawing.Point(9, 6);
			this.btn_Raporlar.Name = "btn_Raporlar";
			this.btn_Raporlar.Size = new System.Drawing.Size(232, 44);
			this.btn_Raporlar.TabIndex = 0;
			this.btn_Raporlar.Text = "Raporlar";
			this.btn_Raporlar.UseVisualStyleBackColor = false;
			this.btn_Raporlar.Click += new System.EventHandler(this.btn_Raporlar_Click);
			// 
			// pnl_Bayi
			// 
			this.pnl_Bayi.Controls.Add(this.btn_BayiAyarlari);
			this.pnl_Bayi.Dock = System.Windows.Forms.DockStyle.Top;
			this.pnl_Bayi.Location = new System.Drawing.Point(0, 106);
			this.pnl_Bayi.Name = "pnl_Bayi";
			this.pnl_Bayi.Size = new System.Drawing.Size(250, 53);
			this.pnl_Bayi.TabIndex = 2;
			// 
			// btn_BayiAyarlari
			// 
			this.btn_BayiAyarlari.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(19)))), ((int)(((byte)(19)))), ((int)(((byte)(19)))));
			this.btn_BayiAyarlari.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(49)))), ((int)(((byte)(49)))), ((int)(((byte)(49)))));
			this.btn_BayiAyarlari.FlatAppearance.BorderSize = 2;
			this.btn_BayiAyarlari.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
			this.btn_BayiAyarlari.Font = new System.Drawing.Font("Century Gothic", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
			this.btn_BayiAyarlari.ForeColor = System.Drawing.Color.White;
			this.btn_BayiAyarlari.Location = new System.Drawing.Point(9, 6);
			this.btn_BayiAyarlari.Name = "btn_BayiAyarlari";
			this.btn_BayiAyarlari.Size = new System.Drawing.Size(232, 44);
			this.btn_BayiAyarlari.TabIndex = 0;
			this.btn_BayiAyarlari.Text = "Bayi Ayarları";
			this.btn_BayiAyarlari.UseVisualStyleBackColor = false;
			this.btn_BayiAyarlari.Click += new System.EventHandler(this.btn_BayiAyarlari_Click);
			// 
			// pnl_Kullanici
			// 
			this.pnl_Kullanici.Controls.Add(this.btn_KullaniciAyarlari);
			this.pnl_Kullanici.Dock = System.Windows.Forms.DockStyle.Top;
			this.pnl_Kullanici.Location = new System.Drawing.Point(0, 53);
			this.pnl_Kullanici.Name = "pnl_Kullanici";
			this.pnl_Kullanici.Size = new System.Drawing.Size(250, 53);
			this.pnl_Kullanici.TabIndex = 1;
			// 
			// btn_KullaniciAyarlari
			// 
			this.btn_KullaniciAyarlari.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(19)))), ((int)(((byte)(19)))), ((int)(((byte)(19)))));
			this.btn_KullaniciAyarlari.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(49)))), ((int)(((byte)(49)))), ((int)(((byte)(49)))));
			this.btn_KullaniciAyarlari.FlatAppearance.BorderSize = 2;
			this.btn_KullaniciAyarlari.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
			this.btn_KullaniciAyarlari.Font = new System.Drawing.Font("Century Gothic", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
			this.btn_KullaniciAyarlari.ForeColor = System.Drawing.Color.White;
			this.btn_KullaniciAyarlari.Location = new System.Drawing.Point(9, 6);
			this.btn_KullaniciAyarlari.Name = "btn_KullaniciAyarlari";
			this.btn_KullaniciAyarlari.Size = new System.Drawing.Size(232, 44);
			this.btn_KullaniciAyarlari.TabIndex = 0;
			this.btn_KullaniciAyarlari.Text = "Kullanıcı Ayarları";
			this.btn_KullaniciAyarlari.UseVisualStyleBackColor = false;
			this.btn_KullaniciAyarlari.Click += new System.EventHandler(this.button2_Click);
			// 
			// panel5
			// 
			this.panel5.Controls.Add(this.btn_RestoranAyarlari);
			this.panel5.Dock = System.Windows.Forms.DockStyle.Top;
			this.panel5.Location = new System.Drawing.Point(0, 0);
			this.panel5.Name = "panel5";
			this.panel5.Size = new System.Drawing.Size(250, 53);
			this.panel5.TabIndex = 0;
			// 
			// btn_RestoranAyarlari
			// 
			this.btn_RestoranAyarlari.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(19)))), ((int)(((byte)(19)))), ((int)(((byte)(19)))));
			this.btn_RestoranAyarlari.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(49)))), ((int)(((byte)(49)))), ((int)(((byte)(49)))));
			this.btn_RestoranAyarlari.FlatAppearance.BorderSize = 2;
			this.btn_RestoranAyarlari.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
			this.btn_RestoranAyarlari.Font = new System.Drawing.Font("Century Gothic", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
			this.btn_RestoranAyarlari.ForeColor = System.Drawing.Color.White;
			this.btn_RestoranAyarlari.Location = new System.Drawing.Point(9, 0);
			this.btn_RestoranAyarlari.Name = "btn_RestoranAyarlari";
			this.btn_RestoranAyarlari.Size = new System.Drawing.Size(232, 44);
			this.btn_RestoranAyarlari.TabIndex = 0;
			this.btn_RestoranAyarlari.Text = "Restoran Ayarları";
			this.btn_RestoranAyarlari.UseVisualStyleBackColor = false;
			this.btn_RestoranAyarlari.Click += new System.EventHandler(this.button1_Click);
			// 
			// pnl_Icerik
			// 
			this.pnl_Icerik.Dock = System.Windows.Forms.DockStyle.Fill;
			this.pnl_Icerik.Location = new System.Drawing.Point(250, 50);
			this.pnl_Icerik.Name = "pnl_Icerik";
			this.pnl_Icerik.Size = new System.Drawing.Size(750, 550);
			this.pnl_Icerik.TabIndex = 4;
			// 
			// YoneticiEkrani
			// 
			this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
			this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
			this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(39)))), ((int)(((byte)(39)))), ((int)(((byte)(39)))));
			this.ClientSize = new System.Drawing.Size(1000, 600);
			this.Controls.Add(this.pnl_Icerik);
			this.Controls.Add(this.panel3);
			this.Controls.Add(this.panel1);
			this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
			this.IsMdiContainer = true;
			this.Name = "YoneticiEkrani";
			this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
			this.Text = "YoneticiEkrani";
			this.Load += new System.EventHandler(this.YoneticiEkrani_Load);
			this.panel1.ResumeLayout(false);
			this.panel3.ResumeLayout(false);
			this.pnl_Telegram.ResumeLayout(false);
			this.pnl_Urun.ResumeLayout(false);
			this.panel9.ResumeLayout(false);
			this.panel8.ResumeLayout(false);
			this.pnl_Bayi.ResumeLayout(false);
			this.pnl_Kullanici.ResumeLayout(false);
			this.panel5.ResumeLayout(false);
			this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Label lbl_Header;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.Panel panel10;
        private System.Windows.Forms.Panel panel3;
        private System.Windows.Forms.Panel pnl_Telegram;
        private System.Windows.Forms.Button btn_TelegramBotAyarlari;
        private System.Windows.Forms.Panel pnl_Urun;
        private System.Windows.Forms.Button btn_UrunYonetimi;
        private System.Windows.Forms.Panel panel9;
        private System.Windows.Forms.Button btn_ModulYonetimi;
        private System.Windows.Forms.Panel panel8;
        private System.Windows.Forms.Button btn_Raporlar;
        private System.Windows.Forms.Panel pnl_Bayi;
        private System.Windows.Forms.Button btn_BayiAyarlari;
        private System.Windows.Forms.Panel pnl_Kullanici;
        private System.Windows.Forms.Button btn_KullaniciAyarlari;
        private System.Windows.Forms.Panel panel5;
        private System.Windows.Forms.Button btn_RestoranAyarlari;
        private System.Windows.Forms.Panel pnl_Icerik;
    }
}