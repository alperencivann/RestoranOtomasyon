﻿using RestoranOtomasyon.Functions;
using RestoranOtomasyon.Objects;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace RestoranOtomasyon.Forms
{
    public partial class YoneticiEkrani : Form
    {
        public GarsonEkrani garson;
        public YoneticiEkrani(GarsonEkrani garson)
        {
            InitializeComponent();
            this.garson = garson;
        }

        // GLOBAL VARIABLES
        int bayi = 0, kullanici = 0, modul = 0, raporlar = 0, restoran = 0, telegram = 0, urun = 0;

        YonetimBayiAyarlari bayiForm = new YonetimBayiAyarlari();
        YonetimKullaniciAyarlari kullaniciForm = new YonetimKullaniciAyarlari();
        YonetimModulAyarlari modulForm = new YonetimModulAyarlari();
        YonetimRaporlar raporlarForm = new YonetimRaporlar();
        YonetimRestoranAyarlari restoranForm;
        YonetimTelegramBotAyarlari telegramForm = new YonetimTelegramBotAyarlari();
        YonetimUrunYonetimi urunForm = new YonetimUrunYonetimi();

        
       

        // FUNCS
        public void formGetir(string formAd)
        {
            if (bayiForm.Visible == true && formAd != "bayi")
                bayiForm.Visible = false;
            else if (kullaniciForm.Visible == true && formAd != "kullanici")
                kullaniciForm.Visible = false;
            else if (modulForm.Visible == true && formAd != "modul")
                modulForm.Visible = false;
            else if (raporlarForm.Visible == true && formAd != "raporlar")
                raporlarForm.Visible = false;
            else if (restoranForm.Visible == true && formAd != "restoran")
                restoranForm.Visible = false;
            else if (telegramForm.Visible == true && formAd != "telegram")
                telegramForm.Visible = false;
            else if (urunForm.Visible == true && formAd != "urun")
                urunForm.Visible = false;

            switch (formAd)
            {
                case "bayi":
                    if (bayi == 0)
                    {
                        bayiForm.MdiParent = this;
                        bayiForm.MaximizeBox = true;
                        bayiForm.FormBorderStyle = FormBorderStyle.None;
                        bayiForm.Dock = DockStyle.Fill;
                        pnl_Icerik.Controls.Add(bayiForm);
                        bayiForm.Show();
                        bayi++;
                    }
                    else
                    {
                        bayiForm.Visible = true;
                    }
                    break;
                case "kullanici":
                    if (kullanici == 0)
                    {
                        kullaniciForm.MdiParent = this;
                        kullaniciForm.MaximizeBox = true;
                        kullaniciForm.FormBorderStyle = FormBorderStyle.None;
                        kullaniciForm.Dock = DockStyle.Fill;
                        pnl_Icerik.Controls.Add(kullaniciForm);
                        kullaniciForm.Show();
                        kullanici++;
                    }
                    else
                    {
                        kullaniciForm.Visible = true;
                    }
                    break;
                case "modul":
                    if (modul == 0)
                    {
                        modulForm.MdiParent = this;
                        modulForm.MaximizeBox = true;
                        modulForm.FormBorderStyle = FormBorderStyle.None;
                        modulForm.Dock = DockStyle.Fill;
                        pnl_Icerik.Controls.Add(modulForm);
                        modulForm.Show();
                        modul++;
                    }
                    else
                    {
                        modulForm.Visible = true;
                    }
                    break;
                case "raporlar":
                    if (raporlar == 0)
                    {
                        raporlarForm.MdiParent = this;
                        raporlarForm.MaximizeBox = true;
                        raporlarForm.FormBorderStyle = FormBorderStyle.None;
                        raporlarForm.Dock = DockStyle.Fill;
                        pnl_Icerik.Controls.Add(raporlarForm);
                        raporlarForm.Show();
                        raporlar++;
                    }
                    else
                    {
                        raporlarForm.Visible = true;
                    }
                    break;
                case "restoran":
                    if (restoran == 0)
                    {
                        restoranForm.MdiParent = this;
                        restoranForm.MaximizeBox = true;
                        restoranForm.FormBorderStyle = FormBorderStyle.None;
                        restoranForm.Dock = DockStyle.Fill;
                        pnl_Icerik.Controls.Add(restoranForm);
                        restoranForm.Show();
                        restoran++;
                    }
                    else
                    {
                        restoranForm.Visible = true;
                    }
                    break;
                case "telegram":
                    if (telegram == 0)
                    {
                        telegramForm.MdiParent = this;
                        telegramForm.MaximizeBox = true;
                        telegramForm.FormBorderStyle = FormBorderStyle.None;
                        telegramForm.Dock = DockStyle.Fill;
                        pnl_Icerik.Controls.Add(telegramForm);
                        telegramForm.Show();
                        telegram++;
                    }
                    else
                    {
                        telegramForm.Visible = true;
                    }
                    break;
                case "urun":
                    if (urun == 0)
                    {
                        urunForm.MdiParent = this;
                        urunForm.MaximizeBox = true;
                        urunForm.FormBorderStyle = FormBorderStyle.None;
                        urunForm.Dock = DockStyle.Fill;
                        pnl_Icerik.Controls.Add(urunForm);
                        urunForm.Visible = true;
                        urunForm.Show();

                        urun++;
                    }
                    else
                    {
                        urunForm.Visible = true;
                    }
                    break;

                default:
                    break;
            }
        }



        // EVENTS
        private void YoneticiEkrani_Load(object sender, EventArgs e)
        {
			restoranForm = new YonetimRestoranAyarlari(garson);
			formGetir("restoran");
            Database kullaniciDb = new Database();
            ModulObject kullanici = kullaniciDb.getModulFromName("Kullanıcı");
            if (string.IsNullOrEmpty(kullanici.ModulKey) || kullanici.Aktiflik == false)
            {
                pnl_Kullanici.Visible = false;
            }

			Database bayiDb = new Database();
			ModulObject bayi = bayiDb.getModulFromName("Bayi");
			if (string.IsNullOrEmpty(bayi.ModulKey) || bayi.Aktiflik == false)
			{
				pnl_Bayi.Visible = false;
			}

			Database telegramDb = new Database();
			ModulObject telegram = telegramDb.getModulFromName("Telegram");
			if (string.IsNullOrEmpty(telegram.ModulKey) || telegram.Aktiflik == false)
			{
				pnl_Telegram.Visible = false;
			}

		}
		private void button1_Click(object sender, EventArgs e)
        {
            formGetir("restoran");
        }
        private void button2_Click(object sender, EventArgs e)
        {
            formGetir("kullanici");
        }

		private void lbl_Header_Click(object sender, EventArgs e)
		{

		}

		private void btn_BayiAyarlari_Click(object sender, EventArgs e)
        {
            formGetir("bayi");
        }
        private void btn_Raporlar_Click(object sender, EventArgs e)
        {
            formGetir("raporlar");
        }
        private void btn_ModulYonetimi_Click(object sender, EventArgs e)
        {
            formGetir("modul");
        }
        private void btn_UrunYonetimi_Click(object sender, EventArgs e)
        {
            formGetir("urun");
        }
        private void btn_TelegramBotAyarlari_Click(object sender, EventArgs e)
        {
            formGetir("telegram");
        }

        private void btn_Exit_Click(object sender, EventArgs e)
        {

        }

    }
}
