﻿using RestoranOtomasyon.Components;
using RestoranOtomasyon.Forms;
using RestoranOtomasyon.Objects;
using System;
using System.Collections;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Data.SqlTypes;
using System.Linq;
using System.Runtime.InteropServices;
using System.Text;
using System.Threading.Tasks;


namespace RestoranOtomasyon.Functions
{
    internal class Database
    {
        string connetionString = "Data Source=DESKTOP-OASK6RG\\SQLEXPRESS;Initial Catalog=restoranOtomasyon;Integrated Security=True";
        SqlConnection connection = null;
        public Database()
        {
            
            connection = new SqlConnection(connetionString);
            if (connection.State == System.Data.ConnectionState.Closed)
            {
                connection.Open();
            }
        }
        public bool Connect()
        {
            try
            {
                if (connection.State == System.Data.ConnectionState.Closed)
                {
                    connection.Open();
                }
                return true;
            }
            catch
            {
                return false;
            }
            
        }

        // rezervasyon işlemleri
        public RezervasyonObject getRezervasyon(int id)
        {
            bool isConnected = Connect();
            string sorgu = "select * from tbl_Rezervasyonlar where id=@p1";
            SqlCommand command = new SqlCommand(sorgu, connection);
            command.Parameters.AddWithValue("p1", id);
            SqlDataReader reader = command.ExecuteReader();
            RezervasyonObject rez = new RezervasyonObject();

            while (reader.Read())
            {
                try
                {
					rez.Id = reader.GetInt32(0);
					rez.KullaniciId = reader.GetInt32(1);
					rez.IsimSoyisim = reader.GetString(2);
					rez.RezervasyonTelefonNo = reader.GetString(3);
					rez.RezervasyonSaati = reader.GetDateTime(4);
					rez.RezervasyonOlusturmaTarihi = reader.GetDateTime(5);
					rez.MasaId = reader.GetInt32(6);
					rez.RezervasyonDurumu = reader.GetInt32(7);
					return rez;
				}
                catch 
                {
                    return rez;
                }
                
            }
            connection.Close();

            return rez;

        }
        public List<RezervasyonObject> listRezervasyon(int tip)
        {
            bool isConnected = Connect();
            List<RezervasyonObject> rezervasyonList = new List<RezervasyonObject>();

            string sorgu = "select * from tbl_Rezervasyonlar";
            if (tip != 0) // 0 tüm rezervasyonlar demektir.
            {
                sorgu += " where rezervasyonDurumu = " + tip;
            }
            SqlCommand command = new SqlCommand(sorgu, connection);
            SqlDataReader reader = command.ExecuteReader();
            while (reader.Read())
            {
                RezervasyonObject rez = new RezervasyonObject();
                rez.Id = reader.GetInt32(0);
                rez.KullaniciId = reader.GetInt32(1);
                rez.IsimSoyisim = reader.GetString(2);
                rez.RezervasyonTelefonNo = reader.GetString(3);
                try
                {
                    rez.RezervasyonSaati = reader.GetDateTime(4);
                }
                catch
                {
                    rez.RezervasyonSaati = DateTime.Now;
                }
                try
                {
                    rez.RezervasyonOlusturmaTarihi = reader.GetDateTime(5);

                }
                catch 
                {
                    rez.RezervasyonOlusturmaTarihi = DateTime.Now;

                }
                rez.MasaId = reader.GetInt32(6);
                rez.RezervasyonDurumu = reader.GetInt32(7);
                rezervasyonList.Add(rez);
            }
            connection.Close();

            return rezervasyonList;
        }
        public List<RezervasyonObject> listGecmisRezervasyonlar(string isimSoyisim, string telefonNo)
        {
            telefonNo = telefonNo.Trim().Replace(" ", "");
			bool isConnected = Connect();

			List<RezervasyonObject> rezervasyonList = new List<RezervasyonObject>();

			string sorgu = "select * from tbl_Rezervasyonlar where isimSoyisim = @p1 and rezervasyonTelefonNo = @p2";
			SqlCommand command = new SqlCommand(sorgu, connection);
			command.Parameters.AddWithValue("p1", isimSoyisim);
			command.Parameters.AddWithValue("p2", telefonNo);

			SqlDataReader reader = command.ExecuteReader();
			while (reader.Read())
			{
				RezervasyonObject rez = new RezervasyonObject();
				rez.Id = reader.GetInt32(0);
				rez.KullaniciId = reader.GetInt32(1);
				rez.IsimSoyisim = reader.GetString(2);
				rez.RezervasyonTelefonNo = reader.GetString(3);
				try
				{
					rez.RezervasyonSaati = reader.GetDateTime(4);
				}
				catch
				{
					rez.RezervasyonSaati = DateTime.Now;
				}
				try
				{
					rez.RezervasyonOlusturmaTarihi = reader.GetDateTime(5);

				}
				catch
				{
					rez.RezervasyonOlusturmaTarihi = DateTime.Now;

				}
				rez.MasaId = reader.GetInt32(6);
				rez.RezervasyonDurumu = reader.GetInt32(7);
				rezervasyonList.Add(rez);
			}
			connection.Close();

			return rezervasyonList;
		}

        public string insertRezervasyon(RezervasyonObject rezervasyon)
        {
            bool isConnected = Connect();
            if (!isConnected)
                return "DB Connect Exception";

            try
            {
                string kayit = "insert into tbl_Rezervasyonlar (kullaniciId,isimSoyisim,rezervasyonTelefonNo,rezervasyonSaati,rezervasyonOlusturmaTarihi,masaId,rezervasyonDurumu) values (@p1,@p2,@p3,@p4,@p5,@p6,@p7)";
                SqlCommand ekle = new SqlCommand(kayit, connection);
                ekle.Parameters.AddWithValue("@p1", rezervasyon.KullaniciId);
                ekle.Parameters.AddWithValue("@p2", rezervasyon.IsimSoyisim);
                ekle.Parameters.AddWithValue("@p3", rezervasyon.RezervasyonTelefonNo);
                ekle.Parameters.AddWithValue("@p4", rezervasyon.RezervasyonSaati);
                ekle.Parameters.AddWithValue("@p5", rezervasyon.RezervasyonOlusturmaTarihi);
                ekle.Parameters.AddWithValue("@p6", rezervasyon.MasaId);
                ekle.Parameters.AddWithValue("@p7", rezervasyon.RezervasyonDurumu);
                ekle.ExecuteNonQuery();
                connection.Close();
                return "eklendi";
            }
            catch (Exception ex)
            {

                return ex.ToString();
            }
        }
        public string updateRezervasyon(RezervasyonObject rezervasyon)
        {
            bool isConnected = Connect();
            if (!isConnected)
                return "DB Connect Exception";
            try
            {
                string kayit = "update tbl_Rezervasyonlar set kullaniciId=@p1, isimSoyisim=@p2, rezervasyonTelefonNo=@p3, rezervasyonSaati=@p4, rezervasyonOlusturmaTarihi=@p5, masaId=@p6, rezervasyonDurumu=@p7 where id=@p8";
                SqlCommand ekle = new SqlCommand(kayit, connection);
                ekle.Parameters.AddWithValue("@p1", rezervasyon.KullaniciId);
                ekle.Parameters.AddWithValue("@p2", rezervasyon.IsimSoyisim);
                ekle.Parameters.AddWithValue("@p3", rezervasyon.RezervasyonTelefonNo);
                ekle.Parameters.AddWithValue("@p4", rezervasyon.RezervasyonSaati);
                ekle.Parameters.AddWithValue("@p5", rezervasyon.RezervasyonOlusturmaTarihi);
                ekle.Parameters.AddWithValue("@p6", rezervasyon.MasaId);
                ekle.Parameters.AddWithValue("@p7", rezervasyon.RezervasyonDurumu);
                ekle.Parameters.AddWithValue("@p8", rezervasyon.Id);

                ekle.ExecuteNonQuery();
                connection.Close();
                return "Güncellendi";
            }
            catch (Exception ex)
            {
                return ex.ToString();
            }
        }
        public string deleteRezervasyon(int id)
        {
            bool isConnected = Connect();
            if (!isConnected)
                return "DB Connect Exception";
            try
            {
                string kayit = "DELETE FROM tbl_Rezervasyonlar where id=@p1";
                SqlCommand ekle = new SqlCommand(kayit, connection);
                ekle.Parameters.AddWithValue("@p1", id);
                ekle.ExecuteNonQuery();
                connection.Close();
                return "Silindi";
            }
            catch (Exception ex)
            {
                return ex.ToString();
            }
        }

        // Masa Kategori İşlemleri
        public MasaKategoriObject getMasaKategori(int id)
        {
            bool isConnected = Connect();
            string sorgu = "select * from tbl_MasaKategori where id=@p1";
            SqlCommand command = new SqlCommand(sorgu, connection);
            command.Parameters.AddWithValue("p1", id);
            SqlDataReader reader = command.ExecuteReader();
            MasaKategoriObject masaKategori = new MasaKategoriObject();

            while (reader.Read())
            {
                masaKategori.Id = reader.GetInt32(0);
                masaKategori.KategoriAdi = reader.GetString(1);
                masaKategori.KategoriMasaSayisi = reader.GetInt32(2);
                masaKategori.Aktiflik = reader.GetBoolean(3);
                return masaKategori;
            }
            connection.Close();

            return masaKategori;

        }
        public List<MasaKategoriObject> listMasaKategori()
        {
            bool isConnected = Connect();
            List<MasaKategoriObject> masaKategoriList = new List<MasaKategoriObject>();

            string sorgu = "select * from tbl_MasaKategori";
            SqlCommand command = new SqlCommand(sorgu, connection);
            SqlDataReader reader = command.ExecuteReader();
            while (reader.Read())
            {
                MasaKategoriObject masaKategori = new MasaKategoriObject();
                masaKategori.Id = reader.GetInt32(0);
                masaKategori.KategoriAdi = reader.GetString(1);
                masaKategori.KategoriMasaSayisi = reader.GetInt32(2);
                masaKategori.Aktiflik = reader.GetBoolean(3);
                masaKategoriList.Add(masaKategori);
            }
            connection.Close();
            return masaKategoriList;
        }
        public string insertMasaKategori(MasaKategoriObject masaKategori)
        {
            bool isConnected = Connect();
            if (!isConnected)
                return "DB Connect Exception";

            try
            {
                string kayit = "insert into tbl_MasaKategori (kategoriAdi,kategoriMasaSayisi,aktiflik) values (@p1,@p2,@p3)";
                SqlCommand ekle = new SqlCommand(kayit, connection);
                ekle.Parameters.AddWithValue("@p1", masaKategori.KategoriAdi);
                ekle.Parameters.AddWithValue("@p2", masaKategori.KategoriMasaSayisi);
                ekle.Parameters.AddWithValue("@p3", masaKategori.Aktiflik);
                ekle.ExecuteNonQuery();

                string maxSorgu = "select MAX(id) from tbl_MasaKategori";
                SqlCommand max = new SqlCommand(maxSorgu, connection);
                int maxId = Convert.ToInt32(max.ExecuteScalar());
                for (int i = 1; i <= masaKategori.KategoriMasaSayisi; i++)
                {
                    MasaObject masa = new MasaObject();
                    masa.KategoriId = maxId;
                    masa.MasaNo = i.ToString();
                    masa.Aktiflik = true;
                    insertMasa(masa);
                }

                connection.Close();
                return "Masa kategorisi ekleme işlemi başarılı.";

            }
            catch 
            {
                return "Masa kategorisi ekleme işlemi sırasında bir hata meydana geldi";
            }
        }
        public string updateMasaKategori(MasaKategoriObject masaKategori)
        {
            bool isConnected = Connect();
            if (!isConnected)
                return "DB Connect Exception";
            try
            {
                string update = "update tbl_MasaKategori set kategoriAdi=@p1, kategoriMasaSayisi=@p2, aktiflik=@p3 where id=@p4";
                SqlCommand guncelle = new SqlCommand(update, connection);
                guncelle.Parameters.AddWithValue("@p1", masaKategori.KategoriAdi);
                guncelle.Parameters.AddWithValue("@p2", masaKategori.KategoriMasaSayisi);
                guncelle.Parameters.AddWithValue("@p3", masaKategori.Aktiflik);
                guncelle.Parameters.AddWithValue("@p4", masaKategori.Id);
                guncelle.ExecuteNonQuery();

				for (int i = 1; i <= masaKategori.KategoriMasaSayisi; i++)
				{
					MasaObject masa = new MasaObject();
					masa.KategoriId = masaKategori.Id;
					masa.MasaNo = i.ToString();
					masa.Aktiflik = true;
					insertMasa(masa);
				}
				connection.Close();
                return "Masa kategorisi güncelleme işlemi başarılı.";
            }
            catch 
            {
                return "Güncelleme sırasında bir hata meydana geldi";
            }
        }
        public string deleteMasaKategori(int id)
        {
            bool isConnected = Connect();
            if (!isConnected)
                return "DB Connect Exception";
            try
            {
                string delete = "DELETE FROM tbl_MasaKategori where id=@p1";
                SqlCommand ekle = new SqlCommand(delete, connection);
                ekle.Parameters.AddWithValue("@p1", id);
                ekle.ExecuteNonQuery();
                connection.Close();
                return "Masa kategorisi silme işlemi başarılı";
            }
            catch 
            {
                return "Masa kategorisi silme işlemi sırasında bir hata meydana geldi.";
            }
        }

        // Masa İşlemleri
        public MasaObject getMasa(int id)
        {
            bool isConnected = Connect();
            string sorgu = "select * from tbl_Masalar where id=@p1";
            SqlCommand command = new SqlCommand(sorgu, connection);
            command.Parameters.AddWithValue("p1", id);
            SqlDataReader reader = command.ExecuteReader();
            MasaObject masa = new MasaObject();

            while (reader.Read())
            {
                masa.Id = reader.GetInt32(0);
                masa.MasaNo = reader.GetString(1);
                masa.KategoriId = reader.GetInt32(2);
                masa.Aktiflik = reader.GetBoolean(3);
                return masa;
            }
            connection.Close();

            return masa;

        }
        public List<MasaObject> listMasa()
        {
            bool isConnected = Connect();
            List<MasaObject> MasaList = new List<MasaObject>();

            string sorgu = "select * from tbl_Masalar";
            SqlCommand command = new SqlCommand(sorgu, connection);
            SqlDataReader reader = command.ExecuteReader();
            while (reader.Read())
            {
                MasaObject masa = new MasaObject();
                masa.Id = reader.GetInt32(0);
                masa.MasaNo = reader.GetString(1);
                masa.KategoriId = reader.GetInt32(2);
                masa.Aktiflik = reader.GetBoolean(3);
                MasaList.Add(masa);
            }
            connection.Close();

            return MasaList;
        }
        public List<MasaObject> listMasaWithCategory(int kategoriId)
        {
            bool isConnected = Connect();
            List<MasaObject> MasaList = new List<MasaObject>();

            string sorgu = "select * from tbl_Masalar where kategoriId = @p1";
            SqlCommand command = new SqlCommand(sorgu, connection);
            command.Parameters.AddWithValue("@p1", kategoriId);

            SqlDataReader reader = command.ExecuteReader();
            while (reader.Read())
            {
                MasaObject masa = new MasaObject();
                masa.Id = reader.GetInt32(0);
                masa.MasaNo = reader.GetString(1);
                masa.KategoriId = reader.GetInt32(2);
                masa.Aktiflik = reader.GetBoolean(3);
                MasaList.Add(masa);
            }
            connection.Close();
            return MasaList;
        }
        public string insertMasa(MasaObject masa)
        {
            bool isConnected = Connect();
            if (!isConnected)
                return "DB Connect Exception";

            try
            {
                string kayit = "insert into tbl_Masalar (masaNo,kategoriId,aktiflik) values (@p1,@p2,@p3)";
                SqlCommand ekle = new SqlCommand(kayit, connection);
                ekle.Parameters.AddWithValue("@p1", masa.MasaNo);
                ekle.Parameters.AddWithValue("@p2", masa.KategoriId);
                ekle.Parameters.AddWithValue("@p3", masa.Aktiflik);
                ekle.ExecuteNonQuery();
                connection.Close();
                return "eklendi";
            }
            catch (Exception ex)
            {

                return ex.ToString();
            }
        }
        public string updateMasa(MasaObject masa)
        {
            bool isConnected = Connect();
            if (!isConnected)
                return "DB Connect Exception";
            try
            {
                string update = "update tbl_Masalar set masaNo=@p1, kategoriId=@p2, aktiflik=@p3 where id=@p4";
                SqlCommand guncelle = new SqlCommand(update, connection);
                guncelle.Parameters.AddWithValue("@p1", masa.MasaNo);
                guncelle.Parameters.AddWithValue("@p2", masa.KategoriId);
                guncelle.Parameters.AddWithValue("@p3", masa.Aktiflik);
                guncelle.Parameters.AddWithValue("@p4", masa.Id);

                guncelle.ExecuteNonQuery();
                connection.Close();
                return "Güncellendi";
            }
            catch (Exception ex)
            {
                return ex.ToString();
            }
        }
        public string deleteMasa(int id)
        {
            bool isConnected = Connect();
            if (!isConnected)
                return "DB Connect Exception";
            try
            {
                string delete = "DELETE FROM tbl_Masalar where id=@p1";
                SqlCommand ekle = new SqlCommand(delete, connection);
                ekle.Parameters.AddWithValue("@p1", id);
                ekle.ExecuteNonQuery();
                connection.Close();
                return "Silindi";
            }
            catch (Exception ex)
            {
                return ex.ToString();
            }
        }
        public string deleteMasaWithCategoryId(int kategoriId)
        {
			bool isConnected = Connect();
			if (!isConnected)
				return "DB Connect Exception";
			try
			{
				string delete = "DELETE FROM tbl_Masalar where kategoriId=@p1";
				SqlCommand ekle = new SqlCommand(delete, connection);
				ekle.Parameters.AddWithValue("@p1", kategoriId);
				ekle.ExecuteNonQuery();
				connection.Close();
				return "Kategoriye ait masalar başarılı bir şekilde silindi.";
			}
			catch
			{
				return "Kategoriye ait masalar silinirken bir hata meydana geldi.";
			}
		}

        // Ürün İşlemleri

        public UrunObject getUrun(int id)
        {
            bool isConnected = Connect();
            string sorgu = "select * from tbl_Urunler where id=@p1";
            SqlCommand command = new SqlCommand(sorgu, connection);
            command.Parameters.AddWithValue("p1", id);
            SqlDataReader reader = command.ExecuteReader();
            UrunObject urun = new UrunObject();

            while (reader.Read())
            {
                urun.Id = reader.GetInt32(0);
                urun.KategoriId = reader.GetInt32(1);
                urun.UrunAdi = reader.GetString(2);
                urun.SatisFiyati = ((float)reader.GetDouble(3));
                urun.ImagePath = reader.GetString(4);
                return urun;
            }
            connection.Close();

            return urun;

        }
        public List<UrunObject> listUrun()
        {
            bool isConnected = Connect();
			List<UrunObject> UrunList = new List<UrunObject>();
			if (!isConnected)
				return UrunList;


            string sorgu = "select * from tbl_Urunler";
            SqlCommand command = new SqlCommand(sorgu, connection);
            SqlDataReader reader = command.ExecuteReader();
            while (reader.Read())
            {
                UrunObject urun = new UrunObject();
                urun.Id = reader.GetInt32(0);
                urun.KategoriId = reader.GetInt32(1);
                urun.UrunAdi = reader.GetString(2);
                urun.SatisFiyati = float.Parse(reader.GetValue(3).ToString());
                urun.ImagePath = reader.GetString(4);
                UrunList.Add(urun);
            }
            connection.Close();

            return UrunList;
        }
        public List<UrunObject> listUrunWithCategory(int kategoriId)
        {
            bool isConnected = Connect();
            List<UrunObject> UrunList = new List<UrunObject>();

            string sorgu = "select * from tbl_Urunler where kategoriId = @p1";
            SqlCommand command = new SqlCommand(sorgu, connection);
            command.Parameters.AddWithValue("@p1", kategoriId);

            SqlDataReader reader = command.ExecuteReader();
            while (reader.Read())
            {
                UrunObject urun = new UrunObject();
                urun.Id = reader.GetInt32(0);
                urun.KategoriId = reader.GetInt32(1);
                urun.UrunAdi = reader.GetString(2);
				urun.SatisFiyati = ((float)reader.GetDouble(3));
				urun.ImagePath = reader.GetString(4);
				UrunList.Add(urun);
            }
            connection.Close();
            return UrunList;
        }
        public string insertUrun(UrunObject urun)
        {
            bool isConnected = Connect();
            if (!isConnected)
                return "DB Connect Exception";

            try
            {
                string kayit = "insert into tbl_Urunler (kategoriId,urunAdi,satisFiyati,imagePath) values (@p1,@p2,@p3,@p4)";
                SqlCommand ekle = new SqlCommand(kayit, connection);
                ekle.Parameters.AddWithValue("@p1", urun.KategoriId);
                ekle.Parameters.AddWithValue("@p2", urun.UrunAdi);
                ekle.Parameters.AddWithValue("@p3", urun.SatisFiyati);
                ekle.Parameters.AddWithValue("@p4", urun.ImagePath);
                ekle.ExecuteNonQuery();
                connection.Close();
                return "Ürün kaydetme işlemi başarılı.";
            }
            catch 
            {

                return "Ürün kaydedilirken bir hata meydana geldi.";
            }
        }
        public string updateUrun(UrunObject urun)
        {
            bool isConnected = Connect();
            if (!isConnected)
                return "DB Connect Exception";
            try
            {
                string update = "update tbl_Urunler set kategoriId=@p1, urunAdi=@p2, satisFiyati=@p3 , imagePath = @p4 where id=@p5";
                SqlCommand guncelle = new SqlCommand(update, connection);
                guncelle.Parameters.AddWithValue("@p1", urun.KategoriId);
                guncelle.Parameters.AddWithValue("@p2", urun.UrunAdi);
                guncelle.Parameters.AddWithValue("@p3", urun.SatisFiyati);
                guncelle.Parameters.AddWithValue("@p4", urun.ImagePath);
                guncelle.Parameters.AddWithValue("@p5", urun.Id);

                guncelle.ExecuteNonQuery();
                connection.Close();
                return "Ürün güncelleme işlemi başarılı.";
            }
            catch 
            {
                return "Ürün güncelleme işlemi sırasında bir hata meydana geldi.";
            }
        }
        public string deleteUrun(int id)
        {
            bool isConnected = Connect();
            if (!isConnected)
                return "DB Connect Exception";
            try
            {
                string delete = "DELETE FROM tbl_Urunler where id=@p1";
                SqlCommand ekle = new SqlCommand(delete, connection);
                ekle.Parameters.AddWithValue("@p1", id);
                ekle.ExecuteNonQuery();
                connection.Close();
                return "Ürün silme işlemi başarılı.";
            }
            catch 
            {
                return "Ürün silme işlemi sırasında bir hata meydana geldi.";
            }
        }

        // Ürün Kategori İşlemleri

        public UrunKategoriObject getUrunKategori(int id)
        {
            bool isConnected = Connect();
            string sorgu = "select * from tbl_UrunKategori where id=@p1";
            SqlCommand command = new SqlCommand(sorgu, connection);
            command.Parameters.AddWithValue("p1", id);
            SqlDataReader reader = command.ExecuteReader();
            UrunKategoriObject urunKategori = new UrunKategoriObject();

            while (reader.Read())
            {
                urunKategori.Id = reader.GetInt32(0);
                urunKategori.KategoriAdi = reader.GetString(1);
                urunKategori.Aktiflik = reader.GetBoolean(2);
                return urunKategori;
            }
            connection.Close();

            return urunKategori;

        }
		public UrunKategoriObject getUrunKategoriFromName(string name)
		{
			bool isConnected = Connect();
			string sorgu = "select * from tbl_UrunKategori where kategoriAdi=@p1";
			SqlCommand command = new SqlCommand(sorgu, connection);
			command.Parameters.AddWithValue("p1", name);
			SqlDataReader reader = command.ExecuteReader();
			UrunKategoriObject urunKategori = new UrunKategoriObject();

			while (reader.Read())
			{
				urunKategori.Id = reader.GetInt32(0);
				urunKategori.KategoriAdi = reader.GetString(1);
                urunKategori.Aktiflik = reader.GetBoolean(2);
				return urunKategori;
			}
			connection.Close();

			return urunKategori;

		}

		public List<UrunKategoriObject> listUrunKategori()
        {
            bool isConnected = Connect();
            List<UrunKategoriObject> UrunKategoriList = new List<UrunKategoriObject>();

            string sorgu = "select * from tbl_UrunKategori";
            SqlCommand command = new SqlCommand(sorgu, connection);
            SqlDataReader reader = command.ExecuteReader();
            while (reader.Read())
            {
                UrunKategoriObject urunKategori = new UrunKategoriObject();
                urunKategori.Id = reader.GetInt32(0);
                urunKategori.KategoriAdi = reader.GetString(1);
                urunKategori.Aktiflik = reader.GetBoolean(2);
                UrunKategoriList.Add(urunKategori);
            }
            connection.Close();

            return UrunKategoriList;
        }
        public string insertUrunKategori(UrunKategoriObject urunKategori)
        {
            bool isConnected = Connect();
            if (!isConnected)
                return "DB Connect Exception";

            try
            {
                string kayit = "insert into tbl_UrunKategori (kategoriAdi,aktiflik) values (@p1,@p2)";
                SqlCommand ekle = new SqlCommand(kayit, connection);
                ekle.Parameters.AddWithValue("@p1", urunKategori.KategoriAdi);
                ekle.Parameters.AddWithValue("@p2", urunKategori.Aktiflik);
                ekle.ExecuteNonQuery();
                connection.Close();
                return "Ürün kategorisi ekleme işlemi başarılı.";
            }
            catch
            {
                return "Ürün kategorisi ekleme işlemi sırasında bir hata meydana geldi.";
            }
        }
        public string updateUrunKategori(UrunKategoriObject urunKategori)
        {
            bool isConnected = Connect();
            if (!isConnected)
                return "DB Connect Exception";
            try
            {
                string update = "update tbl_UrunKategori set kategoriAdi=@p1, aktiflik=@p2 where id=@p3";
                SqlCommand guncelle = new SqlCommand(update, connection);
                guncelle.Parameters.AddWithValue("@p1", urunKategori.KategoriAdi);
                guncelle.Parameters.AddWithValue("@p2", urunKategori.Aktiflik);
                guncelle.Parameters.AddWithValue("@p3", urunKategori.Id);

                guncelle.ExecuteNonQuery();
                connection.Close();
                return "Ürün kategorisi güncelleme işlemi başarılı.";
            }
            catch
            {
                return "Ürün kategorisi güncelleme işlemi sırasında bir hata meydana geldi.";
            }
        }
        public string deleteUrunKategori(int id)
        {
            bool isConnected = Connect();
            if (!isConnected)
                return "DB Connect Exception";
            try
            {
                string delete = "DELETE FROM tbl_UrunKategori where id=@p1";
                SqlCommand ekle = new SqlCommand(delete, connection);
                ekle.Parameters.AddWithValue("@p1", id);
                ekle.ExecuteNonQuery();
                connection.Close();
                return "Ürün kategorisi başarılı bir şekilde silindi.";
            }
            catch
            {
                return "Ürün kategorisi silme işlemi sırasında bir hata meydana geldi.";
            }
        }

        // Restoran İşlemleri

        public RestoranObject getRestoranBilgileri()
        {
            RestoranObject restoran = new RestoranObject();

            try
            {
                bool isConnected = Connect();
                string sorgu = "select * from tbl_RestoranBilgileri";
                SqlCommand command = new SqlCommand(sorgu, connection);
                SqlDataReader reader = command.ExecuteReader();

                while (reader.Read())
                {
                    restoran.Id = reader.GetInt32(0);
                    restoran.RestoranAdi = reader.GetString(1);
                    restoran.RestoranTelefonNumarasi = reader.GetString(2);
                    restoran.RestoranYoneticiId = reader.GetInt32(3);
                    return restoran;
                }
                connection.Close();
                return restoran;
            }
            catch 
            {
                return restoran;
            }
            

        }
        public string updateRestoran(RestoranObject restoran)
        {
            bool isConnected = Connect();
            if (!isConnected)
                return "DB Connect Exception";
            try
            {
                string update = "update tbl_RestoranBilgileri set restoranAdi=@p1, restoranTelefonNumarasi=@p2,restoranYoneticiId=@p3";
                SqlCommand guncelle = new SqlCommand(update, connection);
                guncelle.Parameters.AddWithValue("@p1", restoran.RestoranAdi);
                guncelle.Parameters.AddWithValue("@p2", restoran.RestoranTelefonNumarasi);
                guncelle.Parameters.AddWithValue("@p3", restoran.RestoranYoneticiId);

                guncelle.ExecuteNonQuery();
                connection.Close();
                return "Restoran bilgileri başarılı bir şekilde güncellendi.";
            }
            catch
            {
                return "Restoran bilgileri güncellenirken bir hata meydana geldi.";
            }
        }

        // KULLANICI İşlemleri

        public KullaniciObject getKullanici(int id)
        {
            bool isConnected = Connect();
            string sorgu = "select * from tbl_Kullanicilar where id=@p1";
            SqlCommand command = new SqlCommand(sorgu, connection);
            command.Parameters.AddWithValue("p1", id);
            SqlDataReader reader = command.ExecuteReader();
            KullaniciObject kullanici = new KullaniciObject();

            while (reader.Read())
            {
                kullanici.Id = reader.GetInt32(0);
                kullanici.KullaniciAdi = reader.GetString(1);
                kullanici.KullaniciTelefonNumarasi = reader.GetString(2);
                kullanici.KullaniciAdresi = reader.GetString(3);
                kullanici.KullaniciIban = reader.GetString(4);
                kullanici.KullaniciMaasi = reader.GetInt32(5);
                kullanici.YetkiId = reader.GetInt32(6);
                return kullanici;
            }
            connection.Close();

            return kullanici;

        }
        public KullaniciObject getKullaniciFromName(string name)
        {
            bool isConnected = Connect();
            string sorgu = "select * from tbl_Kullanicilar where kullaniciAdi=@p1";
            SqlCommand command = new SqlCommand(sorgu, connection);
            command.Parameters.AddWithValue("p1", name);
            SqlDataReader reader = command.ExecuteReader();
            KullaniciObject kullanici = new KullaniciObject();

            while (reader.Read())
            {
                kullanici.Id = reader.GetInt32(0);
                kullanici.KullaniciAdi = reader.GetString(1);
                kullanici.KullaniciTelefonNumarasi = reader.GetString(2);
                kullanici.KullaniciAdresi = reader.GetString(3);
                kullanici.KullaniciIban = reader.GetString(4);
                kullanici.KullaniciMaasi = reader.GetInt32(5);
                kullanici.YetkiId = reader.GetInt32(6);
                return kullanici;
            }
            connection.Close();

            return kullanici;

        }
        public List<KullaniciObject> listKullanicilar()
        {
            bool isConnected = Connect();
            List<KullaniciObject> KullaniciList = new List<KullaniciObject>();

            string sorgu = "select * from tbl_Kullanicilar";
            SqlCommand command = new SqlCommand(sorgu, connection);
            SqlDataReader reader = command.ExecuteReader();
            while (reader.Read())
            {
                KullaniciObject kullanici = new KullaniciObject();
                kullanici.Id = reader.GetInt32(0);
                kullanici.KullaniciAdi = reader.GetString(1);
                kullanici.KullaniciTelefonNumarasi = reader.GetString(2);
                kullanici.KullaniciAdresi = reader.GetString(3);
                kullanici.KullaniciIban = reader.GetString(4);
                kullanici.KullaniciMaasi = reader.GetInt32(5);
                kullanici.YetkiId = reader.GetInt32(6);
                KullaniciList.Add(kullanici);
            }
            connection.Close();

            return KullaniciList;
        }
        public string insertKullanici(KullaniciObject kullanici)
        {
            bool isConnected = Connect();
            if (!isConnected)
                return "DB Connect Exception";

            try
            {
                string kayit = "insert into tbl_Kullanicilar (kullaniciAdi,kullaniciTelefonNumarasi,kullaniciAdresi,kullaniciIban,kullaniciMaasi,yetkiId) values (@p1,@p2,@p3,@p4,@p5,@p6)";
                SqlCommand ekle = new SqlCommand(kayit, connection);
                ekle.Parameters.AddWithValue("@p1", kullanici.KullaniciAdi);
                ekle.Parameters.AddWithValue("@p2", kullanici.KullaniciTelefonNumarasi);
                ekle.Parameters.AddWithValue("@p3", kullanici.KullaniciAdresi);
                ekle.Parameters.AddWithValue("@p4", kullanici.KullaniciIban);
                ekle.Parameters.AddWithValue("@p5", kullanici.KullaniciMaasi);
                ekle.Parameters.AddWithValue("@p6", kullanici.YetkiId);
                ekle.ExecuteNonQuery();
                connection.Close();
                return "Kullanıcı Başarılı bir şekilde kaydedildi.";
            }
            catch(Exception ex)
            {
                return ex.ToString();
                //return "Kullanıcı ekleme işlemi sırasında bir hata meydana geldi";
            }
        }
        public string updateKullanici(KullaniciObject kullanici)
        {
            bool isConnected = Connect();
            if (!isConnected)
                return "DB Connect Exception";
            try
            {
                string update = "update tbl_Kullanicilar set kullaniciAdi=@p1, kullaniciTelefonNumarasi=@p2, kullaniciAdresi=@p3,kullaniciIban=@p4,kullaniciMaasi=@p5,yetkiId=@p6 where id=@p7";
                SqlCommand guncelle = new SqlCommand(update, connection);
                guncelle.Parameters.AddWithValue("@p1", kullanici.KullaniciAdi);
                guncelle.Parameters.AddWithValue("@p2", kullanici.KullaniciTelefonNumarasi);
                guncelle.Parameters.AddWithValue("@p3", kullanici.KullaniciAdresi);
                guncelle.Parameters.AddWithValue("@p4", kullanici.KullaniciIban);
                guncelle.Parameters.AddWithValue("@p5", kullanici.KullaniciMaasi);
                guncelle.Parameters.AddWithValue("@p6", kullanici.YetkiId);
                guncelle.Parameters.AddWithValue("@p7", kullanici.Id);

                guncelle.ExecuteNonQuery();
                connection.Close();
                return "Kullanıcı başarılı bir şekilde güncellendi.";
            }
            catch 
            {
                return "Kullanıcı güncelleme işlemi sırasında bir hata meydana geldi";
            }
        }
        public string deleteKullanici(int id)
        {
            bool isConnected = Connect();
            if (!isConnected)
                return "DB Connect Exception";
            try
            {
                string delete = "DELETE FROM tbl_Kullanicilar where id=@p1";
                SqlCommand ekle = new SqlCommand(delete, connection);
                ekle.Parameters.AddWithValue("@p1", id);
                ekle.ExecuteNonQuery();
                connection.Close();
                return "Kullanıcı başarılı bir şekilde silindi.";
            }
            catch 
            {
                return "Kullanıcı silme işlemi sırasında bir hata meydana geldi.";
            }
        }

        // YETKİ İşlemleri

        public YetkiObject getYetki(int id)
        {
            bool isConnected = Connect();
            string sorgu = "select * from tbl_Yetkiler where id=@p1";
            SqlCommand command = new SqlCommand(sorgu, connection);
            command.Parameters.AddWithValue("p1", id);
            SqlDataReader reader = command.ExecuteReader();
            YetkiObject yetki = new YetkiObject();

            while (reader.Read())
            {
                yetki.Id = reader.GetInt32(0);
                yetki.YetkiAdi = reader.GetString(1);
                yetki.AyarErisim = reader.GetBoolean(2);
                yetki.EklemeGuncelleme = reader.GetBoolean(3);
                yetki.YapilacaklarListesineEkleme = reader.GetBoolean(4);
                yetki.YapilacaklarListesindenSilme = reader.GetBoolean(5);
                yetki.SiparisIptalEtme = reader.GetBoolean(6);
                yetki.BayiGoruntuleme = reader.GetBoolean(7);
                yetki.RaporGoruntuleme = reader.GetBoolean(8);
                yetki.Telegram = reader.GetBoolean(9);
                yetki.ModulDuzenleme = reader.GetBoolean(10);
                yetki.UrunYonetimi = reader.GetBoolean(11);
                return yetki;
            }
            connection.Close();

            return yetki;

        }
        public YetkiObject getYetkiFromName(string name)
        {
            bool isConnected = Connect();
            string sorgu = "select * from tbl_Yetkiler where yetkiAdi=@p1";
            SqlCommand command = new SqlCommand(sorgu, connection);
            command.Parameters.AddWithValue("p1", name);
            SqlDataReader reader = command.ExecuteReader();
            YetkiObject yetki = new YetkiObject();

            while (reader.Read())
            {
                yetki.Id = reader.GetInt32(0);
                yetki.YetkiAdi = reader.GetString(1);
                yetki.AyarErisim = reader.GetBoolean(2);
                yetki.EklemeGuncelleme = reader.GetBoolean(3);
                yetki.YapilacaklarListesineEkleme = reader.GetBoolean(4);
                yetki.YapilacaklarListesindenSilme = reader.GetBoolean(5);
                yetki.SiparisIptalEtme = reader.GetBoolean(6);
                yetki.BayiGoruntuleme = reader.GetBoolean(7);
                yetki.RaporGoruntuleme = reader.GetBoolean(8);
                yetki.Telegram = reader.GetBoolean(9);
                yetki.ModulDuzenleme = reader.GetBoolean(10);
                yetki.UrunYonetimi = reader.GetBoolean(11);
                return yetki;
            }
            connection.Close();

            return yetki;

        }
        public List<YetkiObject> listYetkiler()
        {
            bool isConnected = Connect();
            List<YetkiObject> yetkiList = new List<YetkiObject>();

            string sorgu = "select * from tbl_Yetkiler";
            SqlCommand command = new SqlCommand(sorgu, connection);
            SqlDataReader reader = command.ExecuteReader();
            while (reader.Read())
            {
                YetkiObject yetki = new YetkiObject();
                yetki.Id = reader.GetInt32(0);
                yetki.YetkiAdi = reader.GetString(1);
                yetki.AyarErisim = reader.GetBoolean(2);
                yetki.EklemeGuncelleme = reader.GetBoolean(3);
                yetki.YapilacaklarListesineEkleme = reader.GetBoolean(4);
                yetki.YapilacaklarListesindenSilme = reader.GetBoolean(5);
                yetki.SiparisIptalEtme = reader.GetBoolean(6);
                yetki.BayiGoruntuleme = reader.GetBoolean(7);
                yetki.RaporGoruntuleme = reader.GetBoolean(8);
                yetki.Telegram = reader.GetBoolean(9);
                yetki.ModulDuzenleme = reader.GetBoolean(10);
                yetki.UrunYonetimi = reader.GetBoolean(11);
                yetkiList.Add(yetki);
            }
            connection.Close();

            return yetkiList;
        }
        public string insertYetki(YetkiObject yetki)
        {
            bool isConnected = Connect();
            if (!isConnected)
                return "DB Connect Exception";

            try
            {
                string kayit = "insert into tbl_Yetkiler (yetkiAdi,ayarErisim,eklemeGuncelleme, yapilacaklarListesineEkleme,yapilacaklarListesindenSilme,siparisIptalEtme,bayiGoruntuleme,raporGoruntuleme,telegram,modulDuzenleme,urunYonetimi) values (@p1,@p2,@p3,@p4,@p5,@p6,@p7,@p8,@p9,@p10,@p11)";
                SqlCommand ekle = new SqlCommand(kayit, connection);
                ekle.Parameters.AddWithValue("@p1", yetki.YetkiAdi);
                ekle.Parameters.AddWithValue("@p2", yetki.AyarErisim);
                ekle.Parameters.AddWithValue("@p3", yetki.EklemeGuncelleme);
                ekle.Parameters.AddWithValue("@p4", yetki.YapilacaklarListesineEkleme);
                ekle.Parameters.AddWithValue("@p5", yetki.YapilacaklarListesindenSilme);
                ekle.Parameters.AddWithValue("@p6", yetki.SiparisIptalEtme);
                ekle.Parameters.AddWithValue("@p7", yetki.BayiGoruntuleme);
                ekle.Parameters.AddWithValue("@p8", yetki.RaporGoruntuleme);
                ekle.Parameters.AddWithValue("@p9", yetki.Telegram);
                ekle.Parameters.AddWithValue("@p10", yetki.ModulDuzenleme);
                ekle.Parameters.AddWithValue("@p11", yetki.UrunYonetimi);
                ekle.ExecuteNonQuery();
                connection.Close();
                return "Yetki başarılı bir şekilde kaydedildi.";
            }
            catch
            {
                return "Yetki ekleme işlemi sırasında bir hata meydana geldi";
            }
        }
        public string updateYetki(YetkiObject yetki)
        {
            bool isConnected = Connect();
            if (!isConnected)
                return "DB Connect Exception";
            try
            {
                string update = "update tbl_Yetkiler set yetkiAdi=@p1,ayarErisim=@p2,eklemeGuncelleme=@p3,yapilacaklarListesineEkleme=@p4,yapilacaklarListesindenSilme=@p5,siparisIptalEtme=@p6,bayiGoruntuleme=@p7,raporGoruntuleme=@p8,telegram=@p9,modulDuzenleme=@p10,urunYonetimi=@p11 where id=@p12";
                SqlCommand guncelle = new SqlCommand(update, connection);
                guncelle.Parameters.AddWithValue("@p1", yetki.YetkiAdi);
                guncelle.Parameters.AddWithValue("@p2", yetki.AyarErisim);
                guncelle.Parameters.AddWithValue("@p3", yetki.EklemeGuncelleme);
                guncelle.Parameters.AddWithValue("@p4", yetki.YapilacaklarListesineEkleme);
                guncelle.Parameters.AddWithValue("@p5", yetki.YapilacaklarListesindenSilme);
                guncelle.Parameters.AddWithValue("@p6", yetki.SiparisIptalEtme);
                guncelle.Parameters.AddWithValue("@p7", yetki.BayiGoruntuleme);
                guncelle.Parameters.AddWithValue("@p8", yetki.RaporGoruntuleme);
                guncelle.Parameters.AddWithValue("@p9", yetki.Telegram);
                guncelle.Parameters.AddWithValue("@p10", yetki.ModulDuzenleme);
                guncelle.Parameters.AddWithValue("@p11", yetki.UrunYonetimi);
                guncelle.Parameters.AddWithValue("@p12", yetki.Id);

                guncelle.ExecuteNonQuery();
                connection.Close();
                return "Yetki başarılı bir şekilde güncellendi.";
            }
            catch
            {
                return "Yetki güncelleme işlemi sırasında bir hata meydana geldi";
            }
        }
        public string deleteYetki(int id)
        {
            bool isConnected = Connect();
            if (!isConnected)
                return "DB Connect Exception";
            try
            {
                string delete = "DELETE FROM tbl_Yetkiler where id=@p1";
                SqlCommand ekle = new SqlCommand(delete, connection);
                ekle.Parameters.AddWithValue("@p1", id);
                ekle.ExecuteNonQuery();
                connection.Close();
                return "Yetki başarılı bir şekilde silindi.";
            }
            catch
            {
                return "Yetki silme işlemi sırasında bir hata meydana geldi.";
            }
        }

        // TELEGRAM BOT İşlemleri

        public TelegramBotObject getTelegram(int id)
        {
            bool isConnected = Connect();
            string sorgu = "select * from tbl_TelegramBot where id=@p1";
            SqlCommand command = new SqlCommand(sorgu, connection);
            command.Parameters.AddWithValue("p1", id);
            SqlDataReader reader = command.ExecuteReader();
            TelegramBotObject telegram = new TelegramBotObject();

            while (reader.Read())
            {
                telegram.Id = reader.GetInt32(0);
                telegram.KullaniciId = reader.GetInt32(1);
                telegram.BotKey = reader.GetString(2);
                telegram.ChatId = reader.GetString(3);
                telegram.SiparisBildirim = reader.GetBoolean(4);
                telegram.AlinacaklarListesiBildirim = reader.GetBoolean(5);
                telegram.RezervasyonBildirim = reader.GetBoolean(6);
                telegram.GunlukRaporBildirim = reader.GetBoolean(7);
                telegram.YonetimAyariBildirim = reader.GetBoolean(8);
                telegram.CalisanMaasBildirim = reader.GetBoolean(9);
                telegram.BotAdi = reader.GetString(10);
                telegram.Aktiflik = reader.GetBoolean(11);
                return telegram;
            }
            connection.Close();

            return telegram;

        }
        public TelegramBotObject getTelegramFromName(string name)
        {
            bool isConnected = Connect();
            string sorgu = "select * from tbl_TelegramBot where botAdi=@p1";
            SqlCommand command = new SqlCommand(sorgu, connection);
            command.Parameters.AddWithValue("p1", name);
            SqlDataReader reader = command.ExecuteReader();
            TelegramBotObject telegram = new TelegramBotObject();

            while (reader.Read())
            {
                telegram.Id = reader.GetInt32(0);
                telegram.KullaniciId = reader.GetInt32(1);
                telegram.BotKey = reader.GetString(2);
                telegram.ChatId = reader.GetString(3);
                telegram.SiparisBildirim = reader.GetBoolean(4);
                telegram.AlinacaklarListesiBildirim = reader.GetBoolean(5);
                telegram.RezervasyonBildirim = reader.GetBoolean(6);
                telegram.GunlukRaporBildirim = reader.GetBoolean(7);
                telegram.YonetimAyariBildirim = reader.GetBoolean(8);
                telegram.CalisanMaasBildirim = reader.GetBoolean(9);
                telegram.BotAdi = reader.GetString(10);
                telegram.Aktiflik = reader.GetBoolean(11);

                return telegram;
            }
            connection.Close();

            return telegram;

        }
        public List<TelegramBotObject> listTelegram()
        {
            bool isConnected = Connect();
            List<TelegramBotObject> telegramList = new List<TelegramBotObject>();

            string sorgu = "select * from tbl_TelegramBot";
            SqlCommand command = new SqlCommand(sorgu, connection);
            SqlDataReader reader = command.ExecuteReader();
            while (reader.Read())
            {
                TelegramBotObject telegram = new TelegramBotObject();
                telegram.Id = reader.GetInt32(0);
                telegram.KullaniciId = reader.GetInt32(1);
                telegram.BotKey = reader.GetString(2);
                telegram.ChatId = reader.GetString(3);
                telegram.SiparisBildirim = reader.GetBoolean(4);
                telegram.AlinacaklarListesiBildirim = reader.GetBoolean(5);
                telegram.RezervasyonBildirim = reader.GetBoolean(6);
                telegram.GunlukRaporBildirim = reader.GetBoolean(7);
                telegram.YonetimAyariBildirim = reader.GetBoolean(8);
                telegram.CalisanMaasBildirim = reader.GetBoolean(9);
                telegram.BotAdi = reader.GetString(10);
                telegram.Aktiflik = reader.GetBoolean(11);

                telegramList.Add(telegram);
            }
            connection.Close();

            return telegramList;
        }
        public string insertTelegram(TelegramBotObject telegram)
        {
            bool isConnected = Connect();
            if (!isConnected)
                return "DB Connect Exception";

            try
            {
                string kayit = "insert into tbl_TelegramBot (kullaniciId,botKey,chatId, siparisBildirim,alinacaklarListesiBildirim,rezervasyonBildirim,gunlukRaporBildirim,yonetimAyariBildirim,calisanMaasBildirim,botAdi,aktiflik) values (@p1,@p2,@p3,@p4,@p5,@p6,@p7,@p8,@p9,@p10,@p11)";
                SqlCommand ekle = new SqlCommand(kayit, connection);
                ekle.Parameters.AddWithValue("@p1", telegram.KullaniciId);
                ekle.Parameters.AddWithValue("@p2", telegram.BotKey);
                ekle.Parameters.AddWithValue("@p3", telegram.ChatId);
                ekle.Parameters.AddWithValue("@p4", telegram.SiparisBildirim);
                ekle.Parameters.AddWithValue("@p5", telegram.AlinacaklarListesiBildirim);
                ekle.Parameters.AddWithValue("@p6", telegram.RezervasyonBildirim);
                ekle.Parameters.AddWithValue("@p7", telegram.GunlukRaporBildirim);
                ekle.Parameters.AddWithValue("@p8", telegram.YonetimAyariBildirim);
                ekle.Parameters.AddWithValue("@p9", telegram.CalisanMaasBildirim);
                ekle.Parameters.AddWithValue("@p10", telegram.BotAdi);
                ekle.Parameters.AddWithValue("@p11", telegram.Aktiflik);

                ekle.ExecuteNonQuery();
                connection.Close();
                return "Telegram Bot başarılı bir şekilde kaydedildi.";
            }
            catch
            {
                return "Telegram Bot ekleme işlemi sırasında bir hata meydana geldi";
            }
        }
        public string updateTelegram(TelegramBotObject telegram)
        {
            bool isConnected = Connect();
            if (!isConnected)
                return "DB Connect Exception";
            try
            {
                string update = "update tbl_TelegramBot set kullaniciId=@p1,botKey=@p2,chatId=@p3,siparisBildirim=@p4,alinacaklarListesiBildirim=@p5,rezervasyonBildirim=@p6,gunlukRaporBildirim=@p7,yonetimAyariBildirim=@p8,calisanMaasBildirim=@p9,botAdi=@p10, aktiflik=@p11 where id=@p12";
                SqlCommand guncelle = new SqlCommand(update, connection);
                guncelle.Parameters.AddWithValue("@p1", telegram.KullaniciId);
                guncelle.Parameters.AddWithValue("@p2", telegram.BotKey);
                guncelle.Parameters.AddWithValue("@p3", telegram.ChatId);
                guncelle.Parameters.AddWithValue("@p4", telegram.SiparisBildirim);
                guncelle.Parameters.AddWithValue("@p5", telegram.AlinacaklarListesiBildirim);
                guncelle.Parameters.AddWithValue("@p6", telegram.RezervasyonBildirim);
                guncelle.Parameters.AddWithValue("@p7", telegram.GunlukRaporBildirim);
                guncelle.Parameters.AddWithValue("@p8", telegram.YonetimAyariBildirim);
                guncelle.Parameters.AddWithValue("@p9", telegram.CalisanMaasBildirim);
                guncelle.Parameters.AddWithValue("@p10", telegram.BotAdi);
                guncelle.Parameters.AddWithValue("@p11", telegram.Aktiflik);
                guncelle.Parameters.AddWithValue("@p12", telegram.Id);

                guncelle.ExecuteNonQuery();
                connection.Close();
                return "Telegram Bot başarılı bir şekilde güncellendi.";
            }
            catch
            {
                return "Telegram Bot güncelleme işlemi sırasında bir hata meydana geldi";
            }
        }
        public string deleteTelegram(int id)
        {
            bool isConnected = Connect();
            if (!isConnected)
                return "DB Connect Exception";
            try
            {
                string delete = "DELETE FROM tbl_TelegramBot where id=@p1";
                SqlCommand ekle = new SqlCommand(delete, connection);
                ekle.Parameters.AddWithValue("@p1", id);
                ekle.ExecuteNonQuery();
                connection.Close();
                return "Telegram Bot başarılı bir şekilde silindi.";
            }
            catch
            {
                return "Telegram Bot silme işlemi sırasında bir hata meydana geldi.";
            }
        }

        // BAYİ İşlemleri

        public BayiObject getBayi(int id)
        {
            bool isConnected = Connect();
            string sorgu = "select * from tbl_Bayiler where id=@p1";
            SqlCommand command = new SqlCommand(sorgu, connection);
            command.Parameters.AddWithValue("p1", id);
            SqlDataReader reader = command.ExecuteReader();
            BayiObject bayi = new BayiObject();

            while (reader.Read())
            {
                bayi.Id = reader.GetInt32(0);
                bayi.BayiAdi = reader.GetString(1);
                bayi.BayiAdresi = reader.GetString(2);
                bayi.TelefonNo = reader.GetString(3);
                bayi.YoneticiId = reader.GetInt32(4);
                return bayi;
            }
            connection.Close();

            return bayi;

        }
        public BayiObject getBayiFromName(string name)
        {
            bool isConnected = Connect();
            string sorgu = "select * from tbl_Bayiler where bayiAdi=@p1";
            SqlCommand command = new SqlCommand(sorgu, connection);
            command.Parameters.AddWithValue("p1", name);
            SqlDataReader reader = command.ExecuteReader();
            BayiObject bayi = new BayiObject();

            while (reader.Read())
            {
                bayi.Id = reader.GetInt32(0);
                bayi.BayiAdi = reader.GetString(1);
                bayi.BayiAdresi = reader.GetString(2);
                bayi.TelefonNo = reader.GetString(3);
                bayi.YoneticiId = reader.GetInt32(4);

                return bayi;
            }
            connection.Close();

            return bayi;

        }
        public List<BayiObject> listBayiler()
        {
            bool isConnected = Connect();
            List<BayiObject> bayiList = new List<BayiObject>();

            string sorgu = "select * from tbl_Bayiler";
            SqlCommand command = new SqlCommand(sorgu, connection);
            SqlDataReader reader = command.ExecuteReader();
            while (reader.Read())
            {
                BayiObject bayi = new BayiObject();
                bayi.Id = reader.GetInt32(0);
                bayi.BayiAdi = reader.GetString(1);
                bayi.BayiAdresi = reader.GetString(2);
                bayi.TelefonNo = reader.GetString(3);
                bayi.YoneticiId = reader.GetInt32(4);

                bayiList.Add(bayi);
            }
            connection.Close();

            return bayiList;
        }
        public string insertBayi(BayiObject bayi)
        {
            bool isConnected = Connect();
            if (!isConnected)
                return "DB Connect Exception";

            try
            {
                string kayit = "insert into tbl_Bayiler (bayiAdi,bayiAdresi,telefonNo,yoneticiId) values (@p1,@p2,@p3,@p4)";
                SqlCommand ekle = new SqlCommand(kayit, connection);
                ekle.Parameters.AddWithValue("@p1", bayi.BayiAdi);
                ekle.Parameters.AddWithValue("@p2", bayi.BayiAdresi);
                ekle.Parameters.AddWithValue("@p3", bayi.TelefonNo);
                ekle.Parameters.AddWithValue("@p4", bayi.YoneticiId);

                ekle.ExecuteNonQuery();
                connection.Close();
                return "Bayi başarılı bir şekilde kaydedildi.";
            }
            catch
            {
                return "Bayi ekleme işlemi sırasında bir hata meydana geldi";
            }
        }
        public string updateBayi(BayiObject bayi)
        {
            bool isConnected = Connect();
            if (!isConnected)
                return "DB Connect Exception";
            try
            {
                string update = "update tbl_Bayiler set bayiAdi=@p1,bayiAdresi=@p2,telefonNo=@p3,yoneticiId=@p4 where id=@p5";
                SqlCommand guncelle = new SqlCommand(update, connection);
                guncelle.Parameters.AddWithValue("@p1", bayi.BayiAdi);
                guncelle.Parameters.AddWithValue("@p2", bayi.BayiAdresi);
                guncelle.Parameters.AddWithValue("@p3", bayi.TelefonNo);
                guncelle.Parameters.AddWithValue("@p4", bayi.YoneticiId);
                guncelle.Parameters.AddWithValue("@p5", bayi.Id);

                guncelle.ExecuteNonQuery();
                connection.Close();
                return "Bayi başarılı bir şekilde güncellendi.";
            }
            catch
            {
                return "Bayi güncelleme işlemi sırasında bir hata meydana geldi";
            }
        }
        public string deleteBayi(int id)
        {
            bool isConnected = Connect();
            if (!isConnected)
                return "DB Connect Exception";
            try
            {
                string delete = "DELETE FROM tbl_Bayiler where id=@p1";
                SqlCommand ekle = new SqlCommand(delete, connection);
                ekle.Parameters.AddWithValue("@p1", id);
                ekle.ExecuteNonQuery();
                connection.Close();
                return "Bayi başarılı bir şekilde silindi.";
            }
            catch
            {
                return "Bayi silme işlemi sırasında bir hata meydana geldi.";
            }
        }

        // MODÜL İŞLEMLERİ
        public ModulObject getModulFromName(string name)
        {
            bool isConnected = Connect();
            string sorgu = "select * from tbl_Moduller where modulAdi=@p1";
            SqlCommand command = new SqlCommand(sorgu, connection);
            command.Parameters.AddWithValue("p1", name);
            SqlDataReader reader = command.ExecuteReader();
            ModulObject modul = new ModulObject();

            while (reader.Read())
            {
                modul.Id = reader.GetInt32(0);
                modul.ModulAdi = reader.GetString(1);
                modul.ModulKey = reader.GetString(2);
                modul.Aktiflik = reader.GetBoolean(3);
                return modul;
            }
            connection.Close();
            return modul;
        }
        public string updateModul(ModulObject modul)
        {
            bool isConnected = Connect();
            if (!isConnected)
                return "DB Connect Exception";
            try
            {
                string update = "update tbl_Moduller set modulKey=@p1,aktiflik=@p2 where modulAdi=@p3";
                SqlCommand guncelle = new SqlCommand(update, connection);
                guncelle.Parameters.AddWithValue("@p1", modul.ModulKey);
                guncelle.Parameters.AddWithValue("@p2", modul.Aktiflik);
                guncelle.Parameters.AddWithValue("@p3", modul.ModulAdi);
                guncelle.ExecuteNonQuery();
                connection.Close();
                return "Modül başarılı bir şekilde güncellendi.";
            }
            catch
            {
                return "Modül güncelleme işlemi sırasında bir hata meydana geldi";
            }
        }

		// ADİSYON İŞLEMLERİ
		public AdisyonObject getAdisyon(int id)
		{
			bool isConnected = Connect();
			string sorgu = "select * from tbl_Adisyon where id=@p1";
			SqlCommand command = new SqlCommand(sorgu, connection);
			command.Parameters.AddWithValue("p1", id);
			SqlDataReader reader = command.ExecuteReader();
			AdisyonObject adisyon = new AdisyonObject();

			while (reader.Read())
			{
				adisyon.Id = reader.GetInt32(0);
				adisyon.RezervasyonId = reader.GetInt32(1);
				adisyon.MasaId = reader.GetInt32(2);
				adisyon.OlusturmaTarihi = reader.GetDateTime(3);
				adisyon.OdenmeTarihi = reader.GetDateTime(4);
				adisyon.OdenmeDurumu = reader.GetBoolean(5);
				return adisyon;
			}
			connection.Close();

			return adisyon;

		}
		public AdisyonObject getAdisyonFromMasaId(int masaId)
		{
			bool isConnected = Connect();
			string sorgu = "select * from tbl_Adisyon where masaId=@p1";
			SqlCommand command = new SqlCommand(sorgu, connection);
			command.Parameters.AddWithValue("p1", masaId);
			SqlDataReader reader = command.ExecuteReader();
			AdisyonObject adisyon = new AdisyonObject();

			while (reader.Read())
			{
				adisyon.Id = reader.GetInt32(0);
				adisyon.RezervasyonId = reader.GetInt32(1);
				adisyon.MasaId = reader.GetInt32(2);
				adisyon.OlusturmaTarihi = reader.GetDateTime(3);
                try
                {
					adisyon.OdenmeTarihi = reader.GetDateTime(4);

				}
				catch 
                {
                    adisyon.OdenmeTarihi = new DateTime();
				}
				adisyon.OdenmeDurumu = reader.GetBoolean(5);
				return adisyon;
			}
			connection.Close();

			return adisyon;
		}
		public AdisyonObject getAdisyonFromMasaIdWhereIsActive(int masaId)
		{
			bool isConnected = Connect();
			string sorgu = "select * from tbl_Adisyon where masaId=@p1 and odenmeDurumu=@p2 ";
			SqlCommand command = new SqlCommand(sorgu, connection);
			command.Parameters.AddWithValue("p1", masaId);
			command.Parameters.AddWithValue("p2", false);
			SqlDataReader reader = command.ExecuteReader();
			AdisyonObject adisyon = new AdisyonObject();

			while (reader.Read())
			{
                try { adisyon.Id = reader.GetInt32(0); } catch { }
                try { adisyon.RezervasyonId = reader.GetInt32(1); }catch {}
				try { adisyon.MasaId = reader.GetInt32(2); }catch { }
				try { adisyon.OlusturmaTarihi = reader.GetDateTime(3); }catch { }
			    try { adisyon.OdenmeTarihi = reader.GetDateTime(4); }catch { }
                try { adisyon.OdenmeDurumu = reader.GetBoolean(5); }catch { }
				return adisyon;
			}
			connection.Close();

			return adisyon;

		}
		public List<AdisyonObject> listAdisyon()
		{
			bool isConnected = Connect();
			List<AdisyonObject> adisyonList = new List<AdisyonObject>();

			string sorgu = "select * from tbl_Adisyon";
			SqlCommand command = new SqlCommand(sorgu, connection);
			SqlDataReader reader = command.ExecuteReader();
			while (reader.Read())
			{
                AdisyonObject adisyon = new AdisyonObject();
				adisyon.Id = reader.GetInt32(0);
				adisyon.RezervasyonId = reader.GetInt32(1);
				adisyon.MasaId = reader.GetInt32(2);
				adisyon.OlusturmaTarihi = reader.GetDateTime(3);
				adisyon.OdenmeTarihi = reader.GetDateTime(4);
				adisyon.OdenmeDurumu = reader.GetBoolean(5);
				adisyonList.Add(adisyon);
			}
			connection.Close();

			return adisyonList;
		}
		public string insertAdisyon(AdisyonObject adisyon)
		{
			bool isConnected = Connect();
			if (!isConnected)
				return "DB Connect Exception";

			try
			{
				string kayit = "insert into tbl_Adisyon (rezervasyonId,masaId,olusturmaTarihi,odenmeDurumu) values (@p1,@p2,@p3,@p4)";
				SqlCommand ekle = new SqlCommand(kayit, connection);
				ekle.Parameters.AddWithValue("@p1", adisyon.RezervasyonId);
				ekle.Parameters.AddWithValue("@p2", adisyon.MasaId);
				ekle.Parameters.AddWithValue("@p3", adisyon.OlusturmaTarihi);
				ekle.Parameters.AddWithValue("@p4", false);

				ekle.ExecuteNonQuery();
				connection.Close();
				return "Adisyon başarılı bir şekilde kaydedildi.";
			}
			catch(Exception ex)
			{
				return "Adisyon ekleme işlemi sırasında bir hata meydana geldi\n" + ex.ToString();
			}
		}
		public string updateAdisyon(AdisyonObject adisyon)
		{
			bool isConnected = Connect();
			if (!isConnected)
				return "DB Connect Exception";
			try
			{
				string update = "update tbl_Adisyon set rezervasyonId=@p1,masaId=@p2,olusturmaTarihi=@p3,odenmeTarihi=@p4, odenmeDurumu=@p5 where id=@p6";
				SqlCommand guncelle = new SqlCommand(update, connection);
				guncelle.Parameters.AddWithValue("@p1", adisyon.RezervasyonId);
				guncelle.Parameters.AddWithValue("@p2", adisyon.MasaId);
				guncelle.Parameters.AddWithValue("@p3", adisyon.OlusturmaTarihi);
				guncelle.Parameters.AddWithValue("@p4", adisyon.OdenmeTarihi);
				guncelle.Parameters.AddWithValue("@p5", adisyon.OdenmeDurumu);
				guncelle.Parameters.AddWithValue("@p6", adisyon.Id);

				guncelle.ExecuteNonQuery();
				connection.Close();
				return "Adisyon başarılı bir şekilde güncellendi.";
			}
			catch
			{
				return "Adisyon güncelleme işlemi sırasında bir hata meydana geldi";
			}
		}
		public string deleteAdisyon(int id)
		{
			bool isConnected = Connect();
			if (!isConnected)
				return "DB Connect Exception";
			try
			{
				string delete = "DELETE FROM tbl_Adisyon where id=@p1";
				SqlCommand ekle = new SqlCommand(delete, connection);
				ekle.Parameters.AddWithValue("@p1", id);
				ekle.ExecuteNonQuery();
				connection.Close();
				return "Adisyon başarılı bir şekilde silindi.";
			}
			catch
			{
				return "Adisyon silme işlemi sırasında bir hata meydana geldi.";
			}
		}

		// SİPARİŞ İŞLEMLERİ
		public SiparisObject getSiparis(int id)
		{
			bool isConnected = Connect();
			string sorgu = "select * from tbl_Siparis where id=@p1";
			SqlCommand command = new SqlCommand(sorgu, connection);
			command.Parameters.AddWithValue("p1", id);
			SqlDataReader reader = command.ExecuteReader();
			SiparisObject siparis = new SiparisObject();

			while (reader.Read())
			{
				siparis.Id = reader.GetInt32(0);
				siparis.AdisyonId = reader.GetInt32(1);
				siparis.UrunId = reader.GetInt32(2);
				siparis.SiparisAdedi = reader.GetInt32(3);
				try
				{
					siparis.SiparisTutari = (float)reader.GetFloat(4);
				}
				catch
				{
					siparis.SiparisTutari = 0;

				}
				siparis.SiparisTarihi = reader.GetDateTime(5);
				try
				{
					siparis.MutfakTeslimTarihi = reader.GetDateTime(6);

				}
				catch
				{

				}

				siparis.SiparisTeslimDurumu = reader.GetBoolean(7);
				siparis.SiparisOdenmeDurumu = reader.GetBoolean(8);
				return siparis;
			}
			connection.Close();

			return siparis;

		}
		public List<SiparisObject> getSiparisListFromAdisyonId(int adisyonId)
		{
			bool isConnected = Connect();
			List<SiparisObject> siparisList = new List<SiparisObject>();
			if (adisyonId > 0)
            {
				string sorgu = "select * from tbl_Siparis where adisyonId=@p1";
				SqlCommand command = new SqlCommand(sorgu, connection);
				command.Parameters.AddWithValue("p1", adisyonId);
				SqlDataReader reader = command.ExecuteReader();
				while (reader.Read())
				{
					SiparisObject siparis = new SiparisObject();
					siparis.Id = reader.GetInt32(0);
					siparis.AdisyonId = reader.GetInt32(1);
					siparis.UrunId = reader.GetInt32(2);
					siparis.SiparisAdedi = reader.GetInt32(3);
					try
					{
						siparis.SiparisTutari = (float)reader.GetFloat(4);
					}
					catch
					{
						siparis.SiparisTutari = 0;

					}
					siparis.SiparisTarihi = reader.GetDateTime(5);
					try
					{
						siparis.MutfakTeslimTarihi = reader.GetDateTime(6);

					}
					catch
					{

					}

					siparis.SiparisTeslimDurumu = reader.GetBoolean(7);
					siparis.SiparisOdenmeDurumu = reader.GetBoolean(8);
					siparisList.Add(siparis);
				}
				connection.Close();
			}

			return siparisList;
		}
		
		public List<SiparisObject> listSiparisler()
		{
			bool isConnected = Connect();
			List<SiparisObject> siparisList = new List<SiparisObject>();

			string sorgu = "select * from tbl_Siparis where siparisTeslimDurumu = @p1";
			SqlCommand command = new SqlCommand(sorgu, connection);
			command.Parameters.AddWithValue("p1", false);
			SqlDataReader reader = command.ExecuteReader();
			while (reader.Read())
			{
				SiparisObject siparis = new SiparisObject();
				siparis.Id = reader.GetInt32(0);
				siparis.AdisyonId = reader.GetInt32(1);
				siparis.UrunId = reader.GetInt32(2);
				siparis.SiparisAdedi = reader.GetInt32(3);
				try
				{
					siparis.SiparisTutari = (float)reader.GetFloat(4);
				}
				catch
				{
					siparis.SiparisTutari = 0;
				}
				siparis.SiparisTarihi = reader.GetDateTime(5);
				try
				{
					siparis.MutfakTeslimTarihi = reader.GetDateTime(6);

				}
				catch{}
				siparis.SiparisTeslimDurumu = reader.GetBoolean(7);
				siparis.SiparisOdenmeDurumu = reader.GetBoolean(8);
				siparisList.Add(siparis);
			}
			connection.Close();

			return siparisList;
		}
		public string insertSiparis(SiparisObject siparis)
		{
			bool isConnected = Connect();
			if (!isConnected)
				return "DB Connect Exception";

			try
			{
				string kayit = "insert into tbl_Siparis (adisyonId,urunId,siparisAdedi,siparisTutari,siparisTarihi,siparisTeslimDurumu,siparisOdenmeDurumu) values (@p1,@p2,@p3,@p4,@p5,@p6,@p7)";
				SqlCommand ekle = new SqlCommand(kayit, connection);
				ekle.Parameters.AddWithValue("@p1", siparis.AdisyonId);
				ekle.Parameters.AddWithValue("@p2", siparis.UrunId);
				ekle.Parameters.AddWithValue("@p3", siparis.SiparisAdedi);
				ekle.Parameters.AddWithValue("@p4", siparis.SiparisTutari);
				ekle.Parameters.AddWithValue("@p5", siparis.SiparisTarihi);
				ekle.Parameters.AddWithValue("@p6", siparis.SiparisTeslimDurumu);
				ekle.Parameters.AddWithValue("@p7", siparis.SiparisOdenmeDurumu);

				ekle.ExecuteNonQuery();
				connection.Close();
				return "Sipariş başarılı bir şekilde kaydedildi.";
			}
			catch
			{
				return "Sipariş ekleme işlemi sırasında bir hata meydana geldi.";
			}
		}
        public string updateSiparis(SiparisObject siparis)
        {
            bool isConnected = Connect();
            if (!isConnected)
                return "DB Connect Exception";
            //try
            //{

            string update;
            if (siparis.MutfakTeslimTarihi != null)
            {
                update = "update tbl_Siparis set adisyonId=@p1,urunId=@p2,siparisAdedi=@p3,siparisTutari=@p4, siparisTarihi=@p5, mutfakTeslimTarihi = @p6,siparisTeslimDurumu=@p7,siparisOdenmeDurumu=@p8 where id=@p9";
            }
            else
            {
				update = "update tbl_Siparis set adisyonId=@p1,urunId=@p2,siparisAdedi=@p3,siparisTutari=@p4, siparisTarihi=@p5, siparisTeslimDurumu=@p7,siparisOdenmeDurumu=@p8 where id=@p9";
			}
			SqlCommand guncelle = new SqlCommand(update, connection);
            guncelle.Parameters.AddWithValue("@p1", siparis.AdisyonId);
            guncelle.Parameters.AddWithValue("@p2", siparis.UrunId);
            guncelle.Parameters.AddWithValue("@p3", siparis.SiparisAdedi);
            guncelle.Parameters.AddWithValue("@p4", siparis.SiparisTutari);
            guncelle.Parameters.AddWithValue("@p5", siparis.SiparisTarihi);
            if (siparis.MutfakTeslimTarihi != null)
            {
                guncelle.Parameters.AddWithValue("@p6", siparis.MutfakTeslimTarihi);
            }
            guncelle.Parameters.AddWithValue("@p7", siparis.SiparisTeslimDurumu);
            guncelle.Parameters.AddWithValue("@p8", siparis.SiparisOdenmeDurumu);
            guncelle.Parameters.AddWithValue("@p9", siparis.Id);

            guncelle.ExecuteNonQuery();
            connection.Close();
            return "Sipariş başarılı bir şekilde güncellendi.";
            //}
            //catch(Exception ex)
            //{
            //	return "Sipariş güncelleme işlemi sırasında bir hata meydana geldi.\n" + ex.ToString();
            //}
        }
		public string deleteSiparis(int id)
		{
			bool isConnected = Connect();
			if (!isConnected)
				return "DB Connect Exception";
			try
			{
				string delete = "DELETE FROM tbl_Siparis where id=@p1";
				SqlCommand ekle = new SqlCommand(delete, connection);
				ekle.Parameters.AddWithValue("@p1", id);
				ekle.ExecuteNonQuery();
				connection.Close();
				return "Sipariş başarılı bir şekilde silindi.";
			}
			catch
			{
				return "Sipariş silme işlemi sırasında bir hata meydana geldi.";
			}
		}



	}
}
