﻿using System;
using System.Collections.Generic;
using System.Text.RegularExpressions;
using System.Threading.Tasks;
using System.IO;
using System.Xml.Linq;
using System.ComponentModel.DataAnnotations;

namespace RestoranOtomasyon
{
    public class Funcs
    {

        public async Task<List<string>> ListedekiTekrarEdenKayitlariTemizle(List<string> list)
        {
            List<string> list2 = new List<string>();

            try
            {
                foreach (string str in list) {
                    if (!list2.Contains(str) && !string.IsNullOrWhiteSpace(str))
                    {
                        list2.Add(str);
                    }
                }
                return list2;

            }
            catch
            {
                return list2;
            }
        }

        public async Task<bool> isValidMail(string mail)
        {
            bool isValid = new EmailAddressAttribute().IsValid(mail); ;
            if (isValid)
                return true;
            return false;
        }

        public async Task<bool> isMail(string content)
        {
            try
            {
                string _pattern = @"(([\w-]+\.)+[\w-]+|([a-zA-Z]{1}|[\w-]{2,}))@" + @"((([0-1]?[0-9]{1,2}|25[0-5]|2[0-4][0-9])\.([0-1]?[0-9]{1,2}|25[0-5]|2[0-4][0-9])\." + @"([0-1]?[0-9]{1,2}|25[0-5]|2[0-4][0-9])\.([0-1]?[0-9]{1,2}|25[0-5]|2[0-4][0-9])){1}|" + @"([a-zA-Z]+[\w-]+\.)+[a-zA-Z]{2,4})";
                Regex _regExpr = new Regex(_pattern, RegexOptions.IgnoreCase);
                Match _match = _regExpr.Match(content);
                int mail = 0;
                while (_match.Success)
                {
                    mail++;
                    _match = _match.NextMatch();
                }
                if (mail == 0 || mail > 1)
                {
                    return false;
                }
                else
                {
                    return true;
                }
            }
            catch
            {
                return false;
            }
        }

        public async Task<bool> isValidPhoneNumber(string phoneNumber)
        {
            phoneNumber = phoneNumber.Replace(" ", "");
            Regex regex = new Regex(@"^(90|0)?([1-9]{1})(\d{9})$");
            if (regex.IsMatch(phoneNumber))
            {
                return true;
            }
            else
            {
                return false;
            }
        }
        public async Task<string> isValidPassword(string password)
        {
            bool letter = false;
            bool number = false;
            if (password.Length < 8)
            {
                return "Girilen şifre 8 karakter veya daha uzun olmalıdır.";
            }
			foreach (var item in password)
			{
				if (char.IsDigit(item))
					letter = true;
                if (char.IsLetter(item))
					number = true;
                if (letter && number)
                    return null;
			}
            return "Girilen şifrede hem harf hem sayı bulunmalıdır.";
		}
        public async Task<bool> isValidLisanceKey(string licanseKey)
        {
			string pattern = @"^[A-Za-z0-9]{4}-[A-Za-z0-9]{4}-[A-Za-z0-9]{4}-[A-Za-z0-9]{4}$";
			Regex regex = new Regex(pattern);

			// Lisans anahtarını regex ile kontrol et
			if (regex.IsMatch(licanseKey))
			{
				// Anahtarın doğru formatta olduğu durumda, "-" karakterlerini kontrol et
				if (licanseKey[4] == '-' && licanseKey[9] == '-' && licanseKey[14] == '-')
				{
					return true; // Lisans anahtarı geçerli
				}
			}

			return false;
		}

	}
}
