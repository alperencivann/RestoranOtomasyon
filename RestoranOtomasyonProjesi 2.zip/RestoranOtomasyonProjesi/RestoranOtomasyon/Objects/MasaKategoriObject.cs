﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace RestoranOtomasyon.Objects
{

    
    internal class MasaKategoriObject
    {
        private int id;
        private string kategoriAdi;
        private int kategoriMasaSayisi;
        private bool aktiflik;

        public MasaKategoriObject()
        {

        }

        public int Id { get => id; set => id = value; }
        public string KategoriAdi { get => kategoriAdi; set => kategoriAdi = value; }
        public int KategoriMasaSayisi { get => kategoriMasaSayisi; set => kategoriMasaSayisi = value; }
        public bool Aktiflik { get => aktiflik; set => aktiflik = value; }
    }

}
