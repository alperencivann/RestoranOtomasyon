﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace RestoranOtomasyon.Objects
{
    internal class TelegramBotObject
    {
        private int id;
        private int kullaniciId;
        private string botKey;
        private string chatId;
        private bool siparisBildirim;
        private bool alinacaklarListesiBildirim;
        private bool rezervasyonBildirim;
        private bool gunlukRaporBildirim;
        private bool yonetimAyariBildirim;
        private bool calisanMaasBildirim;
        private string botAdi;
        private bool aktiflik;

        public TelegramBotObject()
        {

        }

        public int Id { get => id; set => id = value; }
        public int KullaniciId { get => kullaniciId; set => kullaniciId = value; }
        public string BotKey { get => botKey; set => botKey = value; }
        public string ChatId { get => chatId; set => chatId = value; }
        public bool SiparisBildirim { get => siparisBildirim; set => siparisBildirim = value; }
        public bool AlinacaklarListesiBildirim { get => alinacaklarListesiBildirim; set => alinacaklarListesiBildirim = value; }
        public bool RezervasyonBildirim { get => rezervasyonBildirim; set => rezervasyonBildirim = value; }
        public bool GunlukRaporBildirim { get => gunlukRaporBildirim; set => gunlukRaporBildirim = value; }
        public bool YonetimAyariBildirim { get => yonetimAyariBildirim; set => yonetimAyariBildirim = value; }
        public bool CalisanMaasBildirim { get => calisanMaasBildirim; set => calisanMaasBildirim = value; }
        public string BotAdi { get => botAdi; set => botAdi = value; }
        public bool Aktiflik { get => aktiflik; set => aktiflik = value; }
    }
}
