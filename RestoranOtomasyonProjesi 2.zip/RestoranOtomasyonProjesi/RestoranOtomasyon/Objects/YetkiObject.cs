﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace RestoranOtomasyon.Objects
{
    internal class YetkiObject
    {
        int id;
        string yetkiAdi;

        bool ayarErisim = false;
        bool eklemeGuncelleme = false;
        bool yapilacaklarListesineEkleme = false;
        bool yapilacaklarListesindenSilme = false;
        bool siparisIptalEtme = false;
        bool bayiGoruntuleme = false;
        bool raporGoruntuleme = false;
        bool telegram = false;
        bool modulDuzenleme = false;
        bool urunYonetimi = false;

        public YetkiObject()
        {
        }

        public int Id { get => id; set => id = value; }
        public string YetkiAdi { get => yetkiAdi; set => yetkiAdi = value; }
        public bool AyarErisim { get => ayarErisim; set => ayarErisim = value; }
        public bool EklemeGuncelleme { get => eklemeGuncelleme; set => eklemeGuncelleme = value; }
        public bool YapilacaklarListesineEkleme { get => yapilacaklarListesineEkleme; set => yapilacaklarListesineEkleme = value; }
        public bool YapilacaklarListesindenSilme { get => yapilacaklarListesindenSilme; set => yapilacaklarListesindenSilme = value; }
        public bool SiparisIptalEtme { get => siparisIptalEtme; set => siparisIptalEtme = value; }
        public bool BayiGoruntuleme { get => bayiGoruntuleme; set => bayiGoruntuleme = value; }
        public bool RaporGoruntuleme { get => raporGoruntuleme; set => raporGoruntuleme = value; }
        public bool Telegram { get => telegram; set => telegram = value; }
        public bool ModulDuzenleme { get => modulDuzenleme; set => modulDuzenleme = value; }
        public bool UrunYonetimi { get => urunYonetimi; set => urunYonetimi = value; }
    }
}
