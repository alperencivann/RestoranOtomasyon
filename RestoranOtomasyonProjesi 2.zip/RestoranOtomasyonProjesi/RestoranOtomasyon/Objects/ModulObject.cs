﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace RestoranOtomasyon.Objects
{
    internal class ModulObject
    {
        int id;
        string modulAdi;
        string modulKey;
        bool aktiflik;

        public ModulObject()
        {
        }

        public int Id { get => id; set => id = value; }
        public string ModulAdi { get => modulAdi; set => modulAdi = value; }
        public string ModulKey { get => modulKey; set => modulKey = value; }
        public bool Aktiflik { get => aktiflik; set => aktiflik = value; }
    }
}
