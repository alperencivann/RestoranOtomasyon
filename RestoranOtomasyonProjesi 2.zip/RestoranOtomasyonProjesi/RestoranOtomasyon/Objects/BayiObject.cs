﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace RestoranOtomasyon.Objects
{
    
    internal class BayiObject
    {
        int id;
        string bayiAdi;
        string bayiAdresi;
        string telefonNo;
        int yoneticiId;

        public BayiObject()
        {
        }

        public int Id { get => id; set => id = value; }
        public string BayiAdi { get => bayiAdi; set => bayiAdi = value; }
        public string BayiAdresi { get => bayiAdresi; set => bayiAdresi = value; }
        public string TelefonNo { get => telefonNo; set => telefonNo = value; }
        public int YoneticiId { get => yoneticiId; set => yoneticiId = value; }
    }
}
