﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace RestoranOtomasyon.Objects
{
    internal class KullaniciObject
    {
        int id;
        string kullaniciAdi;
        string kullaniciTelefonNumarasi;
        string kullaniciAdresi;
        string kullaniciIban;
        int kullaniciMaasi;
        int yetkiId;

        public KullaniciObject()
        {
        }

        public int Id { get => id; set => id = value; }
        public string KullaniciAdi { get => kullaniciAdi; set => kullaniciAdi = value; }
        public string KullaniciTelefonNumarasi { get => kullaniciTelefonNumarasi; set => kullaniciTelefonNumarasi = value; }
        public string KullaniciAdresi { get => kullaniciAdresi; set => kullaniciAdresi = value; }
        public string KullaniciIban { get => kullaniciIban; set => kullaniciIban = value; }
        public int KullaniciMaasi { get => kullaniciMaasi; set => kullaniciMaasi = value; }
        public int YetkiId { get => yetkiId; set => yetkiId = value; }
    }
}
