﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace RestoranOtomasyon.Objects
{
    public class RestoranObject
    {
        int id;
        string restoranAdi;
        string restoranTelefonNumarasi;
        int restoranYoneticiId;
        public RestoranObject()
        {
        }

        public int Id { get => id; set => id = value; }
        public string RestoranAdi { get => restoranAdi; set => restoranAdi = value; }
        public string RestoranTelefonNumarasi { get => restoranTelefonNumarasi; set => restoranTelefonNumarasi = value; }
        public int RestoranYoneticiId { get => restoranYoneticiId; set => restoranYoneticiId = value; }
    }
}
