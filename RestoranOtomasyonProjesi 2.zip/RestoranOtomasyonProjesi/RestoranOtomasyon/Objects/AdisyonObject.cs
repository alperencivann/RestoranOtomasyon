﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace RestoranOtomasyon.Objects
{
	internal class AdisyonObject
	{
		int id;
		int rezervasyonId;
		int masaId;
		DateTime? olusturmaTarihi;
		DateTime? odenmeTarihi;
		bool odenmeDurumu;

		public AdisyonObject()
		{
		}

		public int Id { get => id; set => id = value; }
		public int RezervasyonId { get => rezervasyonId; set => rezervasyonId = value; }
		public int MasaId { get => masaId; set => masaId = value; }
		public DateTime? OlusturmaTarihi { get => olusturmaTarihi; set => olusturmaTarihi = value; }
		public DateTime? OdenmeTarihi { get => odenmeTarihi; set => odenmeTarihi = value; }
		public bool OdenmeDurumu { get => odenmeDurumu; set => odenmeDurumu = value; }
	}
}
