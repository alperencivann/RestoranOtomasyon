﻿using RestoranOtomasyon.Forms;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Runtime.CompilerServices;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace RestoranOtomasyon.Components
{
	
	public partial class YonetimUrunKategorisiComp : UserControl
	{
		int kategoriId;
		string kategoriAdi;
		bool aktiflik;
		YonetimUrunYonetimi yonetim;
		public YonetimUrunKategorisiComp(int kategoriId, string kategoriAdi, bool aktiflik, YonetimUrunYonetimi yonetim)
		{
			InitializeComponent();
			this.kategoriId = kategoriId;
			this.kategoriAdi = kategoriAdi;
			this.aktiflik = aktiflik;
			this.yonetim = yonetim;
			txb_KategoriAdi.Text = kategoriAdi;
		}

		private void btn_KategoriDuzenle_Click(object sender, EventArgs e)
		{
			YeniUrunKategorisiEkleDuzenle yeniUrunKategorisiEkleDuzenle = new YeniUrunKategorisiEkleDuzenle(kategoriId,kategoriAdi,aktiflik,yonetim);
			yeniUrunKategorisiEkleDuzenle.ShowDialog();
		}
	}
}
