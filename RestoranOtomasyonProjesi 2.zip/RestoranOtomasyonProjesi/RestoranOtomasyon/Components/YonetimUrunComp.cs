﻿using RestoranOtomasyon.Forms;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace RestoranOtomasyon.Components
{
	public partial class YonetimUrunComp : UserControl
	{
		public int urunId;
		public string urunAdi;
		public YonetimUrunYonetimi yonetimEkrani;
		public YonetimUrunComp(int urunId, string urunAdi, YonetimUrunYonetimi yonetimEkrani)
		{
			InitializeComponent();
			this.urunId = urunId;
			this.urunAdi = urunAdi;
			this.yonetimEkrani = yonetimEkrani;

		}

		private void YonetimUrunComp_Load(object sender, EventArgs e)
		{
			txb_UrunAdi.Text = urunAdi;
		}

		private void btn_YeniKategoriEkle_Click(object sender, EventArgs e)
		{
			YeniUrunEklemeDuzenlemeForm urunForm = new YeniUrunEklemeDuzenlemeForm(this.urunId,yonetimEkrani);
			urunForm.ShowDialog();

		}
	}
}
