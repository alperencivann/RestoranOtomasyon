﻿using RestoranOtomasyon.Forms;
using System.Windows.Forms;

namespace RestoranOtomasyon.Components
{
    public partial class Urun : UserControl
    {
        private int id;
        private int kategoriId;
        private string urunAdi;
        private string urunFiyati;
        private SiparisAl siparis;
        public Urun(int id, int kategoriId, string urunAdi, string urunFiyati, SiparisAl siparis)
        {
            InitializeComponent();
            this.urunAdi = urunAdi;
            this.urunFiyati = urunFiyati;
            this.id = id;
            this.kategoriId = kategoriId;
            this.siparis = siparis;
            lbl_UrunAdi.Text = urunAdi;
            lbl_Fiyat.Text = urunFiyati.ToString() + "₺";
        }
        public void clicked()
        {
            siparis.sepeteEkle(id,urunAdi);
        }
		public void pictureBox1_Click(object sender, System.EventArgs e)
		{
            clicked();
		}

		public void pictureBox1_Click_1(object sender, System.EventArgs e)
		{
			clicked();

		}
	}
}
