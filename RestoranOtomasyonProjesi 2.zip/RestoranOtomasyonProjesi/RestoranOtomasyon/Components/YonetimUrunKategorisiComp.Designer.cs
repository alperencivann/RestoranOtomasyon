﻿namespace RestoranOtomasyon.Components
{
	partial class YonetimUrunKategorisiComp
	{
		/// <summary> 
		/// Required designer variable.
		/// </summary>
		private System.ComponentModel.IContainer components = null;

		/// <summary> 
		/// Clean up any resources being used.
		/// </summary>
		/// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
		protected override void Dispose(bool disposing)
		{
			if (disposing && (components != null))
			{
				components.Dispose();
			}
			base.Dispose(disposing);
		}

		#region Component Designer generated code

		/// <summary> 
		/// Required method for Designer support - do not modify 
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			this.pnl_KullaniciAdi = new System.Windows.Forms.Panel();
			this.btn_KategoriDuzenle = new System.Windows.Forms.Button();
			this.txb_KategoriAdi = new System.Windows.Forms.TextBox();
			this.label5 = new System.Windows.Forms.Label();
			this.pnl_KullaniciAdi.SuspendLayout();
			this.SuspendLayout();
			// 
			// pnl_KullaniciAdi
			// 
			this.pnl_KullaniciAdi.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(29)))), ((int)(((byte)(29)))), ((int)(((byte)(29)))));
			this.pnl_KullaniciAdi.Controls.Add(this.btn_KategoriDuzenle);
			this.pnl_KullaniciAdi.Controls.Add(this.txb_KategoriAdi);
			this.pnl_KullaniciAdi.Controls.Add(this.label5);
			this.pnl_KullaniciAdi.Dock = System.Windows.Forms.DockStyle.Fill;
			this.pnl_KullaniciAdi.Location = new System.Drawing.Point(0, 0);
			this.pnl_KullaniciAdi.Name = "pnl_KullaniciAdi";
			this.pnl_KullaniciAdi.Size = new System.Drawing.Size(706, 34);
			this.pnl_KullaniciAdi.TabIndex = 8;
			// 
			// btn_KategoriDuzenle
			// 
			this.btn_KategoriDuzenle.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
			this.btn_KategoriDuzenle.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(2)))), ((int)(((byte)(117)))), ((int)(((byte)(252)))));
			this.btn_KategoriDuzenle.FlatAppearance.BorderSize = 0;
			this.btn_KategoriDuzenle.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
			this.btn_KategoriDuzenle.Font = new System.Drawing.Font("Century Gothic", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
			this.btn_KategoriDuzenle.ForeColor = System.Drawing.Color.White;
			this.btn_KategoriDuzenle.Location = new System.Drawing.Point(548, 6);
			this.btn_KategoriDuzenle.Name = "btn_KategoriDuzenle";
			this.btn_KategoriDuzenle.Size = new System.Drawing.Size(153, 22);
			this.btn_KategoriDuzenle.TabIndex = 6;
			this.btn_KategoriDuzenle.Text = "Düzenle";
			this.btn_KategoriDuzenle.UseVisualStyleBackColor = false;
			this.btn_KategoriDuzenle.Click += new System.EventHandler(this.btn_KategoriDuzenle_Click);
			// 
			// txb_KategoriAdi
			// 
			this.txb_KategoriAdi.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
			this.txb_KategoriAdi.Font = new System.Drawing.Font("Century Gothic", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
			this.txb_KategoriAdi.Location = new System.Drawing.Point(151, 6);
			this.txb_KategoriAdi.Name = "txb_KategoriAdi";
			this.txb_KategoriAdi.Size = new System.Drawing.Size(391, 22);
			this.txb_KategoriAdi.TabIndex = 2;
			// 
			// label5
			// 
			this.label5.AutoSize = true;
			this.label5.Font = new System.Drawing.Font("Century Gothic", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
			this.label5.ForeColor = System.Drawing.Color.White;
			this.label5.Location = new System.Drawing.Point(19, 9);
			this.label5.Name = "label5";
			this.label5.Size = new System.Drawing.Size(79, 16);
			this.label5.TabIndex = 1;
			this.label5.Text = "Kategori Adı";
			// 
			// YonetimUrunKategorisiComp
			// 
			this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
			this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
			this.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
			this.Controls.Add(this.pnl_KullaniciAdi);
			this.Name = "YonetimUrunKategorisiComp";
			this.Size = new System.Drawing.Size(706, 34);
			this.pnl_KullaniciAdi.ResumeLayout(false);
			this.pnl_KullaniciAdi.PerformLayout();
			this.ResumeLayout(false);

		}

		#endregion

		private System.Windows.Forms.Panel pnl_KullaniciAdi;
		private System.Windows.Forms.Button btn_KategoriDuzenle;
		private System.Windows.Forms.TextBox txb_KategoriAdi;
		private System.Windows.Forms.Label label5;
	}
}
