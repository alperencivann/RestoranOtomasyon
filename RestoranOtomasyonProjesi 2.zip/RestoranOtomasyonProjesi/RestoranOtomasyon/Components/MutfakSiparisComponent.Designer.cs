﻿namespace RestoranOtomasyon.Components
{
	partial class MutfakSiparisComponent
	{
		/// <summary> 
		/// Required designer variable.
		/// </summary>
		private System.ComponentModel.IContainer components = null;

		/// <summary> 
		/// Clean up any resources being used.
		/// </summary>
		/// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
		protected override void Dispose(bool disposing)
		{
			if (disposing && (components != null))
			{
				components.Dispose();
			}
			base.Dispose(disposing);
		}

		#region Component Designer generated code

		/// <summary> 
		/// Required method for Designer support - do not modify 
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			this.panel1 = new System.Windows.Forms.Panel();
			this.panel2 = new System.Windows.Forms.Panel();
			this.panel3 = new System.Windows.Forms.Panel();
			this.panel4 = new System.Windows.Forms.Panel();
			this.panel5 = new System.Windows.Forms.Panel();
			this.panel6 = new System.Windows.Forms.Panel();
			this.panel7 = new System.Windows.Forms.Panel();
			this.panel8 = new System.Windows.Forms.Panel();
			this.panel12 = new System.Windows.Forms.Panel();
			this.panel14 = new System.Windows.Forms.Panel();
			this.panel15 = new System.Windows.Forms.Panel();
			this.pcb_UrunResmi = new System.Windows.Forms.PictureBox();
			this.lbl_UrunAdi = new System.Windows.Forms.Label();
			this.lbl_Adet = new System.Windows.Forms.Label();
			this.lbl_SiparisSaati = new System.Windows.Forms.Label();
			this.btn_TeslimEt = new System.Windows.Forms.Button();
			this.lbl_Id = new System.Windows.Forms.Label();
			this.panel13 = new System.Windows.Forms.Panel();
			this.btn_IptalEt = new System.Windows.Forms.Button();
			this.panel16 = new System.Windows.Forms.Panel();
			this.panel11 = new System.Windows.Forms.Panel();
			this.lbl_Notlar = new System.Windows.Forms.Label();
			this.panel1.SuspendLayout();
			this.panel2.SuspendLayout();
			this.panel4.SuspendLayout();
			this.panel6.SuspendLayout();
			this.panel7.SuspendLayout();
			this.panel15.SuspendLayout();
			((System.ComponentModel.ISupportInitialize)(this.pcb_UrunResmi)).BeginInit();
			this.panel13.SuspendLayout();
			this.panel11.SuspendLayout();
			this.SuspendLayout();
			// 
			// panel1
			// 
			this.panel1.Controls.Add(this.lbl_Id);
			this.panel1.Dock = System.Windows.Forms.DockStyle.Left;
			this.panel1.Location = new System.Drawing.Point(0, 0);
			this.panel1.Name = "panel1";
			this.panel1.Size = new System.Drawing.Size(15, 88);
			this.panel1.TabIndex = 0;
			// 
			// panel2
			// 
			this.panel2.Controls.Add(this.pcb_UrunResmi);
			this.panel2.Dock = System.Windows.Forms.DockStyle.Left;
			this.panel2.Location = new System.Drawing.Point(15, 0);
			this.panel2.Name = "panel2";
			this.panel2.Size = new System.Drawing.Size(120, 88);
			this.panel2.TabIndex = 1;
			// 
			// panel3
			// 
			this.panel3.Dock = System.Windows.Forms.DockStyle.Left;
			this.panel3.Location = new System.Drawing.Point(135, 0);
			this.panel3.Name = "panel3";
			this.panel3.Size = new System.Drawing.Size(10, 88);
			this.panel3.TabIndex = 2;
			// 
			// panel4
			// 
			this.panel4.Controls.Add(this.lbl_UrunAdi);
			this.panel4.Dock = System.Windows.Forms.DockStyle.Left;
			this.panel4.Location = new System.Drawing.Point(145, 0);
			this.panel4.Name = "panel4";
			this.panel4.Size = new System.Drawing.Size(197, 88);
			this.panel4.TabIndex = 3;
			// 
			// panel5
			// 
			this.panel5.Dock = System.Windows.Forms.DockStyle.Left;
			this.panel5.Location = new System.Drawing.Point(342, 0);
			this.panel5.Name = "panel5";
			this.panel5.Size = new System.Drawing.Size(10, 88);
			this.panel5.TabIndex = 4;
			// 
			// panel6
			// 
			this.panel6.Controls.Add(this.lbl_Adet);
			this.panel6.Dock = System.Windows.Forms.DockStyle.Left;
			this.panel6.Location = new System.Drawing.Point(352, 0);
			this.panel6.Name = "panel6";
			this.panel6.Size = new System.Drawing.Size(85, 88);
			this.panel6.TabIndex = 5;
			// 
			// panel7
			// 
			this.panel7.Controls.Add(this.lbl_SiparisSaati);
			this.panel7.Dock = System.Windows.Forms.DockStyle.Left;
			this.panel7.Location = new System.Drawing.Point(447, 0);
			this.panel7.Name = "panel7";
			this.panel7.Size = new System.Drawing.Size(120, 88);
			this.panel7.TabIndex = 7;
			// 
			// panel8
			// 
			this.panel8.Dock = System.Windows.Forms.DockStyle.Left;
			this.panel8.Location = new System.Drawing.Point(437, 0);
			this.panel8.Name = "panel8";
			this.panel8.Size = new System.Drawing.Size(10, 88);
			this.panel8.TabIndex = 6;
			// 
			// panel12
			// 
			this.panel12.Dock = System.Windows.Forms.DockStyle.Left;
			this.panel12.Location = new System.Drawing.Point(567, 0);
			this.panel12.Name = "panel12";
			this.panel12.Size = new System.Drawing.Size(10, 88);
			this.panel12.TabIndex = 10;
			// 
			// panel14
			// 
			this.panel14.Dock = System.Windows.Forms.DockStyle.Left;
			this.panel14.Location = new System.Drawing.Point(577, 0);
			this.panel14.Name = "panel14";
			this.panel14.Size = new System.Drawing.Size(10, 88);
			this.panel14.TabIndex = 12;
			// 
			// panel15
			// 
			this.panel15.Controls.Add(this.btn_TeslimEt);
			this.panel15.Dock = System.Windows.Forms.DockStyle.Right;
			this.panel15.Location = new System.Drawing.Point(870, 0);
			this.panel15.Name = "panel15";
			this.panel15.Size = new System.Drawing.Size(90, 88);
			this.panel15.TabIndex = 15;
			// 
			// pcb_UrunResmi
			// 
			this.pcb_UrunResmi.Location = new System.Drawing.Point(7, 3);
			this.pcb_UrunResmi.Name = "pcb_UrunResmi";
			this.pcb_UrunResmi.Size = new System.Drawing.Size(107, 83);
			this.pcb_UrunResmi.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
			this.pcb_UrunResmi.TabIndex = 0;
			this.pcb_UrunResmi.TabStop = false;
			// 
			// lbl_UrunAdi
			// 
			this.lbl_UrunAdi.Dock = System.Windows.Forms.DockStyle.Fill;
			this.lbl_UrunAdi.Font = new System.Drawing.Font("Century Gothic", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
			this.lbl_UrunAdi.ForeColor = System.Drawing.Color.White;
			this.lbl_UrunAdi.Location = new System.Drawing.Point(0, 0);
			this.lbl_UrunAdi.Name = "lbl_UrunAdi";
			this.lbl_UrunAdi.Size = new System.Drawing.Size(197, 88);
			this.lbl_UrunAdi.TabIndex = 7;
			this.lbl_UrunAdi.Text = "Ürün Adı";
			this.lbl_UrunAdi.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
			// 
			// lbl_Adet
			// 
			this.lbl_Adet.Dock = System.Windows.Forms.DockStyle.Fill;
			this.lbl_Adet.Font = new System.Drawing.Font("Century Gothic", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
			this.lbl_Adet.ForeColor = System.Drawing.Color.White;
			this.lbl_Adet.Location = new System.Drawing.Point(0, 0);
			this.lbl_Adet.Name = "lbl_Adet";
			this.lbl_Adet.Size = new System.Drawing.Size(85, 88);
			this.lbl_Adet.TabIndex = 8;
			this.lbl_Adet.Text = "Adet";
			this.lbl_Adet.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
			// 
			// lbl_SiparisSaati
			// 
			this.lbl_SiparisSaati.Dock = System.Windows.Forms.DockStyle.Fill;
			this.lbl_SiparisSaati.Font = new System.Drawing.Font("Century Gothic", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
			this.lbl_SiparisSaati.ForeColor = System.Drawing.Color.White;
			this.lbl_SiparisSaati.Location = new System.Drawing.Point(0, 0);
			this.lbl_SiparisSaati.Name = "lbl_SiparisSaati";
			this.lbl_SiparisSaati.Size = new System.Drawing.Size(120, 88);
			this.lbl_SiparisSaati.TabIndex = 8;
			this.lbl_SiparisSaati.Text = "Sipariş Saati";
			this.lbl_SiparisSaati.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
			// 
			// btn_TeslimEt
			// 
			this.btn_TeslimEt.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
			this.btn_TeslimEt.BackColor = System.Drawing.Color.Lime;
			this.btn_TeslimEt.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(89)))), ((int)(((byte)(89)))), ((int)(((byte)(89)))));
			this.btn_TeslimEt.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
			this.btn_TeslimEt.Font = new System.Drawing.Font("Century Gothic", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
			this.btn_TeslimEt.ForeColor = System.Drawing.Color.Black;
			this.btn_TeslimEt.Location = new System.Drawing.Point(3, 3);
			this.btn_TeslimEt.Name = "btn_TeslimEt";
			this.btn_TeslimEt.Size = new System.Drawing.Size(84, 83);
			this.btn_TeslimEt.TabIndex = 16;
			this.btn_TeslimEt.Text = "Teslim Et";
			this.btn_TeslimEt.UseVisualStyleBackColor = false;
			this.btn_TeslimEt.Click += new System.EventHandler(this.btn_TeslimEt_Click);
			// 
			// lbl_Id
			// 
			this.lbl_Id.AutoSize = true;
			this.lbl_Id.Font = new System.Drawing.Font("Microsoft Sans Serif", 1.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
			this.lbl_Id.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(49)))), ((int)(((byte)(49)))), ((int)(((byte)(49)))));
			this.lbl_Id.Location = new System.Drawing.Point(3, 4);
			this.lbl_Id.Name = "lbl_Id";
			this.lbl_Id.Size = new System.Drawing.Size(6, 2);
			this.lbl_Id.TabIndex = 1;
			this.lbl_Id.Text = "label1";
			// 
			// panel13
			// 
			this.panel13.Controls.Add(this.btn_IptalEt);
			this.panel13.Dock = System.Windows.Forms.DockStyle.Right;
			this.panel13.Location = new System.Drawing.Point(780, 0);
			this.panel13.Name = "panel13";
			this.panel13.Size = new System.Drawing.Size(90, 88);
			this.panel13.TabIndex = 16;
			// 
			// btn_IptalEt
			// 
			this.btn_IptalEt.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
			this.btn_IptalEt.BackColor = System.Drawing.Color.Red;
			this.btn_IptalEt.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(89)))), ((int)(((byte)(89)))), ((int)(((byte)(89)))));
			this.btn_IptalEt.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
			this.btn_IptalEt.Font = new System.Drawing.Font("Century Gothic", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
			this.btn_IptalEt.ForeColor = System.Drawing.Color.White;
			this.btn_IptalEt.Location = new System.Drawing.Point(3, 3);
			this.btn_IptalEt.Name = "btn_IptalEt";
			this.btn_IptalEt.Size = new System.Drawing.Size(84, 83);
			this.btn_IptalEt.TabIndex = 15;
			this.btn_IptalEt.Text = "İptal Et";
			this.btn_IptalEt.UseVisualStyleBackColor = false;
			this.btn_IptalEt.Click += new System.EventHandler(this.btn_IptalEt_Click_1);
			// 
			// panel16
			// 
			this.panel16.Dock = System.Windows.Forms.DockStyle.Right;
			this.panel16.Location = new System.Drawing.Point(770, 0);
			this.panel16.Name = "panel16";
			this.panel16.Size = new System.Drawing.Size(10, 88);
			this.panel16.TabIndex = 17;
			// 
			// panel11
			// 
			this.panel11.Controls.Add(this.lbl_Notlar);
			this.panel11.Dock = System.Windows.Forms.DockStyle.Left;
			this.panel11.Location = new System.Drawing.Point(587, 0);
			this.panel11.Name = "panel11";
			this.panel11.Size = new System.Drawing.Size(181, 88);
			this.panel11.TabIndex = 18;
			// 
			// lbl_Notlar
			// 
			this.lbl_Notlar.Dock = System.Windows.Forms.DockStyle.Fill;
			this.lbl_Notlar.Font = new System.Drawing.Font("Century Gothic", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
			this.lbl_Notlar.ForeColor = System.Drawing.Color.White;
			this.lbl_Notlar.Location = new System.Drawing.Point(0, 0);
			this.lbl_Notlar.Name = "lbl_Notlar";
			this.lbl_Notlar.Size = new System.Drawing.Size(181, 88);
			this.lbl_Notlar.TabIndex = 9;
			this.lbl_Notlar.Text = "Sipariş Notları";
			this.lbl_Notlar.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
			// 
			// MutfakSiparisComponent
			// 
			this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
			this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
			this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(49)))), ((int)(((byte)(49)))), ((int)(((byte)(49)))));
			this.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
			this.Controls.Add(this.panel11);
			this.Controls.Add(this.panel16);
			this.Controls.Add(this.panel13);
			this.Controls.Add(this.panel15);
			this.Controls.Add(this.panel14);
			this.Controls.Add(this.panel12);
			this.Controls.Add(this.panel7);
			this.Controls.Add(this.panel8);
			this.Controls.Add(this.panel6);
			this.Controls.Add(this.panel5);
			this.Controls.Add(this.panel4);
			this.Controls.Add(this.panel3);
			this.Controls.Add(this.panel2);
			this.Controls.Add(this.panel1);
			this.Name = "MutfakSiparisComponent";
			this.Size = new System.Drawing.Size(960, 88);
			this.panel1.ResumeLayout(false);
			this.panel1.PerformLayout();
			this.panel2.ResumeLayout(false);
			this.panel4.ResumeLayout(false);
			this.panel6.ResumeLayout(false);
			this.panel7.ResumeLayout(false);
			this.panel15.ResumeLayout(false);
			((System.ComponentModel.ISupportInitialize)(this.pcb_UrunResmi)).EndInit();
			this.panel13.ResumeLayout(false);
			this.panel11.ResumeLayout(false);
			this.ResumeLayout(false);

		}

		#endregion

		private System.Windows.Forms.Panel panel1;
		private System.Windows.Forms.Panel panel2;
		private System.Windows.Forms.Panel panel3;
		private System.Windows.Forms.Panel panel4;
		private System.Windows.Forms.Panel panel5;
		private System.Windows.Forms.Panel panel6;
		private System.Windows.Forms.Panel panel7;
		private System.Windows.Forms.Panel panel8;
		private System.Windows.Forms.PictureBox pcb_UrunResmi;
		private System.Windows.Forms.Panel panel12;
		private System.Windows.Forms.Panel panel14;
		private System.Windows.Forms.Panel panel15;
		private System.Windows.Forms.Label lbl_UrunAdi;
		private System.Windows.Forms.Label lbl_Adet;
		private System.Windows.Forms.Label lbl_SiparisSaati;
		private System.Windows.Forms.Button btn_TeslimEt;
		private System.Windows.Forms.Label lbl_Id;
		private System.Windows.Forms.Panel panel13;
		private System.Windows.Forms.Button btn_IptalEt;
		private System.Windows.Forms.Panel panel16;
		private System.Windows.Forms.Panel panel11;
		private System.Windows.Forms.Label lbl_Notlar;
	}
}
