﻿using RestoranOtomasyon.Forms;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace RestoranOtomasyon.Components
{
    public partial class UrunKategori : UserControl
    {
        int id;
        string kategoriAdi;
        SiparisAl siparisForm;

        public UrunKategori(int id, string ad, SiparisAl siparisEkrani)
        {
            InitializeComponent();
            this.BackColor = Color.FromArgb(29, 29, 29); // this should be pink-ish
            this.BorderStyle = BorderStyle.FixedSingle;
            this.id = id;
            this.kategoriAdi = ad;
            this.siparisForm = siparisEkrani;
            label1.Text = kategoriAdi;

        }

        private void InitializeComponent()
        {
			this.label1 = new System.Windows.Forms.Label();
			this.SuspendLayout();
			// 
			// label1
			// 
			this.label1.Cursor = System.Windows.Forms.Cursors.Hand;
			this.label1.Dock = System.Windows.Forms.DockStyle.Fill;
			this.label1.Font = new System.Drawing.Font("Century Gothic", 10.125F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
			this.label1.ForeColor = System.Drawing.Color.White;
			this.label1.Location = new System.Drawing.Point(0, 0);
			this.label1.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
			this.label1.Name = "label1";
			this.label1.Size = new System.Drawing.Size(160, 51);
			this.label1.TabIndex = 0;
			this.label1.Text = "lbl_KategoriAdi";
			this.label1.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
			this.label1.Click += new System.EventHandler(this.label1_Click);
			// 
			// UrunKategori
			// 
			this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
			this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
			this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(39)))), ((int)(((byte)(39)))), ((int)(((byte)(39)))));
			this.Controls.Add(this.label1);
			this.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
			this.Name = "UrunKategori";
			this.Size = new System.Drawing.Size(160, 51);
			this.ResumeLayout(false);

        }

        private void label1_Click(object sender, EventArgs e)
        {
            siparisForm.urunleriListele(id);
        }
    }
}
