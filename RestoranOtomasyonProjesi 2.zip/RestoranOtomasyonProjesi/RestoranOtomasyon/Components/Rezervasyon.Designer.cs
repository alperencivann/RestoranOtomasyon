﻿namespace RestoranOtomasyon.Components
{
    partial class Rezervasyon
    {
        /// <summary> 
        ///Gerekli tasarımcı değişkeni.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        ///Kullanılan tüm kaynakları temizleyin.
        /// </summary>
        ///<param name="disposing">yönetilen kaynaklar dispose edilmeliyse doğru; aksi halde yanlış.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Bileşen Tasarımcısı üretimi kod

        /// <summary> 
        /// Tasarımcı desteği için gerekli metot - bu metodun 
        ///içeriğini kod düzenleyici ile değiştirmeyin.
        /// </summary>
        private void InitializeComponent()
        {
			System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Rezervasyon));
			this.panel1 = new System.Windows.Forms.Panel();
			this.panel4 = new System.Windows.Forms.Panel();
			this.pictureBox1 = new System.Windows.Forms.PictureBox();
			this.panel2 = new System.Windows.Forms.Panel();
			this.panel5 = new System.Windows.Forms.Panel();
			this.lbl_MasaNo = new System.Windows.Forms.Label();
			this.lbl_KategoriAdi = new System.Windows.Forms.Label();
			this.panel3 = new System.Windows.Forms.Panel();
			this.lbl_IsimSoyisim = new System.Windows.Forms.Label();
			this.lbl_RezervasyonSaati = new System.Windows.Forms.Label();
			this.panel1.SuspendLayout();
			this.panel4.SuspendLayout();
			((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
			this.panel2.SuspendLayout();
			this.panel5.SuspendLayout();
			this.panel3.SuspendLayout();
			this.SuspendLayout();
			// 
			// panel1
			// 
			this.panel1.Controls.Add(this.panel4);
			this.panel1.Dock = System.Windows.Forms.DockStyle.Left;
			this.panel1.Location = new System.Drawing.Point(0, 0);
			this.panel1.Name = "panel1";
			this.panel1.Size = new System.Drawing.Size(60, 60);
			this.panel1.TabIndex = 0;
			this.panel1.Click += new System.EventHandler(this.pictureBox1_Click);
			// 
			// panel4
			// 
			this.panel4.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(24)))), ((int)(((byte)(24)))), ((int)(((byte)(24)))));
			this.panel4.Controls.Add(this.pictureBox1);
			this.panel4.Location = new System.Drawing.Point(3, 3);
			this.panel4.Name = "panel4";
			this.panel4.Size = new System.Drawing.Size(54, 54);
			this.panel4.TabIndex = 0;
			this.panel4.Click += new System.EventHandler(this.pictureBox1_Click);
			// 
			// pictureBox1
			// 
			this.pictureBox1.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox1.Image")));
			this.pictureBox1.Location = new System.Drawing.Point(7, 7);
			this.pictureBox1.Name = "pictureBox1";
			this.pictureBox1.Size = new System.Drawing.Size(40, 40);
			this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
			this.pictureBox1.TabIndex = 0;
			this.pictureBox1.TabStop = false;
			this.pictureBox1.Click += new System.EventHandler(this.pictureBox1_Click);
			// 
			// panel2
			// 
			this.panel2.Controls.Add(this.panel5);
			this.panel2.Dock = System.Windows.Forms.DockStyle.Right;
			this.panel2.Location = new System.Drawing.Point(236, 0);
			this.panel2.Name = "panel2";
			this.panel2.Size = new System.Drawing.Size(60, 60);
			this.panel2.TabIndex = 1;
			this.panel2.Click += new System.EventHandler(this.pictureBox1_Click);
			// 
			// panel5
			// 
			this.panel5.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(24)))), ((int)(((byte)(24)))), ((int)(((byte)(24)))));
			this.panel5.Controls.Add(this.lbl_MasaNo);
			this.panel5.Controls.Add(this.lbl_KategoriAdi);
			this.panel5.Location = new System.Drawing.Point(3, 3);
			this.panel5.Name = "panel5";
			this.panel5.Size = new System.Drawing.Size(54, 54);
			this.panel5.TabIndex = 1;
			this.panel5.Click += new System.EventHandler(this.pictureBox1_Click);
			// 
			// lbl_MasaNo
			// 
			this.lbl_MasaNo.Cursor = System.Windows.Forms.Cursors.Hand;
			this.lbl_MasaNo.Dock = System.Windows.Forms.DockStyle.Fill;
			this.lbl_MasaNo.Font = new System.Drawing.Font("Bahnschrift SemiBold", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
			this.lbl_MasaNo.ForeColor = System.Drawing.Color.White;
			this.lbl_MasaNo.Location = new System.Drawing.Point(0, 27);
			this.lbl_MasaNo.Name = "lbl_MasaNo";
			this.lbl_MasaNo.Size = new System.Drawing.Size(54, 27);
			this.lbl_MasaNo.TabIndex = 13;
			this.lbl_MasaNo.Text = "10";
			this.lbl_MasaNo.TextAlign = System.Drawing.ContentAlignment.TopCenter;
			this.lbl_MasaNo.Click += new System.EventHandler(this.pictureBox1_Click);
			// 
			// lbl_KategoriAdi
			// 
			this.lbl_KategoriAdi.Cursor = System.Windows.Forms.Cursors.Hand;
			this.lbl_KategoriAdi.Dock = System.Windows.Forms.DockStyle.Top;
			this.lbl_KategoriAdi.Font = new System.Drawing.Font("Bahnschrift", 10F);
			this.lbl_KategoriAdi.ForeColor = System.Drawing.Color.White;
			this.lbl_KategoriAdi.Location = new System.Drawing.Point(0, 0);
			this.lbl_KategoriAdi.Name = "lbl_KategoriAdi";
			this.lbl_KategoriAdi.Size = new System.Drawing.Size(54, 27);
			this.lbl_KategoriAdi.TabIndex = 12;
			this.lbl_KategoriAdi.Text = "Masa";
			this.lbl_KategoriAdi.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
			this.lbl_KategoriAdi.Click += new System.EventHandler(this.pictureBox1_Click);
			// 
			// panel3
			// 
			this.panel3.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(39)))), ((int)(((byte)(39)))), ((int)(((byte)(39)))));
			this.panel3.Controls.Add(this.lbl_IsimSoyisim);
			this.panel3.Controls.Add(this.lbl_RezervasyonSaati);
			this.panel3.Dock = System.Windows.Forms.DockStyle.Fill;
			this.panel3.Location = new System.Drawing.Point(60, 0);
			this.panel3.Name = "panel3";
			this.panel3.Size = new System.Drawing.Size(176, 60);
			this.panel3.TabIndex = 2;
			this.panel3.Click += new System.EventHandler(this.pictureBox1_Click);
			// 
			// lbl_IsimSoyisim
			// 
			this.lbl_IsimSoyisim.Cursor = System.Windows.Forms.Cursors.Hand;
			this.lbl_IsimSoyisim.Dock = System.Windows.Forms.DockStyle.Fill;
			this.lbl_IsimSoyisim.Font = new System.Drawing.Font("Bahnschrift", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
			this.lbl_IsimSoyisim.ForeColor = System.Drawing.Color.White;
			this.lbl_IsimSoyisim.Location = new System.Drawing.Point(0, 30);
			this.lbl_IsimSoyisim.Name = "lbl_IsimSoyisim";
			this.lbl_IsimSoyisim.Size = new System.Drawing.Size(176, 30);
			this.lbl_IsimSoyisim.TabIndex = 12;
			this.lbl_IsimSoyisim.Text = "Alperen Civan";
			this.lbl_IsimSoyisim.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
			this.lbl_IsimSoyisim.Click += new System.EventHandler(this.pictureBox1_Click);
			// 
			// lbl_RezervasyonSaati
			// 
			this.lbl_RezervasyonSaati.Cursor = System.Windows.Forms.Cursors.Hand;
			this.lbl_RezervasyonSaati.Dock = System.Windows.Forms.DockStyle.Top;
			this.lbl_RezervasyonSaati.Font = new System.Drawing.Font("Bahnschrift", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
			this.lbl_RezervasyonSaati.ForeColor = System.Drawing.Color.White;
			this.lbl_RezervasyonSaati.Location = new System.Drawing.Point(0, 0);
			this.lbl_RezervasyonSaati.Name = "lbl_RezervasyonSaati";
			this.lbl_RezervasyonSaati.Size = new System.Drawing.Size(176, 30);
			this.lbl_RezervasyonSaati.TabIndex = 11;
			this.lbl_RezervasyonSaati.Text = "18:00 - 21:30 Rezervasyon";
			this.lbl_RezervasyonSaati.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
			this.lbl_RezervasyonSaati.Click += new System.EventHandler(this.pictureBox1_Click);
			// 
			// Rezervasyon
			// 
			this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
			this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
			this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(39)))), ((int)(((byte)(39)))), ((int)(((byte)(39)))));
			this.Controls.Add(this.panel3);
			this.Controls.Add(this.panel2);
			this.Controls.Add(this.panel1);
			this.Name = "Rezervasyon";
			this.Size = new System.Drawing.Size(296, 60);
			this.panel1.ResumeLayout(false);
			this.panel4.ResumeLayout(false);
			((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
			this.panel2.ResumeLayout(false);
			this.panel5.ResumeLayout(false);
			this.panel3.ResumeLayout(false);
			this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.Panel panel3;
        private System.Windows.Forms.Label lbl_IsimSoyisim;
        private System.Windows.Forms.Label lbl_RezervasyonSaati;
        private System.Windows.Forms.Panel panel4;
        private System.Windows.Forms.Panel panel5;
        private System.Windows.Forms.Label lbl_MasaNo;
        private System.Windows.Forms.Label lbl_KategoriAdi;
    }
}
