﻿using Mail.Forms;
using RestoranOtomasyon.Forms;
using RestoranOtomasyon.Functions;
using RestoranOtomasyon.Objects;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace RestoranOtomasyon.Components
{
    public partial class YonetimYetki : UserControl
    {
        int id;
        string yetkiAdi;
        YonetimKullaniciAyarlari yonetimKullanici;

        // CONSTRUCTOR VE LOAD EVENTİ
        public YonetimYetki(int id, string yetkiAdi, YonetimKullaniciAyarlari yonetimKullanici)
        {
            InitializeComponent();
            this.id = id;
            this.yetkiAdi = yetkiAdi;
            this.yonetimKullanici = yonetimKullanici;
            txb_KullaniciAdi.Text = yetkiAdi;
        }
        private void YonetimYetki_Load(object sender, EventArgs e)
        {
            locate();
        }
        // FUNCS
        public void Message(string message)
        {
            MyMessageBox myMessageBox = new MyMessageBox(message);
            myMessageBox.ShowDialog();
        }
        public void locate()
        {
            int guncelleLocX = btn_Guncelle.Location.X;
            int right = (txb_KullaniciAdi.Location.X + txb_KullaniciAdi.Width);
            int xArea = right - guncelleLocX;
            btn_Guncelle.Width = xArea / 2 - 7;
            btn_Sil.Location = new Point(btn_Guncelle.Location.X + btn_Guncelle.Width + 14, btn_Guncelle.Location.Y);
            btn_Sil.Width = xArea / 2 - 7;
        }


        // EVENTS
        private void btn_Guncelle_Click(object sender, EventArgs e)
        {
            // Düzenleme işlemleri
            YonetimYetkileriDuzenlemeForm form = new YonetimYetkileriDuzenlemeForm(id);
            form.Show();
            yonetimKullanici.loadYetkiler();
        }

        private void btn_Sil_Click(object sender, EventArgs e)
        {
            Database database = new Database();
            string result = database.deleteYetki(id);
            Message(result);
            yonetimKullanici.loadYetkiler();
        }

        private void YonetimYetki_SizeChanged(object sender, EventArgs e)
        {
            locate();
        }
    }
}
