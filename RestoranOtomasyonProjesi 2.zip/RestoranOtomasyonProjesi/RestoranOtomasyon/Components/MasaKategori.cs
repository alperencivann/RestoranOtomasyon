﻿using RestoranOtomasyon.Forms;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Reflection.Emit;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace RestoranOtomasyon.Components
{
    public partial class MasaKategori : UserControl
    {
        int id;
        string kategoriAdi;
        GarsonEkrani garsonEkrani;
        public MasaKategori(int id, string ad, GarsonEkrani garsonEkrani)
        {
            InitializeComponent();
            this.id = id;
            this.kategoriAdi = ad;
            this.garsonEkrani = garsonEkrani;
            lbl_KategoriAdi.Text = kategoriAdi;
        }

        private void InitializeComponent()
        {
			this.lbl_KategoriAdi = new System.Windows.Forms.Label();
			this.SuspendLayout();
			// 
			// lbl_KategoriAdi
			// 
			this.lbl_KategoriAdi.Cursor = System.Windows.Forms.Cursors.Hand;
			this.lbl_KategoriAdi.Dock = System.Windows.Forms.DockStyle.Fill;
			this.lbl_KategoriAdi.Font = new System.Drawing.Font("Century Gothic", 10.875F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
			this.lbl_KategoriAdi.ForeColor = System.Drawing.Color.White;
			this.lbl_KategoriAdi.Location = new System.Drawing.Point(0, 0);
			this.lbl_KategoriAdi.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
			this.lbl_KategoriAdi.Name = "lbl_KategoriAdi";
			this.lbl_KategoriAdi.Size = new System.Drawing.Size(177, 51);
			this.lbl_KategoriAdi.TabIndex = 0;
			this.lbl_KategoriAdi.Text = "lbl_KategoriAdi";
			this.lbl_KategoriAdi.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
			this.lbl_KategoriAdi.Click += new System.EventHandler(this.lbl_KategoriAdi_Click);
			// 
			// MasaKategori
			// 
			this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
			this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
			this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(39)))), ((int)(((byte)(39)))), ((int)(((byte)(39)))));
			this.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
			this.Controls.Add(this.lbl_KategoriAdi);
			this.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
			this.Name = "MasaKategori";
			this.Size = new System.Drawing.Size(177, 51);
			this.Load += new System.EventHandler(this.MasaKategori_Load);
			this.ResumeLayout(false);

        }

        private void MasaKategori_Load(object sender, EventArgs e)
        {

        }

        private void lbl_KategoriAdi_Click(object sender, EventArgs e)
        {
            garsonEkrani.listMasa(this.id, this.kategoriAdi);
        }
    }
}
